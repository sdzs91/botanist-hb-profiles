Instructions can be found here:

http://www.thebuddyforum.com/honorbuddy-forum/submitted-profiles/neutral/127960-botanists-reins-drake-north-wind-mount-farm.html