*** Disclaimer ***
*** READ THIS OR YOUR COMPUTER WILL BLOW UP ***


When complete, these profiles will level your character from level 1 through 85, fully automated 


We have not yet determined the total runtime. Present guess-timate would be 10-80 in less than 32 hours (including automated movement between instances)


Under NO circumstances do we advise or suggest that you run these profiles unattended or for excessive amounts of time.


If you, as the user, decide to go against this warning, you do so after being informed that we as the profile writers advise against it.




*** Prerequisites ***

Due to an extensive use of the RunLikeHell Custom Behavior,

if at any time you stop the bot inside the instance, you must close and restart HonorBuddy to clear the memory ! 

You must also exit the instance and manually reset it if any bosses were killed !!!


You must have 1 HonorBuddy session per character you intend to run the profiles on.


The Booster must be the leader of the party.


All characters must abide by the levels of the profiles.

Booster - Must be level 90
RAF - Must be level 1-85


 The profiles do not require your characters to be RAFed together, but you will not receive the triple XP bonus unless they are.
 If the characters are RAFed, the "raf" toons must not be RAFed directly to the Booster.
 In order to receive the triple XP bonus, your RAF toons can't be more than four levels apart.


The 1-10 profiles will require a minimum of 5g on you character, or they will not run.


The 1-10 profiles will require the user to enable the Autoequip plugin (which comes default with HonorBuddy) to equip gear purchased at level 5..


 Each RAF character must have gold for riding and at least two mounts (one for ground, one for flight).

Available @ Level 20 - Apprentice Riding (4g)
Available @ Level 40 - Journeyman Riding (50g)
Available @ Level 60 - Expert Riding (250g)  - mandatory trained  @ level 60
Available @ Level 60 - Flight Master's License (250g) - mandatory trained  @ level 80
Available @ Level 60 - Cold Weather Flying (500g) - mandatory trained @ level 68
Total riding cost: 1054g

Any blue ground mount (1g)
Any blue flying mount (50g)
Total mount cost: 51g

Grand total: 1105g


 The Booster must have a Hearthstone - OR - Innkeeper's Daughter present in their bags.


 At all times, the RAF's hearthstone must be set in the proper location in order to have full functionality. 


Alliance RAF's must have a hearthstone in their bags and that hearthstone must be set to Innkeeper Allison in Stormwind. 
Horde RAF's must have a hearthstone in their bags and that hearthstone must be set to Innkeeper Gryshka in Orgrimmar.



*** Instructions ***



*** 1-80 Semi Automation ***
If you are starting the profiles between levels 1 and 10, you must start all your characters from the (race starting) zone, Stormwind (Alliance) or Orgrimmar (Horde).


If you are starting the profiles between levels 10 and 17, you must start all your characters from Stormwind (Alliance) or Orgrimmar (Horde).


If you are starting the profiles > level 17, determine which profile you need to run (Chart Below) based on the lowest level character in the party.



[17-25] Blackfathom Deeps 

[25-37] Razorfen Kraul 

[37-42] Razorfen Downs

[42-48] Blackrock Depths

[48-60] Blackrock Spire

[60-63] Blood Furnace

[63-68] Sethekk Halls

[68-71] Utgarde Keep

[71-73] Drak'tharon Keep

[73-75] Gundrak

[75-80] Halls of Lightning

[80-83] Blackrock Caverns  *non RAF XP

[83-85] Lost City of Tolvir *non RAF XP


User must set the hearthstone's of all RAF characters with Innkeeper Allison in Stormwind (Alliance) or Innkeeper Gryshka in Orgrimmar (Horde).

Users must invite all party members into the party. The Booster must be the party leader.

You must then move all your charcters 5 meters/yards away from the instance (entrance portal) you wish to begin.

Click load profile in the HonorBuddy UI. Browse to where you have the profiles stored. Double click the appropriate profile.


Users may opt to use the [QO][1-80]_raf-auto-loader (RAF Toons ONLY) or manually select the first profile for the RAF characters.

Users must manually select the first profile on the Booster.

Automation will begin from there.


Once you have selected the appropriate profile on all your characters, start HonorBuddy on all of the party members. 

Complete automation will begin from that point.



*** 1-80 Full Automation ***


Roll your level 1 characters.

Put 1105g on each of the characters. The RAF characters must have a minimum of 5g to begin the profile.

From the Booster's account, invite all the characters into a party. The Booster must be the party leader.

Select the "questing" bot base on all your bots.

Load the Deadmines (Alliance) or Wailing Caverns (Horde) profile on the Booster.

Load the [QO][1-80]_raf-auto-loader on all the RAF characters.

Start all your characters from that point.



The Booster will fly to the rendezvous location and wait for the RAF toons to arrive.

The RAF characters will make their way to Stormwind or Orgrimmar and grind until level 5.

At level 5 the RAF characters will purchase gear and then continue grinding until level 10.

At level 10, the RAF characters will rendezvous with the Booster and automatically begin farming instances.


*** INFORMATION ***

How to RAF Accounts ----------> https://www.youtube.com/watch?feature=player_embedded&v=pvXMpfPb6Ok

 Should you have questions that are not answered on this page or bug reports :

Contact me via Skype by clicking my link ----> : Botanist


 There will be two modes of operation:


Full Automation - User starts the bots (where told) or approximately 5 yrds away from the correct portal entrance, starts all characters from there, and allows the profiles to control everything !!!


Instance Automation - User manually moves all characters approximately 5 yrds away from the correct portal entrance, starts all characters from there. 

User will need to stop the automated movement when the characters reach the appropriate level to advance to the next instance.

Otherwise, the characters will advance to the next instance automatically !!!


Important:

Users that have the Cataclysm Expansion can stop the bots at level (77) and change to the [QO-N][80-83]_blackrock-caverns profile.

Doing so will greatly increase XP/hr and decrease leveling time between levels (77-80) !!!

Otherwise, the bots will continue until level 80 in Halls of Lightning.


When the 1-10 sections are complete, users will be able to create any (non zone-locked race) level 1  character,

the character will make its way to Elwynn Forest/Durator and grind to level 10 before setting its hearth in the right location for running Symbiotic.


During testing, we noticed that HonorBuddy will give the following error if you intialize the bot while your character is in an instance.

If you encounter this problem, move your characters outside the instance and then start HonorBuddy:

"Object reference not set to an instance of an object"