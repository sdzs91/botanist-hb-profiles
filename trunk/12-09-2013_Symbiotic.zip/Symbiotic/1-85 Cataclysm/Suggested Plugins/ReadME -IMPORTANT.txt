 This has been Modified to DELETE everything in your bags except your hearthstone.
 
 Categories for common, uncommon and rares loots have been added and set to delete by default, leafe the setting that way
 
 IT IS MEANT TO BE USED BY THE RAF TOONS ONLY !!
 
 This will now delete EVERYTHING in your bags every 5 minutes.
 
Copy the entire folder to your RAF toons \Plugins folder then enable it on the Plugins tab of the HonorBuddy GUI