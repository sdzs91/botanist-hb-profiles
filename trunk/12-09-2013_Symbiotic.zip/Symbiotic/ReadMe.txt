Instructions can be found here:

http://www.thebuddyforum.com/honorbuddy-forum/submitted-profiles/neutral/113413-symbiotic-ultimate-raf-power-leveling-solution.html