Instructions can be found here:

http://www.thebuddyforum.com/honorbuddy-forum/submitted-profiles/128297-botanists-solstice.html#post1236231
