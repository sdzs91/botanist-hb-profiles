-------------------------------------------------------------------------------
-- ElvUI_ChatTweaks By Lockslap (US, Bleeding Hollow)
-- <Borderline Amazing>, http://ba-guild.com
-------------------------------------------------------------------------------
local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("ElvUI_ChatTweaks", "koKR", false)
if not L then return end

L["About"] = "About" -- Requires localization
L["achieve"] = "achieve" -- Requires localization
L["Achievement Filter"] = "Achievement Filter" -- Requires localization
L["Achievement Messages"] = "Achievement Messages" -- Requires localization
L["  Achievement Points\
"] = "  Achievement Points\
" -- Requires localization
L["Action"] = "Action" -- Requires localization
L["Action to take when an icon is found."] = "Action to take when an icon is found." -- Requires localization
L["Add an |cff00ff00/emotes|r command to see what custom emotes you currently have running."] = "Add an |cff00ff00/emotes|r command to see what custom emotes you currently have running." -- Requires localization
L["Add |cff00ff00/emotes|r Command"] = "Add |cff00ff00/emotes|r Command" -- Requires localization
L["Add custom emotes.  Please remember that your character's name will always be the first word.\
\
|cff00ff00%t|r is your current target."] = "Add custom emotes.  Please remember that your character's name will always be the first word.\
\
|cff00ff00%t|r is your current target." -- Requires localization
L["Add Group Trigger"] = "Add Group Trigger" -- Requires localization
L["Add Guild Trigger"] = "Add Guild Trigger" -- Requires localization
L["Add item icons to loot received messages."] = "Add item icons to loot received messages." -- Requires localization
L["Addon Version Sent, Version: |cffffff00%s|r"] = "Addon Version Sent, Version: |cffffff00%s|r" -- Requires localization
L["Adds a timestamp to each line of text."] = "\234\176\129 \235\157\188\236\157\184\236\151\144 \237\131\128\236\158\132 \236\138\164\237\131\172\237\148\132 \236\182\148\234\176\128" -- Needs review
L["Adds chat commands |cff1784d1/chatframes|r and |cff1784d1/cf|r to help you identify the chat frames and their numbers."] = "Adds chat commands |cff1784d1/chatframes|r and |cff1784d1/cf|r to help you identify the chat frames and their numbers." -- Requires localization
L["Adds chat commands to clear the chat windows.\
\
"] = "\235\176\157\236\157\128 \237\153\148\235\169\180\236\151\144 \235\170\133\235\160\185 \236\182\148\234\176\128.\\n\\n" -- Needs review
L["Adds item links to Auction House messages.  Enabling this module will automatically disable the Auction Message Filter module.\
\
|cffff0000If you do not have the item in your bags at the time of the system message firing then this will not be able to get the item link.  This is a limitation of the|r |cffffff00GetItemInfo()|r |cffff0000API function.  If this occurs, then the module will simple pass through the default message.|r"] = "Adds item links to Auction House messages.  Enabling this module will automatically disable the Auction Message Filter module.\
\
|cffff0000If you do not have the item in your bags at the time of the system message firing then this will not be able to get the item link.  This is a limitation of the|r |cffffff00GetItemInfo()|r |cffff0000API function.  If this occurs, then the module will simple pass through the default message.|r" -- Requires localization
L["Adds tell target slash command, |cff00ff00/tt|r."] = "Adds tell target slash command, |cff00ff00/tt|r." -- Requires localization
L["Add surrounding brackets to own charname in messages."] = "\234\183\184\235\166\172\235\147\156 \235\178\136\237\152\184\235\165\188 \236\182\148\234\176\128\237\149\152\235\138\148 \236\160\149\235\179\180\236\157\152 \236\151\173\237\149\160" -- Needs review
L["Add word to your group invite trigger list"] = "Add word to your group invite trigger list" -- Requires localization
L["Add word to your guild invite trigger list."] = "Add word to your guild invite trigger list." -- Requires localization
L["AFK"] = "AFK" -- Requires localization
L["AFK/DND Filter"] = "AFK/DND Filter" -- Requires localization
L["AFK Messages"] = "AFK Messages" -- Requires localization
L["After"] = "\235\146\164" -- Needs review
L["Alchemy"] = "Alchemy" -- Requires localization
L["All"] = "All" -- Requires localization
L["Allow someone to request a link of all your professions."] = "Allow someone to request a link of all your professions." -- Requires localization
L["Allows you to change the default font settings for the chat frames.\
\
|cffff0000Using another addon to do this will break this functionality.|r"] = "\234\184\176\235\179\184 \234\184\128\234\188\180 \236\132\164\236\160\149\236\157\132 \236\130\172\236\154\169\237\149\152\235\169\180 \235\140\128\237\153\148 \236\131\129\236\158\144\235\165\188 \235\179\128\234\178\189.\\n\\n|cffff0000\237\148\140\235\159\172\234\183\184\236\157\184 \235\139\164\235\165\184 \236\156\160\236\130\172\237\149\156\235\165\188 \236\130\172\236\154\169\237\149\152\236\151\172\236\157\180 \237\149\168\236\136\152.|r\
" -- Needs review
L["Allows you to color the pet battle info messages, and determine which chat frame to send them to.\
\
I am aware that some of the features of this module don't really pertain to the chat, but I couldn't really justify an entirely new addon.  So I just snuck them into here."] = "Allows you to color the pet battle info messages, and determine which chat frame to send them to.\
\
I am aware that some of the features of this module don't really pertain to the chat, but I couldn't really justify an entirely new addon.  So I just snuck them into here." -- Requires localization
L["Allows you to filter certain words or phrases using Lua's pattern matching. For an item, achievement, spell, etc. just use the name of the item, don't try to link it.\
\
For more information see this addon's Curse or WoWInterface page."] = "Allows you to filter certain words or phrases using Lua's pattern matching. For an item, achievement, spell, etc. just use the name of the item, don't try to link it.\
\
For more information see this addon's Curse or WoWInterface page." -- Requires localization
L["Allows you to reroute auction house messages to a different chat frame."] = "Allows you to reroute auction house messages to a different chat frame." -- Requires localization
L["Allows you to spam a message to General or Trade chat every X seconds.  Useful for guild recruitment or profession links."] = "Allows you to spam a message to General or Trade chat every X seconds.  Useful for guild recruitment or profession links." -- Requires localization
L["Allows you to strip certain links from channels of your choice."] = "Allows you to strip certain links from channels of your choice." -- Requires localization
L["alt2"] = "alt2" -- Requires localization
L["alt3"] = "alt3" -- Requires localization
L["Alt-click name to invite"] = "Alt-click \236\180\136\235\140\128\236\158\165 \236\157\180\235\166\132\236\157\132 \237\129\180\235\166\173\
" -- Needs review
L["Alternate"] = "Alternate" -- Requires localization
L["ALTERNATE"] = "ALTERNATE" -- Requires localization
L["Alternate command to kick someone from guild."] = "\235\170\133\235\160\185\236\150\180\235\161\156 \234\184\184\235\147\156\235\165\188 \234\181\144\236\178\180" -- Needs review
L["Alt Names"] = "Alt Names" -- Requires localization
L["Alt note fallback"] = "Alt note fallback" -- Requires localization
L["Announce when a mage begins casting Ritual of Refreshment."] = "Announce when a mage begins casting Ritual of Refreshment." -- Requires localization
L["Announce when an alchemist puts down a (Big) Cauldron of Battle."] = "Announce when an alchemist puts down a (Big) Cauldron of Battle." -- Requires localization
L["Announce when an engineer puts down a repair bot."] = "Announce when an engineer puts down a repair bot." -- Requires localization
L["Announce when a warlock puts down a soulwell."] = "Announce when a warlock puts down a soulwell." -- Requires localization
L["Announce when a warlock puts down a summoning stone."] = "Announce when a warlock puts down a summoning stone." -- Requires localization
L["Announce when someone casts Mass Ressurection, obtained when your guild reaches level 25."] = "Announce when someone casts Mass Ressurection, obtained when your guild reaches level 25." -- Requires localization
L["Announce when someone puts down a feast."] = "Announce when someone puts down a feast." -- Requires localization
L["ap"] = "ap" -- Requires localization
L["Are you sure you want to delete all your saved class/level data?"] = "\235\139\185\236\139\160\236\157\128 \236\160\149\235\167\144 \235\139\185\236\139\160\236\157\180 \235\160\136\235\178\168 / \236\167\129\236\151\133 \235\141\176\236\157\180\237\132\176\235\165\188 \236\160\128\236\158\165 \236\130\173\236\160\156\237\149\152\236\139\156\234\178\160\236\138\181\235\139\136\234\185\140?" -- Needs review
L["Are you sure you want to reset the chat fonts to defaults?"] = "\235\139\185\236\139\160\236\157\128 \234\184\176\235\179\184\234\176\146\236\156\188\235\161\156 \236\177\132\237\140\133 \234\184\128\234\188\180\236\157\132 \236\158\172\236\132\164\236\160\149 \237\149\152\236\139\156\234\178\160\236\138\181\235\139\136\234\185\140?" -- Needs review
L["A simple calculator used to perform basic operations on gold values.  Providing no parameters will show you how much gold you have.\
\
You can include your current gold amount by using the |cff00ff00mymoney|r keyword.  For example |cff00ff00mymoney * 2|r.\
\
|cffff0000Money amounts can only be added or subtracted, multiplication or division can only be performed with money and a number.  For example:  4g * 4 is okay, where 4g * 4g is invalid."] = "A simple calculator used to perform basic operations on gold values.  Providing no parameters will show you how much gold you have.\
\
You can include your current gold amount by using the |cff00ff00mymoney|r keyword.  For example |cff00ff00mymoney * 2|r.\
\
|cffff0000Money amounts can only be added or subtracted, multiplication or division can only be performed with money and a number.  For example:  4g * 4 is okay, where 4g * 4g is invalid." -- Requires localization
L["A simple command-line calculator.  Certain keywords, listed below, can be used and their in game value will be substituted.  You can also assign variables which are saved for later use.\
\
|cffffff00Keywords:|r\
"] = "A simple command-line calculator.  Certain keywords, listed below, can be used and their in game value will be substituted.  You can also assign variables which are saved for later use.\
\
|cffffff00Keywords:|r\
" -- Requires localization
L["Auction Expired"] = "Auction Expired" -- Requires localization
L["Auction Message Filtering"] = "Auction Message Filtering" -- Requires localization
L["Auction Message Types"] = "Auction Message Types" -- Requires localization
L["Auction Outbid"] = "Auction Outbid" -- Requires localization
L["Auction Removed"] = "Auction Removed" -- Requires localization
L["Auction Sold"] = "Auction Sold" -- Requires localization
L["Auction Won"] = "Auction Won" -- Requires localization
L["Auto Congratulate"] = "Auto Congratulate" -- Requires localization
L["Auto Ding"] = "Auto Ding" -- Requires localization
L["Auto Farewell"] = "Auto Farewell" -- Requires localization
L["Automatically bid someone farewell when they leave your guild."] = "Automatically bid someone farewell when they leave your guild." -- Requires localization
L["Automatically congratulate someone when they, or others, complete an achievement."] = "Automatically congratulate someone when they, or others, complete an achievement." -- Requires localization
L["Automatically congratulates someone when they say \"ding\" in chat."] = "Automatically congratulates someone when they say \"ding\" in chat." -- Requires localization
L["Automatically enables chat logging."] = "\236\158\144\235\143\153 \236\177\132\237\140\133 \235\169\148\236\139\156\236\167\128 \235\161\156\234\185\133\236\157\180 \237\153\156\236\132\177\237\153\148\235\144\169\235\139\136\235\139\164." -- Needs review
L["Automatically enable tracking of pets for battles."] = "Automatically enable tracking of pets for battles." -- Requires localization
L["Automatically enable tracking of Stable Masters to help you revive and/or heal your pets."] = "Automatically enable tracking of Stable Masters to help you revive and/or heal your pets." -- Requires localization
L["Automatically link someone the profession they requested via various keywords."] = "Automatically link someone the profession they requested via various keywords." -- Requires localization
L["Automatically Remove Item When Finished"] = "Automatically Remove Item When Finished" -- Requires localization
L["Automatically welcomes someone to your guild."] = "Automatically welcomes someone to your guild." -- Requires localization
L["Automatic Chat Logging"] = "Automatic Chat Logging" -- Requires localization
L["Auto Profession Link"] = "Auto Profession Link" -- Requires localization
L["Auto Welcome"] = "Auto Welcome" -- Requires localization
L["Available Chat Command Arguments"] = "\235\170\133\235\160\185 \235\167\164\234\176\156 \235\179\128\236\136\152\235\165\188 \236\177\132\237\140\133" -- Needs review
L["Available parameters are |cff1784d1version|r, |cff1784d1build|r, |cff1784d1date|r, |cff1784d1interface|r, |cff1784d1locale|r."] = "Available parameters are |cff1784d1version|r, |cff1784d1build|r, |cff1784d1date|r, |cff1784d1interface|r, |cff1784d1locale|r." -- Requires localization
L["Battleground"] = "Battleground" -- Requires localization
L["Battleground Channel"] = "Battleground Channel" -- Requires localization
L["Battleground Leader"] = "Battleground Leader" -- Requires localization
L["Battle.Net Options"] = "\235\184\148\235\166\172\236\158\144\235\147\156 \236\132\164\236\160\149" -- Needs review
L["Before"] = "\236\149\158\236\151\144" -- Needs review
L["Bid Accepted"] = "Bid Accepted" -- Requires localization
L["Blacksmithing"] = "Blacksmithing" -- Requires localization
L["Build: |cff1784d1%s|r"] = "Build: |cff1784d1%s|r" -- Requires localization
L["Build Date: |cff1784d1%s|r"] = "Build Date: |cff1784d1%s|r" -- Requires localization
L["Busy"] = "Busy" -- Requires localization
L["Calculator"] = "Calculator" -- Requires localization
L["Can't set value '%s', doesn't look like a number."] = "Can't set value '%s', doesn't look like a number." -- Requires localization
L["Capture Delay"] = "Capture Delay" -- Requires localization
L["Cauldron of Battle"] = "Cauldron of Battle" -- Requires localization
L["Center"] = "Center" -- Requires localization
L["   |cff00ff00/ct %s|r or |cff00ff00%s|r - %s"] = "   |cff00ff00/ct %s|r or |cff00ff00%s|r - %s" -- Requires localization
L["   |cff00ff00/ct %s|r - %s"] = "   |cff00ff00/ct %s|r - %s" -- Requires localization
L["|cff00ff00%d|r Custom %s Being Used"] = "|cff00ff00%d|r Custom %s Being Used" -- Requires localization
L["|cff00ff00Enabled|r"] = "|cff00ff00Enabled|r" -- Requires localization
L["|cff00ff00%s|r"] = "|cff00ff00%s|r" -- Requires localization
L["|cff00ff00%s|r or |cff00ff00%s|r %s"] = "|cff00ff00%s|r or |cff00ff00%s|r %s" -- Requires localization
L["   |cff00ff00%s|r or |cff00ff00%s|r - %s"] = "   |cff00ff00%s|r or |cff00ff00%s|r - %s" -- Requires localization
L["   |cff00ff00%s|r - %s"] = "   |cff00ff00%s|r - %s" -- Requires localization
L["|cff1784d1ElvUI Chat Tweaks|r version |cff1784d1%s|r"] = "|cff1784d1ElvUI Chat Tweaks|r version |cff1784d1%s|r" -- Requires localization
L["|cFF5cb4f8Pet Battle - Tale of the Tape|r"] = "|cFF5cb4f8Pet Battle - Tale of the Tape|r" -- Requires localization
L["|cffc7c7cfs|r"] = "|cffc7c7cfs|r" -- Requires localization
L["|cFFccff00Not Owned|r"] = "|cFFccff00Not Owned|r" -- Requires localization
L["|cffeda55fc|r"] = "|cffeda55fc|r" -- Requires localization
L["|cffff0000Disabled|r"] = "|cffff0000Disabled|r" -- Requires localization
L["|cffff0000ERROR|r Both messages must be set in order to use the spam method |cffffff00%s|r"] = "|cffff0000ERROR|r Both messages must be set in order to use the spam method |cffffff00%s|r" -- Requires localization
L["|cffff0000Item|r |cffffffff\"%s\"|r |cffff0000does not exist.|r"] = "|cffff0000Item|r |cffffffff\"%s\"|r |cffff0000does not exist.|r" -- Requires localization
L["|cffff0000No modules found.|r"] = "|cffff0000No modules found.|r" -- Requires localization
L["\
\
|cffff0000NOTE:|r  If this addon starts to use a substantial amount of memory, simply reset the name data and it will return to a normal level."] = "\
\
|cffff0000NOTE:|r  If this addon starts to use a substantial amount of memory, simply reset the name data and it will return to a normal level." -- Requires localization
L["\
\
|cffff0000NOTE:|r  If this addon starts to use a substantial amount of memory, simply reset the name data and it will return to a normal level.\
\
Addon Usage: |cff00ff00%s|r"] = "\
\
|cffff0000NOTE:|r  If this addon starts to use a substantial amount of memory, simply reset the name data and it will return to a normal level.\
\
Addon Usage: |cff00ff00%s|r" -- Requires localization
L["|cffff0000The Chat Frame you chose to output reputation changes,|r |cffffffff%s|r|cffff0000, does not exist."] = "|cffff0000The Chat Frame you chose to output reputation changes,|r |cffffffff%s|r|cffff0000, does not exist." -- Requires localization
L[" |cFFff5a00(Upgrade)|r"] = " |cFFff5a00(Upgrade)|r" -- Requires localization
L["|cffff9000Not in Pet Journal|r"] = "|cffff9000Not in Pet Journal|r" -- Requires localization
L["|cffff9000Pet Journal:|r %s"] = "|cffff9000Pet Journal:|r %s" -- Requires localization
L["|cffffd700g|r"] = "|cffffd700g|r" -- Requires localization
L["|cffffff00Character already in a guild."] = "|cffffff00Character already in a guild." -- Requires localization
L["|cffffff00Character already in your guild."] = "|cffffff00Character already in your guild." -- Requires localization
L[" |cffffff00%d|r Total Modules (|cff00ff00%d|r Enabled, |cffff0000%d|r Disabled)"] = " |cffffff00%d|r Total Modules (|cff00ff00%d|r Enabled, |cffff0000%d|r Disabled)" -- Requires localization
L["|cffffff00One of your addons is breaking critical chat data I need to work properly :(|r"] = "|cffffff00One of your addons is breaking critical chat data I need to work properly :(|r" -- Requires localization
L["|cffffff00Unable to execute secure command.|r |cffffffff%s|r"] = "|cffffff00Unable to execute secure command.|r |cffffffff%s|r" -- Requires localization
L["|cffffff00Usage: /ginvite <name>|r"] = "|cffffff00Usage: /ginvite <name>|r" -- Requires localization
L["|cffffff00Usage: /gkick <name>|r"] = "|cffffff00Usage: /gkick <name>|r" -- Requires localization
L["|cffffff00Usage: /in <delay> <command>|r"] = "|cffffff00Usage: /in <delay> <command>|r" -- Requires localization
L["|cffffff00Usage: /rpt <times> <command>|r"] = "|cffffff00Usage: /rpt <times> <command>|r" -- Requires localization
L["|cffffffffBlocked spam from |Hplayer:%s|h[%s]|h,|r |cfffe2ec8|Hspamfilter:%d:%s|h[Click to report!]|h|r"] = "|cffffffffBlocked spam from |Hplayer:%s|h[%s]|h,|r |cfffe2ec8|Hspamfilter:%d:%s|h[Click to report!]|h|r" -- Requires localization
L["|cffffffffYou have %s.|r"] = "|cffffffffYou have %s.|r" -- Requires localization
L["Changed Channel"] = "Changed Channel" -- Requires localization
L["Channel"] = "Channel" -- Requires localization
L["Channel Colors"] = "Channel Colors" -- Requires localization
L["Channel %d"] = "Channel %d" -- Requires localization
L["Channel Notice Filter"] = "Channel Notice Filter" -- Requires localization
L["Channels"] = "Channels" -- Requires localization
L["Channel Sounds"] = "Channel Sounds" -- Requires localization
L["Channel Spam"] = "Channel Spam" -- Requires localization
L["Channel Spam has been |cff%s%s|r."] = "Channel Spam has been |cff%s%s|r." -- Requires localization
L["Channel Spam is already running."] = "Channel Spam is already running." -- Requires localization
L["Channels to Monitor"] = "Channels to Monitor" -- Requires localization
L["Channel to output the messages to."] = "Channel to output the messages to." -- Requires localization
L["Character to use between the name and level"] = "Character to use between the name and level" -- Requires localization
L["Character to use for the left bracket"] = "Character to use for the left bracket" -- Requires localization
L["Character to use for the right bracket"] = "Character to use for the right bracket" -- Requires localization
L["Chat"] = "Chat" -- Requires localization
L["Chat Fading"] = "Chat Fading" -- Requires localization
L["Chat Fonts"] = "Chat Fonts" -- Requires localization
L["Chat Frame"] = "Chat Frame" -- Requires localization
L["Chat Frame "] = "Chat Frame " -- Requires localization
L["Chat Frame %d"] = "Chat Frame %d" -- Requires localization
L["ChatFrame %d"] = "ChatFrame %d" -- Requires localization
L["Chat Frame Settings"] = "Chat Frame Settings" -- Requires localization
L["Chat frame to output the messages.  Default is ChatFrame3, which is the default output frame for reputation messages in ElvUI."] = "Chat frame to output the messages.  Default is ChatFrame3, which is the default output frame for reputation messages in ElvUI." -- Requires localization
L["Chat frame to output the message to.  Default is |cffffff00ChatFrame3|r, which is the default frame for ElvUI XP messages."] = "Chat frame to output the message to.  Default is |cffffff00ChatFrame3|r, which is the default frame for ElvUI XP messages." -- Requires localization
L["Chat frame to route the auction house messages to."] = "Chat frame to route the auction house messages to." -- Requires localization
L["Chat frame to route the messages to."] = "Chat frame to route the messages to." -- Requires localization
L["Chat frame to send the messages to."] = "Chat frame to send the messages to." -- Requires localization
L["Chat message"] = "Chat message" -- Requires localization
L["Chat message with icons"] = "Chat message with icons" -- Requires localization
L["Chats To Monitor"] = "Chats To Monitor" -- Requires localization
L["Cheats Color"] = "Cheats Color" -- Requires localization
L["Choose which chat frames display timestamps"] = "Choose which chat frames display timestamps" -- Requires localization
L["Class"] = "Class" -- Requires localization
L["Clear all chat windows."] = "Clear all chat windows." -- Requires localization
L["Clear Chat Commands"] = "Clear Chat Commands" -- Requires localization
L["Clear current chat."] = "Clear current chat." -- Requires localization
L["Click to reset the materials you're tracking."] = "Click to reset the materials you're tracking." -- Requires localization
L["Client Locale: |cff1784d1%s|r"] = "Client Locale: |cff1784d1%s|r" -- Requires localization
L["Coin Size"] = "Coin Size" -- Requires localization
L["Color"] = "Color" -- Requires localization
L["Color Anywhere"] = "Color Anywhere" -- Requires localization
L["Color a roll game loss, aka when you roll a one (1)."] = "Color a roll game loss, aka when you roll a one (1)." -- Requires localization
L["Color a roll game win, aka when someone else rolls a one (1)."] = "Color a roll game win, aka when someone else rolls a one (1)." -- Requires localization
L["Color Cheats"] = "Color Cheats" -- Requires localization
L["Colorize"] = "Colorize" -- Requires localization
L["Color level by difficulty"] = "Color level by difficulty" -- Requires localization
L["Color Loss"] = "Color Loss" -- Requires localization
L["Color Name"] = "Color Name" -- Requires localization
L["Color of other's rolls."] = "Color of other's rolls." -- Requires localization
L["Color of the base reputation messages."] = "Color of the base reputation messages." -- Requires localization
L["Color of the faction."] = "Color of the faction." -- Requires localization
L["Color of the output message."] = "Color of the output message." -- Requires localization
L["Color of the reputation needed/left."] = "Color of the reputation needed/left." -- Requires localization
L["Color of the standing (honored, revered, etc.)."] = "Color of the standing (honored, revered, etc.)." -- Requires localization
L["Color own charname in messages."] = "Color own charname in messages." -- Requires localization
L["Color Player Names By..."] = "Color Player Names By..." -- Requires localization
L["Color regular rolls by others."] = "Color regular rolls by others." -- Requires localization
L["Color Rolls"] = "Color Rolls" -- Requires localization
L["Color rolls differently to make tracking the roll game easier on the eyes."] = "Color rolls differently to make tracking the roll game easier on the eyes." -- Requires localization
L["Color rolls that do not start at 1."] = "Color rolls that do not start at 1." -- Requires localization
L["Color self in messages"] = "Color self in messages" -- Requires localization
L["Color the name of the pets during a pet battle relative to their rarity.  If you have the pet you're currently battling it will also add the quality of the pet you have in your journal."] = "Color the name of the pets during a pet battle relative to their rarity.  If you have the pet you're currently battling it will also add the quality of the pet you have in your journal." -- Requires localization
L["Color the player names anywhere they're found."] = "Color the player names anywhere they're found." -- Requires localization
L["Color timestamps the same as the channel they appear in."] = "Color timestamps the same as the channel they appear in." -- Requires localization
L["Color to change the filtered message to.\
\
|cffff0000Only works when Filtering Mode is set to |cff00ff00Colorize|r."] = "Color to change the filtered message to.\
\
|cffff0000Only works when Filtering Mode is set to |cff00ff00Colorize|r." -- Requires localization
L["Color to designate a cheating roll."] = "Color to designate a cheating roll." -- Requires localization
L["Color to designate a roll game loss."] = "Color to designate a roll game loss." -- Requires localization
L["Color to designate a roll game win."] = "Color to designate a roll game win." -- Requires localization
L["Color to use for your rolls."] = "Color to use for your rolls." -- Requires localization
L["Color Win"] = "Color Win" -- Requires localization
L["Color Your Rolls"] = "Color Your Rolls" -- Requires localization
L["Color your rolls to set them apart."] = "Color your rolls to set them apart." -- Requires localization
L["Combined"] = "Combined" -- Requires localization
L["Compress"] = "Compress" -- Requires localization
L["Congratulate achievements earned by guildmates."] = "Congratulate achievements earned by guildmates." -- Requires localization
L["Congratulate achievements earned by people in your party."] = "Congratulate achievements earned by people in your party." -- Requires localization
L["Congratulate achievements earned by people in your raid."] = "Congratulate achievements earned by people in your raid." -- Requires localization
L["Congratulate achievements earned by people near you."] = "Congratulate achievements earned by people near you." -- Requires localization
L["Congratulations Messages"] = "Congratulations Messages" -- Requires localization
L["conquest"] = "conquest" -- Requires localization
L["  Conquest Points\
"] = "  Conquest Points\
" -- Requires localization
L["Cooking"] = "Cooking" -- Requires localization
L["copper"] = "copper" -- Requires localization
L["cp"] = "cp" -- Requires localization
L["cpcap"] = "cpcap" -- Requires localization
L["Crap Cleaner"] = "Crap Cleaner" -- Requires localization
L["Creates a button to click that will return you to the bottom of the chat frame."] = "Creates a button to click that will return you to the bottom of the chat frame." -- Requires localization
L["Custom chat filters."] = "Custom chat filters." -- Requires localization
L["Custom Chat Filters"] = "Custom Chat Filters" -- Requires localization
L["Custom color"] = "Custom color" -- Requires localization
L["Custom Emote: |cffffff00%s|r"] = "Custom Emote: |cffffff00%s|r" -- Requires localization
L["Custom Emotes"] = "Custom Emotes" -- Requires localization
L["Custom format (advanced)"] = "Custom format (advanced)" -- Requires localization
L["Damage Meters"] = "Damage Meters" -- Requires localization
L["Death Knight"] = "Death Knight" -- Requires localization
L["Default font face for the chat frames."] = "Default font face for the chat frames." -- Requires localization
L["Default font outline for the chat frames."] = "Default font outline for the chat frames." -- Requires localization
L["Default font size for the chat frames."] = "Default font size for the chat frames." -- Requires localization
L["Default Name Color"] = "Default Name Color" -- Requires localization
L["Destroys all your saved class/level data"] = "Destroys all your saved class/level data" -- Requires localization
L["Determines if a chat message is deemed spam, at which point it can be filtered and the person reported."] = "Determines if a chat message is deemed spam, at which point it can be filtered and the person reported." -- Requires localization
L["Developer Tools"] = "Developer Tools" -- Requires localization
L["Ding Messages"] = "Ding Messages" -- Requires localization
L["Disabled"] = "Disabled" -- Requires localization
L["Disable if..."] = "Disable if..." -- Requires localization
L["Disable while you're AFK flagged."] = "Disable while you're AFK flagged." -- Requires localization
L["Disable while you're DND flagged."] = "Disable while you're DND flagged." -- Requires localization
L["Displays reputation numbers and progress in the chat frame."] = "Displays reputation numbers and progress in the chat frame." -- Requires localization
L["DND Messages"] = "DND Messages" -- Requires localization
L["Do Nothing"] = "Do Nothing" -- Requires localization
L["Dont Always Run"] = "Dont Always Run" -- Requires localization
L["Don't Report"] = "Don't Report" -- Requires localization
L["Do you want to automatically remove an item when you meet your quota?"] = "Do you want to automatically remove an item when you meet your quota?" -- Requires localization
L["Druid"] = "Druid" -- Requires localization
L["Editbox History"] = "Editbox History" -- Requires localization
L["ElvUI ChatTweaks"] = "ElvUI ChatTweaks" -- Requires localization
L["ElvUI_ChatTweaks: You need to be level %d to whisper me.  Currently you are level %d!"] = "ElvUI_ChatTweaks: You need to be level %d to whisper me.  Currently you are level %d!" -- Requires localization
L["Emote"] = "Emote" -- Requires localization
L["Emote Filter"] = "Emote Filter" -- Requires localization
L["Emphasize Self"] = "Emphasize Self" -- Requires localization
L["Enable"] = "Enable" -- Requires localization
L["Enable "] = "Enable " -- Requires localization
L["Enabled"] = "Enabled" -- Requires localization
L["Enable Debugging"] = "Enable Debugging" -- Requires localization
L["Enables you to right-click a person's name in chat and set a note on them to be displayed in chat, such as their main character's name.  Can also scan guild notes for character names to display, if no note has been manually set."] = "Enables you to right-click a person's name in chat and set a note on them to be displayed in chat, such as their main character's name.  Can also scan guild notes for character names to display, if no note has been manually set." -- Requires localization
L["Enable this to give the module a percent chance to run to prevent spam/annoyances.  If disabled the module will always congratulate."] = "Enable this to give the module a percent chance to run to prevent spam/annoyances.  If disabled the module will always congratulate." -- Requires localization
L["Enable this to give the module a percent chance to run to prevent spam/annoyances.  If disabled the module will always run."] = "Enable this to give the module a percent chance to run to prevent spam/annoyances.  If disabled the module will always run." -- Requires localization
L["Enable this to give the module a percent chance to run to prevent spam/annoyances.  If disabled the module will always welcome."] = "Enable this to give the module a percent chance to run to prevent spam/annoyances.  If disabled the module will always welcome." -- Requires localization
L["Enable to filter custom emotes made using |cff00ff00/emote|r or |cff00ff00/e|r."] = "Enable to filter custom emotes made using |cff00ff00/emote|r or |cff00ff00/e|r." -- Requires localization
L["Enable to filter standard emotes such as |cff00ff00/dance|r or |cff00ff00/flirt|r."] = "Enable to filter standard emotes such as |cff00ff00/dance|r or |cff00ff00/flirt|r." -- Requires localization
L["Enable various debugging messages to help with errors or undesired functioning."] = "Enable various debugging messages to help with errors or undesired functioning." -- Requires localization
L["Enchanting"] = "Enchanting" -- Requires localization
L["Engineering"] = "Engineering" -- Requires localization
L["Enter a custom time format. See http://www.lua.org/pil/22.1.html for a list of valid formatting symbols."] = "Enter a custom time format. See http://www.lua.org/pil/22.1.html for a list of valid formatting symbols." -- Requires localization
L["Exclude level display for max level characters"] = "Exclude level display for max level characters" -- Requires localization
L["Exclude max levels"] = "Exclude max levels" -- Requires localization
L["Execution Interval"] = "Execution Interval" -- Requires localization
L["Faction Color"] = "Faction Color" -- Requires localization
L["Feasts"] = "Feasts" -- Requires localization
L["Filter"] = "Filter" -- Requires localization
L["Filter achievement message spam!"] = "Filter achievement message spam!" -- Requires localization
L["Filter achievements earned by guildmates."] = "Filter achievements earned by guildmates." -- Requires localization
L["Filter achievements earned by nearby people."] = "Filter achievements earned by nearby people." -- Requires localization
L["Filter AFK/DND auto responses.  This module is compatible with WIM."] = "Filter AFK/DND auto responses.  This module is compatible with WIM." -- Requires localization
L["Filter AFK messages."] = "Filter AFK messages." -- Requires localization
L["Filter annoying phrases in chat."] = "Filter annoying phrases in chat." -- Requires localization
L["Filter by Player Level"] = "Filter by Player Level" -- Requires localization
L["Filter changed channel message."] = "Filter changed channel message." -- Requires localization
L["Filter Color"] = "Filter Color" -- Requires localization
L["Filter DND messages."] = "Filter DND messages." -- Requires localization
L["Filter Entire Line"] = "Filter Entire Line" -- Requires localization
L["Filter Guild Achievements"] = "Filter Guild Achievements" -- Requires localization
L["Filter guild invites."] = "Filter guild invites." -- Requires localization
L["Filter guild recruitment messages in chat."] = "Filter guild recruitment messages in chat." -- Requires localization
L["Filter guild recruitment whispers."] = "Filter guild recruitment whispers." -- Requires localization
L["Filtering Mode"] = "Filtering Mode" -- Requires localization
L["Filter joined channel message."] = "Filter joined channel message." -- Requires localization
L["Filter left channel message."] = "Filter left channel message." -- Requires localization
L["Filter Nearby Achievements"] = "Filter Nearby Achievements" -- Requires localization
L["Filter out raid icons in chat."] = "Filter out raid icons in chat." -- Requires localization
L["Filter Raid Icons"] = "Filter Raid Icons" -- Requires localization
L["Filters"] = "Filters" -- Requires localization
L["Filters guild recruitment spam in whispers or chat.  Can also block guild invites."] = "Filters guild recruitment spam in whispers or chat.  Can also block guild invites." -- Requires localization
L["Filters out Auction House system messages."] = "Filters out Auction House system messages." -- Requires localization
L["Filter spam throttle notices."] = "Filter spam throttle notices." -- Requires localization
L["Filter standard and/or custom emotes."] = "Filter standard and/or custom emotes." -- Requires localization
L["Filters the channel notices."] = "Filters the channel notices." -- Requires localization
L["Filter the Auction Expired message.\
\
|cffffff00%s|r"] = "Filter the Auction Expired message.\
\
|cffffff00%s|r" -- Requires localization
L["Filter the Auction Outbid message.\
\
|cffffff00%s|r"] = "Filter the Auction Outbid message.\
\
|cffffff00%s|r" -- Requires localization
L["Filter the Auction Removed message.\
\
|cffffff00%s|r"] = "Filter the Auction Removed message.\
\
|cffffff00%s|r" -- Requires localization
L["Filter the Auction Sold message.\
\
|cffffff00%s|r"] = "Filter the Auction Sold message.\
\
|cffffff00%s|r" -- Requires localization
L["Filter the Auction Won message.\
\
|cffffff00%s|r"] = "Filter the Auction Won message.\
\
|cffffff00%s|r" -- Requires localization
L["Filter the Bid Accepted message.\
\
|cffffff00%s|r"] = "Filter the Bid Accepted message.\
\
|cffffff00%s|r" -- Requires localization
L["Filter Triggers"] = "Filter Triggers" -- Requires localization
L["Filter whispers based on the sender's level."] = "Filter whispers based on the sender's level." -- Requires localization
L["First message to send.  You can include links.\
\
|cffffffMake sure you hit [ENTER] after you finish typing your message.|r"] = "First message to send.  You can include links.\
\
|cffffffMake sure you hit [ENTER] after you finish typing your message.|r" -- Requires localization
L["Font Face"] = "Font Face" -- Requires localization
L["Font Size"] = "Font Size" -- Requires localization
L["Friends"] = "Friends" -- Requires localization
L["General"] = "General" -- Requires localization
L["ginv"] = "ginv" -- Requires localization
L["ginvite"] = "ginvite" -- Requires localization
L["GInvite Alternate Command"] = "GInvite Alternate Command" -- Requires localization
L["Gives you more flexibility in how you invite people to your group and guild."] = "Gives you more flexibility in how you invite people to your group and guild." -- Requires localization
L["GKick Command"] = "GKick Command" -- Requires localization
L["GKick Target: |cffffff00%s|r"] = "GKick Target: |cffffff00%s|r" -- Requires localization
L["gold"] = "gold" -- Requires localization
L["Gold Calculator"] = "Gold Calculator" -- Requires localization
L["Group"] = "Group" -- Requires localization
L["Group Invite Links"] = "Group Invite Links" -- Requires localization
L["Group Say Command"] = "Group Say Command" -- Requires localization
L["Guild"] = "Guild" -- Requires localization
L["Guild Channel"] = "Guild Channel" -- Requires localization
L["Guild Chat"] = "Guild Chat" -- Requires localization
L["Guild Invite Links"] = "Guild Invite Links" -- Requires localization
L["Guildmates"] = "Guildmates" -- Requires localization
L["Guild Messages"] = "Guild Messages" -- Requires localization
L["Guild Options"] = "Guild Options" -- Requires localization
L["Guild Spam"] = "Guild Spam" -- Requires localization
L["health"] = "health" -- Requires localization
L["Here you can select which channels this module will scan for the keygroupWords to trigger the invite."] = "Here you can select which channels this module will scan for the keygroupWords to trigger the invite." -- Requires localization
L["HH:MM (12-hour)"] = "HH:MM (12-hour)" -- Requires localization
L["HH:MM (24-hour)"] = "HH:MM (24-hour)" -- Requires localization
L["HH:MM:SS (24-hour)"] = "HH:MM:SS (24-hour)" -- Requires localization
L["HH:MM:SS AM (12-hour)"] = "HH:MM:SS AM (12-hour)" -- Requires localization
L["Hide the spam blocked message asking you to report the person."] = "Hide the spam blocked message asking you to report the person." -- Requires localization
L["Highlight Color"] = "Highlight Color" -- Requires localization
L["honor"] = "honor" -- Requires localization
L["  Honor Points\
"] = "  Honor Points\
" -- Requires localization
L["honour"] = "honour" -- Requires localization
L["Hook the GameTooltip to add information to pet tooltips."] = "Hook the GameTooltip to add information to pet tooltips." -- Requires localization
L["Hook Tooltip"] = "Hook Tooltip" -- Requires localization
L["How to filter any matches."] = "How to filter any matches." -- Requires localization
L["Hunter"] = "Hunter" -- Requires localization
L["I am |cff1784d1%s|r"] = "I am |cff1784d1%s|r" -- Requires localization
L["Icon Action"] = "Icon Action" -- Requires localization
L["Icon Orientation"] = "Icon Orientation" -- Requires localization
L["Icon Size"] = "Icon Size" -- Requires localization
L["Icon to the left or right of the item link."] = "Icon to the left or right of the item link." -- Requires localization
L["Identify Chat Frames"] = "Identify Chat Frames" -- Requires localization
L["If no name can be found for an 'alt' rank character, use entire note"] = "If no name can be found for an 'alt' rank character, use entire note" -- Requires localization
L["Improved Auction Messages"] = "Improved Auction Messages" -- Requires localization
L["Improve the Auction Expired message.\
\
|cffffff00%s|r"] = "Improve the Auction Expired message.\
\
|cffffff00%s|r" -- Requires localization
L["Improve the Auction Outbid message.\
\
|cffffff00%s|r"] = "Improve the Auction Outbid message.\
\
|cffffff00%s|r" -- Requires localization
L["Improve the Auction Removed message.\
\
|cffffff00%s|r"] = "Improve the Auction Removed message.\
\
|cffffff00%s|r" -- Requires localization
L["Improve the Auction Sold message.\
\
|cffffff00%s|r"] = "Improve the Auction Sold message.\
\
|cffffff00%s|r" -- Requires localization
L["Improve the Auction Won message.\
\
|cffffff00%s|r"] = "Improve the Auction Won message.\
\
|cffffff00%s|r" -- Requires localization
L["Include level"] = "Include level" -- Requires localization
L["Include the player's level"] = "Include the player's level" -- Requires localization
L["In Command"] = "In Command" -- Requires localization
L["Inscription"] = "Inscription" -- Requires localization
L["inv"] = "inv" -- Requires localization
L["invite"] = "invite" -- Requires localization
L["Invite Links"] = "Invite Links" -- Requires localization
L["Invites"] = "Invites" -- Requires localization
L[" is loaded. Type |cff1784d1/ct|r if you need help."] = " is loaded. Type |cff1784d1/ct|r if you need help." -- Requires localization
L[" isn't a number."] = " isn't a number." -- Requires localization
L[" isn't a recognized variable or number."] = " isn't a recognized variable or number." -- Requires localization
L["Jewelcrafting"] = "Jewelcrafting" -- Requires localization
L["Joined Channel"] = "Joined Channel" -- Requires localization
L["jp"] = "jp" -- Requires localization
L["jpcap"] = "jpcap" -- Requires localization
L["justice"] = "justice" -- Requires localization
L["  Justice Points\
"] = "  Justice Points\
" -- Requires localization
L["Keeps your channel colors by name rather than by number."] = "Keeps your channel colors by name rather than by number." -- Requires localization
L["Keybinds"] = "Keybinds" -- Requires localization
L["Leatherworking"] = "Leatherworking" -- Requires localization
L["Left"] = "Left" -- Requires localization
L["Left Bracket"] = "Left Bracket" -- Requires localization
L["Left Channel"] = "Left Channel" -- Requires localization
L["Lets you alt-click player names to invite them to your party."] = "Lets you alt-click player names to invite them to your party." -- Requires localization
L["Lets you set the justification of text in your chat frames."] = "Lets you set the justification of text in your chat frames." -- Requires localization
L["Level: |cffffff00%s|r, Message: |cffffff00%s|r"] = "Level: |cffffff00%s|r, Message: |cffffff00%s|r" -- Requires localization
L["Level Location"] = "Level Location" -- Requires localization
L["Level wasn't a number, tell Lockslap. Level was |cffff0000%s|r!"] = "Level wasn't a number, tell Lockslap. Level was |cffff0000%s|r!" -- Requires localization
L["Link All Professions"] = "Link All Professions" -- Requires localization
L["Link Types"] = "Link Types" -- Requires localization
L["Look in guildnotes for character names, unless a note is set manually"] = "Look in guildnotes for character names, unless a note is set manually" -- Requires localization
L["Loot Icons"] = "Loot Icons" -- Requires localization
L["Loss Color"] = "Loss Color" -- Requires localization
L["Mage"] = "Mage" -- Requires localization
L["mana"] = "mana" -- Requires localization
L["Mass Ressurection"] = "Mass Ressurection" -- Requires localization
L["Material Quantities"] = "Material Quantities" -- Requires localization
L["Materials Farming"] = "Materials Farming" -- Requires localization
L["Materials to Track"] = "Materials to Track" -- Requires localization
L["Maximum Delay"] = "Maximum Delay" -- Requires localization
L["Maximum time, in seconds, to wait before announcing."] = "Maximum time, in seconds, to wait before announcing." -- Requires localization
L["Maximum time, in seconds, to wait before bidding someone farewell."] = "Maximum time, in seconds, to wait before bidding someone farewell." -- Requires localization
L["Maximum time, in seconds, to wait before congratulating someone."] = "Maximum time, in seconds, to wait before congratulating someone." -- Requires localization
L["Maximum time, in seconds, to wait before welcoming someone."] = "Maximum time, in seconds, to wait before welcoming someone." -- Requires localization
L["Maximum time, in seconds, to wait before whispering someone the link."] = "Maximum time, in seconds, to wait before whispering someone the link." -- Requires localization
L["Message color."] = "Message color." -- Requires localization
L["Message Color"] = "Message Color" -- Requires localization
L["Message highlight color."] = "Message highlight color." -- Requires localization
L["Message Settings"] = "Message Settings" -- Requires localization
L["Messages for when multiple people complete achievements.  A random one will always be selected.\
\
|cffff0000Wildcards do not apply for multiple achievements.|r"] = "Messages for when multiple people complete achievements.  A random one will always be selected.\
\
|cffff0000Wildcards do not apply for multiple achievements.|r" -- Requires localization
L["Messages for when someone completes an achievement.  A random one will always be selected.\
\
|cffFA6400Wildcards|r\
|cff00ff00#name#|r  - Name of the person.\
|cff00ff00#achieve#|r - Achievement they completed."] = "Messages for when someone completes an achievement.  A random one will always be selected.\
\
|cffFA6400Wildcards|r\
|cff00ff00#name#|r  - Name of the person.\
|cff00ff00#achieve#|r - Achievement they completed." -- Requires localization
L["Messages to use in guild chat when someone leaves your guild.\
\
|cffFA6400Wildcards|r\
|cff00ff00#name#|r - Person who left.\
|cff00ff00#guild#|r - Name of your guild."] = "Messages to use in guild chat when someone leaves your guild.\
\
|cffFA6400Wildcards|r\
|cff00ff00#name#|r - Person who left.\
|cff00ff00#guild#|r - Name of your guild." -- Requires localization
L["Messages to use in the whisper when someone leaves your guild.\
\
|cffFA6400Wildcards|r\
|cff00ff00#name#|r - Person who left.\
|cff00ff00#guild#|r - Name of your guild."] = "Messages to use in the whisper when someone leaves your guild.\
\
|cffFA6400Wildcards|r\
|cff00ff00#name#|r - Person who left.\
|cff00ff00#guild#|r - Name of your guild." -- Requires localization
L["Messages to use when someone joins your guild.\
\
|cffFA6400Wildcards|r\
|cff00ff00#name#|r - Person who joined.\
|cff00ff00#guild#|r - Name of your guild."] = "Messages to use when someone joins your guild.\
\
|cffFA6400Wildcards|r\
|cff00ff00#name#|r - Person who joined.\
|cff00ff00#guild#|r - Name of your guild." -- Requires localization
L["Messages to use when someone says \"ding\".\
\
|cffFA6400Wildcards|r\
|cff00ff00#name#|r - Who said ding.\
|cff00ff00#guild#|r - Their current level."] = "Messages to use when someone says \"ding\".\
\
|cffFA6400Wildcards|r\
|cff00ff00#name#|r - Who said ding.\
|cff00ff00#guild#|r - Their current level." -- Requires localization
L["Method by which to send the messages.\
\
|cffff00Alternate is alternating between the two messages.\
Combined is both messages at once.\
Random will randomly pick one of the messages to send.|r"] = "Method by which to send the messages.\
\
|cffff00Alternate is alternating between the two messages.\
Combined is both messages at once.\
Random will randomly pick one of the messages to send.|r" -- Requires localization
L["Minimum Delay"] = "Minimum Delay" -- Requires localization
L["Minimum DK Level"] = "Minimum DK Level" -- Requires localization
L["Minimum Level"] = "Minimum Level" -- Requires localization
L["Minimum level for a Death Knight to be in order to whisper you."] = "Minimum level for a Death Knight to be in order to whisper you." -- Requires localization
L["Minimum level for a non-Death Knight to be in order to whisper you."] = "Minimum level for a non-Death Knight to be in order to whisper you." -- Requires localization
L["Minimum level required for an achievement to not be filtered."] = "Minimum level required for an achievement to not be filtered." -- Requires localization
L["Minimum time, in seconds, to wait before announcing."] = "Minimum time, in seconds, to wait before announcing." -- Requires localization
L["Minimum time, in seconds, to wait before bidding someone farewell."] = "Minimum time, in seconds, to wait before bidding someone farewell." -- Requires localization
L["Minimum time, in seconds, to wait before congratulating someone."] = "Minimum time, in seconds, to wait before congratulating someone." -- Requires localization
L["Minimum time, in seconds, to wait before welcoming someone."] = "Minimum time, in seconds, to wait before welcoming someone." -- Requires localization
L["Minimum time, in seconds, to wait before whispering someone the link."] = "Minimum time, in seconds, to wait before whispering someone the link." -- Requires localization
L["MM:SS"] = "MM:SS" -- Requires localization
L["Module"] = "Module" -- Requires localization
L["Monitor guild chat."] = "Monitor guild chat." -- Requires localization
L["Monitor party chat."] = "Monitor party chat." -- Requires localization
L["Monitor raid chat."] = "Monitor raid chat." -- Requires localization
L["Monitor say chat."] = "Monitor say chat." -- Requires localization
L["Monitor text in this channel for link triggers."] = "Monitor text in this channel for link triggers." -- Requires localization
L["Monitor whispers."] = "Monitor whispers." -- Requires localization
L["Monitor yell chat."] = "Monitor yell chat." -- Requires localization
L["Monster Emote"] = "Monster Emote" -- Requires localization
L["Monster Say"] = "Monster Say" -- Requires localization
L["Multiple Achievement Messages"] = "Multiple Achievement Messages" -- Requires localization
L["Name"] = "Name" -- Requires localization
L["Name color"] = "Name color" -- Requires localization
L["Nearby People"] = "Nearby People" -- Requires localization
L["New Version Notify"] = "New Version Notify" -- Requires localization
L["No custom emotes are currently being used."] = "No custom emotes are currently being used." -- Requires localization
L["None"] = "None" -- Requires localization
L["No RealNames"] = "No RealNames" -- Requires localization
L["NoTarget"] = "NoTarget" -- Requires localization
L["Notifies the raid/party when someone places down a feast, cauldron, or repair bot."] = "Notifies the raid/party when someone places down a feast, cauldron, or repair bot." -- Requires localization
L["Notify on Filter"] = "Notify on Filter" -- Requires localization
L["Notify on new release?"] = "Notify on new release?" -- Requires localization
L["Notify you when a message is filtered."] = "Notify you when a message is filtered." -- Requires localization
L["Notify you when a message/whisper is filtered."] = "Notify you when a message/whisper is filtered." -- Requires localization
L["Not tracking %s."] = "Not tracking %s." -- Requires localization
L["Numbered Channels"] = "Numbered Channels" -- Requires localization
L["Officer"] = "Officer" -- Requires localization
L["Officer Channel"] = "Officer Channel" -- Requires localization
L["Officer Chat"] = "Officer Chat" -- Requires localization
L["One or more of the changes you have made require you to reload your UI."] = "One or more of the changes you have made require you to reload your UI." -- Requires localization
L["Only filter achievements earned by players below a certain level."] = "Only filter achievements earned by players below a certain level." -- Requires localization
L["Only make these announcements if you are a raid assistant."] = "Only make these announcements if you are a raid assistant." -- Requires localization
L["Opens configuration window."] = "Opens configuration window." -- Requires localization
L["Other Channels"] = "Other Channels" -- Requires localization
L["Ouput Frame"] = "Ouput Frame" -- Requires localization
L["Outline"] = "Outline" -- Requires localization
L["Output Color"] = "Output Color" -- Requires localization
L["Output color of the rerouted messages."] = "Output color of the rerouted messages." -- Requires localization
L["Output Frame"] = "Output Frame" -- Requires localization
L["Output Message Every..."] = "Output Message Every..." -- Requires localization
L["Output the message every X times you gain XP."] = "Output the message every X times you gain XP." -- Requires localization
L["Paladin"] = "Paladin" -- Requires localization
L["Parameter: |cffffff00%s|r"] = "Parameter: |cffffff00%s|r" -- Requires localization
L["Party"] = "Party" -- Requires localization
L["Party Channel"] = "Party Channel" -- Requires localization
L["Party Leader"] = "Party Leader" -- Requires localization
L["Party Members"] = "Party Members" -- Requires localization
L["Percent Chance"] = "Percent Chance" -- Requires localization
L["Perhaps you meant '*' (multiplication)?"] = "Perhaps you meant '*' (multiplication)?" -- Requires localization
L["Pet Battle Info"] = "Pet Battle Info" -- Requires localization
L["Pet Battles"] = "Pet Battles" -- Requires localization
L["Pet Combat Log"] = "Pet Combat Log" -- Requires localization
L["Place the level before or after the player's name."] = "Place the level before or after the player's name." -- Requires localization
L["Player Level"] = "Player Level" -- Requires localization
L["Player level display options."] = "Player level display options." -- Requires localization
L["Player Names"] = "Player Names" -- Requires localization
L["Plays a sound, of your choosing (via LibSharedMedia-3.0), whenever a message is received in a given channel."] = "Plays a sound, of your choosing (via LibSharedMedia-3.0), whenever a message is received in a given channel." -- Requires localization
L["Please DON'T use this. Reporting the spam is what gets the hacked accounts used by\
the spammers closed down and realms cleaned up. Also, if many people report a spammer,\
then that spammer looses the ability to chat meaning they can no longer spam, this benefits\
everyone."] = "Please DON'T use this. Reporting the spam is what gets the hacked accounts used by\
the spammers closed down and realms cleaned up. Also, if many people report a spammer,\
then that spammer looses the ability to chat meaning they can no longer spam, this benefits\
everyone." -- Requires localization
L["power"] = "power" -- Requires localization
L["Priest"] = "Priest" -- Requires localization
L["Print Addon Version"] = "Print Addon Version" -- Requires localization
L["Prints a message in the chat with your remain XP needed to level up."] = "Prints a message in the chat with your remain XP needed to level up." -- Requires localization
L["Prints module status."] = "Prints module status." -- Requires localization
L["Print this again."] = "Print this again." -- Requires localization
L["Provides a |cff00ff00/gkick|r command, as it should be."] = "Provides a |cff00ff00/gkick|r command, as it should be." -- Requires localization
L["Provides a few tools to help me (Lockslap), develop this addon as well as diagnose and fix any errors that are reported.\
\
|cff00ff00You can leave this addon disabled unless I (Lockslap) ask you to enable it for some debugging.|r"] = "Provides a few tools to help me (Lockslap), develop this addon as well as diagnose and fix any errors that are reported.\
\
|cff00ff00You can leave this addon disabled unless I (Lockslap) ask you to enable it for some debugging.|r" -- Requires localization
L["Provides a /gr slash command to let you speak in your group (raid, party, or battleground) automatically."] = "Provides a /gr slash command to let you speak in your group (raid, party, or battleground) automatically." -- Requires localization
L["Provides a /in command to delay the execution of code in macros and other settings."] = "Provides a /in command to delay the execution of code in macros and other settings." -- Requires localization
L["Provides |cff00ff00/ginv|r, an alternative to |cff00ff00/ginvite|r command, for us lazy folks."] = "Provides |cff00ff00/ginv|r, an alternative to |cff00ff00/ginvite|r command, for us lazy folks." -- Requires localization
L["Provides keybinds to make talking in a specific chat easier."] = "Provides keybinds to make talking in a specific chat easier." -- Requires localization
L["Provides options to color player names, add player levels, and add tab completion of player names."] = "Provides options to color player names, add player levels, and add tab completion of player names." -- Requires localization
L["Put each emote on a separate line.\
Separate the command from the text with a colon (\":\")."] = "Put each emote on a separate line.\
Separate the command from the text with a colon (\":\")." -- Requires localization
L["Quality Notification"] = "Quality Notification" -- Requires localization
L["Raid"] = "Raid" -- Requires localization
L["Raid Assistant"] = "Raid Assistant" -- Requires localization
L["Raid Boss Emote"] = "Raid Boss Emote" -- Requires localization
L["Raid Channel"] = "Raid Channel" -- Requires localization
L["Raid Helper"] = "Raid Helper" -- Requires localization
L["Raid Leader"] = "Raid Leader" -- Requires localization
L["Raid Members"] = "Raid Members" -- Requires localization
L["Raid Warning"] = "Raid Warning" -- Requires localization
L["Raid Warning Channel"] = "Raid Warning Channel" -- Requires localization
L["Random"] = "Random" -- Requires localization
L["RANDOM"] = "RANDOM" -- Requires localization
L["RealID Brackets"] = "RealID Brackets" -- Requires localization
L["RealID Conversation"] = "RealID Conversation" -- Requires localization
L["RealID Whisper"] = "RealID Whisper" -- Requires localization
L["Really remove this word from your trigger list?"] = "Really remove this word from your trigger list?" -- Requires localization
L["Remembers the history of the editbox across sessions."] = "Remembers the history of the editbox across sessions." -- Requires localization
L["Remove"] = "Remove" -- Requires localization
L["Remove a word from your group invite trigger list"] = "Remove a word from your group invite trigger list" -- Requires localization
L["Remove a word from your guild invite trigget list."] = "Remove a word from your guild invite trigget list." -- Requires localization
L["Remove Group Trigger"] = "Remove Group Trigger" -- Requires localization
L["Remove Guild Trigger"] = "Remove Guild Trigger" -- Requires localization
L["Remove Icon Only"] = "Remove Icon Only" -- Requires localization
L[", removing from list"] = ", removing from list" -- Requires localization
L["Repair Bot"] = "Repair Bot" -- Requires localization
L["Repeat Command"] = "Repeat Command" -- Requires localization
L["Replace"] = "Replace" -- Requires localization
L["Reported by %s"] = "Reported by %s" -- Requires localization
L["Reputation"] = "Reputation" -- Requires localization
L["Reputation Color"] = "Reputation Color" -- Requires localization
L["Reroute Auction Messages"] = "Reroute Auction Messages" -- Requires localization
L["Reset"] = "Reset" -- Requires localization
L["Reset ChatFrame text justifications to defaults (left)."] = "Reset ChatFrame text justifications to defaults (left)." -- Requires localization
L["Reset Data"] = "Reset Data" -- Requires localization
L["Reset Font Data"] = "Reset Font Data" -- Requires localization
L["Reset Materials"] = "Reset Materials" -- Requires localization
L["Resets all chat frames to their original font settings."] = "Resets all chat frames to their original font settings." -- Requires localization
L["Reset Text Justitification"] = "Reset Text Justitification" -- Requires localization
L["Respond to Whispers"] = "Respond to Whispers" -- Requires localization
L["Respond to whispers notifying them that they don't meet the level requirement."] = "Respond to whispers notifying them that they don't meet the level requirement." -- Requires localization
L["Right"] = "Right" -- Requires localization
L["Right Bracket"] = "Right Bracket" -- Requires localization
L["Ritual of Refreshment"] = "Ritual of Refreshment" -- Requires localization
L["Ritual of Souls"] = "Ritual of Souls" -- Requires localization
L["Ritual of Summoning"] = "Ritual of Summoning" -- Requires localization
L["Rogue"] = "Rogue" -- Requires localization
L["Roll Color"] = "Roll Color" -- Requires localization
L["Roll Pattern: |cffffff00%s|r"] = "Roll Pattern: |cffffff00%s|r" -- Requires localization
L["Save all /who data"] = "Save all /who data" -- Requires localization
L["Save class data from friends between sessions."] = "Save class data from friends between sessions." -- Requires localization
L["Save class data from groups between sessions."] = "Save class data from groups between sessions." -- Requires localization
L["Save class data from guild between sessions."] = "Save class data from guild between sessions." -- Requires localization
L["Save class data from target/mouseover between sessions."] = "Save class data from target/mouseover between sessions." -- Requires localization
L["Save class data from /who queries between sessions."] = "Save class data from /who queries between sessions." -- Requires localization
L["Save Data"] = "Save Data" -- Requires localization
L["Save data between sessions. Will increase memory usage"] = "Save data between sessions. Will increase memory usage" -- Requires localization
L["Say"] = "Say" -- Requires localization
L["Say Chat"] = "Say Chat" -- Requires localization
L["%s  Conquest Cap\
"] = "%s  Conquest Cap\
" -- Requires localization
L["Scroll Reminder"] = "Scroll Reminder" -- Requires localization
L["Second message to send.  You can include links.\
\
|cffffffMake sure you hit [ENTER] after you finish typing your message.|r"] = "Second message to send.  You can include links.\
\
|cffffffMake sure you hit [ENTER] after you finish typing your message.|r" -- Requires localization
L["Select a color for this channel."] = "Select a color for this channel." -- Requires localization
L["Select a method for coloring player names"] = "Select a method for coloring player names" -- Requires localization
L["Select the custom color to use for alt names"] = "Select the custom color to use for alt names" -- Requires localization
L["Select which factions you would like to receive notifications for."] = "Select which factions you would like to receive notifications for." -- Requires localization
L["Send a tell to your target."] = "Send a tell to your target." -- Requires localization
L["Send a whisper to the person who left."] = "Send a whisper to the person who left." -- Requires localization
L["Send Guild Messages"] = "Send Guild Messages" -- Requires localization
L["Send messages as a raid warning.  |cffffff00Only applies if you are the raid leader, or an assistant.|r"] = "Send messages as a raid warning.  |cffffff00Only applies if you are the raid leader, or an assistant.|r" -- Requires localization
L["Send messages to guild chat when someone leaves."] = "Send messages to guild chat when someone leaves." -- Requires localization
L["Send Whisper"] = "Send Whisper" -- Requires localization
L["Separator"] = "Separator" -- Requires localization
L["Set Main"] = "Set Main" -- Requires localization
L["Set the coloring mode for alt names"] = "Set the coloring mode for alt names" -- Requires localization
L["Settings"] = "Settings" -- Requires localization
L["%s from |cff00ff00%s|r was blocked."] = "%s from |cff00ff00%s|r was blocked." -- Requires localization
L["Shaman"] = "Shaman" -- Requires localization
L["%s has casted %s."] = "%s has casted %s." -- Requires localization
L["%s has prepared a %s."] = "%s has prepared a %s." -- Requires localization
L["%s has put down a %s."] = "%s has put down a %s." -- Requires localization
L["Show a report player popup (showing the spam) instead of printing in chat"] = "Show a report player popup (showing the spam) instead of printing in chat" -- Requires localization
L["Show current to total XP percentage."] = "Show current to total XP percentage." -- Requires localization
L["Show Percentage"] = "Show Percentage" -- Requires localization
L["Show remaining rested XP."] = "Show remaining rested XP." -- Requires localization
L["Show Rested XP"] = "Show Rested XP" -- Requires localization
L["Show Spam Popup"] = "Show Spam Popup" -- Requires localization
L["Show toon names instead of real names"] = "Show toon names instead of real names" -- Requires localization
L["Show Total XP"] = "Show Total XP" -- Requires localization
L["Show total XP needed to level."] = "Show total XP needed to level." -- Requires localization
L["Show welcome message when logging in."] = "Show welcome message when logging in." -- Requires localization
L["silver"] = "silver" -- Requires localization
L["Similar to the |cffffffIn Command|r module, except it will repeat the command X times."] = "Similar to the |cffffffIn Command|r module, except it will repeat the command X times." -- Requires localization
L["%s is casting %s.  Click!"] = "%s is casting %s.  Click!" -- Requires localization
L["Size of the coin icons.  Generally you want to use your font size or smaller."] = "Size of the coin icons.  Generally you want to use your font size or smaller." -- Requires localization
L["%s  Justice Cap\
"] = "%s  Justice Cap\
" -- Requires localization
L["Smart Group Channel"] = "Smart Group Channel" -- Requires localization
L["%s or %s"] = "%s or %s" -- Requires localization
L["Sound to play when a message in %s is received.\
\
|cff00ff00To disable set to \"None\"|r."] = "Sound to play when a message in %s is received.\
\
|cff00ff00To disable set to \"None\"|r." -- Requires localization
L["Spam Delay"] = "Spam Delay" -- Requires localization
L["Spam Filter"] = "Spam Filter" -- Requires localization
L["Spam Interval"] = "Spam Interval" -- Requires localization
L["Spam interval changed to |cffffff00%d|r"] = "Spam interval changed to |cffffff00%d|r" -- Requires localization
L["Spam Mode"] = "Spam Mode" -- Requires localization
L["Spam Throttle"] = "Spam Throttle" -- Requires localization
L["%s reputation left until %s with %s."] = "%s reputation left until %s with %s." -- Requires localization
L["%s reputation needed until %s with %s."] = "%s reputation needed until %s with %s." -- Requires localization
L["%s, %s, %s  Player's Money\
"] = "%s, %s, %s  Player's Money\
" -- Requires localization
L["%s, %s, %s  Player's Stats\
"] = "%s, %s, %s  Player's Stats\
" -- Requires localization
L["Standard Emote: |cffffff00%s|r"] = "Standard Emote: |cffffff00%s|r" -- Requires localization
L["Standard Emotes"] = "Standard Emotes" -- Requires localization
L["Standing Color"] = "Standing Color" -- Requires localization
L["Start"] = "Start" -- Requires localization
L["STARTED"] = "STARTED" -- Requires localization
L["Stop"] = "Stop" -- Requires localization
L["STOPPED"] = "STOPPED" -- Requires localization
L["Strip Links"] = "Strip Links" -- Requires localization
L["Strip RealID brackets"] = "Strip RealID brackets" -- Requires localization
L["Suppress"] = "Suppress" -- Requires localization
L["Suppress Recount/Skada/TinyDPS output into a clickable link, or filter it entirely."] = "Suppress Recount/Skada/TinyDPS output into a clickable link, or filter it entirely." -- Requires localization
L["Suppress report message."] = "Suppress report message." -- Requires localization
L["%s  Valor Cap\
"] = "%s  Valor Cap\
" -- Requires localization
L["Symbol: |cffffff00%s|r"] = "Symbol: |cffffff00%s|r" -- Requires localization
L["Tailoring"] = "Tailoring" -- Requires localization
L["Talk to your group based on party/raid status."] = "Talk to your group based on party/raid status." -- Requires localization
L["Target: |cffffff00%s|r"] = "Target: |cffffff00%s|r" -- Requires localization
L["Target/Mouseover"] = "Target/Mouseover" -- Requires localization
L["Tell Target"] = "Tell Target" -- Requires localization
L["Text Justification"] = "Text Justification" -- Requires localization
L["Text justification for ChatFrame %d."] = "Text justification for ChatFrame %d." -- Requires localization
L["The amount of each material you'd like to farm.  If you want an unlimited amount simply put a 0.  You must add a quantity for every entry, and it must correspond to the same line in the other box."] = "The amount of each material you'd like to farm.  If you want an unlimited amount simply put a 0.  You must add a quantity for every entry, and it must correspond to the same line in the other box." -- Requires localization
L["The default color to use to color names."] = "The default color to use to color names." -- Requires localization
L["The interval must be a |cff00ff00%s|r between |cff00ff00%d|r and |cff00ff00%d|r."] = "The interval must be a |cff00ff00%s|r between |cff00ff00%d|r and |cff00ff00%d|r." -- Requires localization
L["The name or ID of the material you'd like to track."] = "The name or ID of the material you'd like to track." -- Requires localization
L["The percent chance the module has to bid someone farewell.  Higher the chance, the more likely it is to run.  This is a means to throttle, so as to prevent spam/annoyances."] = "The percent chance the module has to bid someone farewell.  Higher the chance, the more likely it is to run.  This is a means to throttle, so as to prevent spam/annoyances." -- Requires localization
L["The percent chance the module has to congratulate someone.  Higher the chance, the more likely it is to run.  This is a means to throttle, so as to prevent spam/annoyances."] = "The percent chance the module has to congratulate someone.  Higher the chance, the more likely it is to run.  This is a means to throttle, so as to prevent spam/annoyances." -- Requires localization
L["The percent chance the module has to welcome someone.  Higher the chance, the more likely it is to run.  This is a means to throttle, so as to prevent spam/annoyances."] = "The percent chance the module has to welcome someone.  Higher the chance, the more likely it is to run.  This is a means to throttle, so as to prevent spam/annoyances." -- Requires localization
L["These are the keywords that the addon will look for first, when it finds a match then it will look for the actual profession being requested."] = "These are the keywords that the addon will look for first, when it finds a match then it will look for the actual profession being requested." -- Requires localization
L["The size of the icon in the chat frame."] = "The size of the icon in the chat frame." -- Requires localization
L["The time, in seconds, it takes for the same person to trigger the addon again."] = "The time, in seconds, it takes for the same person to trigger the addon again." -- Requires localization
L["The time, in seconds, it takes for the same person to trigger the addon by saying ding."] = "The time, in seconds, it takes for the same person to trigger the addon by saying ding." -- Requires localization
L["Thick Outline"] = "Thick Outline" -- Requires localization
L["Things to Track"] = "Things to Track" -- Requires localization
L["This addon is designed to add a lot of the functionality of full fledged chat addons like Prat or Chatter, but without a lot of the unneeded bloat.  I wrote it to be as lightweight as possible, while still powerful enough to accomplish it's intended function.\
"] = "This addon is designed to add a lot of the functionality of full fledged chat addons like Prat or Chatter, but without a lot of the unneeded bloat.  I wrote it to be as lightweight as possible, while still powerful enough to accomplish it's intended function.\
" -- Requires localization
L["This module will send a chat message every time you loot an item on your list with how many you have, and if applicable it will tell you how many more you need based on your set quantity.  This is useful if you need X amount of Y to be able to cook Z."] = "This module will send a chat message every time you loot an item on your list with how many you have, and if applicable it will tell you how many more you need based on your set quantity.  This is useful if you need X amount of Y to be able to cook Z." -- Requires localization
L["This will disable the ChatFrames annoying habit of having the chat text fade away after a certain amount of time."] = "This will disable the ChatFrames annoying habit of having the chat text fade away after a certain amount of time." -- Requires localization
L["Throttle Interval"] = "Throttle Interval" -- Requires localization
L["Throttle Messages"] = "Throttle Messages" -- Requires localization
L["Throttle output messages to prevent spam."] = "Throttle output messages to prevent spam." -- Requires localization
L["Time, in seconds, between messages being sent."] = "Time, in seconds, between messages being sent." -- Requires localization
L["Time, in seconds, in between running the command."] = "Time, in seconds, in between running the command." -- Requires localization
L["Time, in seconds, the module will wait after the first line is found to assume it is complete.\
\
|cffffff00One (1) second seems to work.|r"] = "Time, in seconds, the module will wait after the first line is found to assume it is complete.\
\
|cffffff00One (1) second seems to work.|r" -- Requires localization
L["Time, in seconds, to throttle output messages to prevent spam."] = "Time, in seconds, to throttle output messages to prevent spam." -- Requires localization
L["Timer is currently running, you must stop it first before changing the interval."] = "Timer is currently running, you must stop it first before changing the interval." -- Requires localization
L["Timestamp color"] = "Timestamp color" -- Requires localization
L["Timestamp format"] = "Timestamp format" -- Requires localization
L["Timestamps"] = "Timestamps" -- Requires localization
L["TOC Version: |cff1784d1%s|r"] = "TOC Version: |cff1784d1%s|r" -- Requires localization
L["Toggle coloring and change of the chat frame for pet combat log messages."] = "Toggle coloring and change of the chat frame for pet combat log messages." -- Requires localization
L["Toggle coloring and changing of the chat frame for pet battle info messages."] = "Toggle coloring and changing of the chat frame for pet battle info messages." -- Requires localization
L["Toggle the pet quality notifications when you join a wild pet battle."] = "Toggle the pet quality notifications when you join a wild pet battle." -- Requires localization
L["Track Pets"] = "Track Pets" -- Requires localization
L["Track Stable Masters"] = "Track Stable Masters" -- Requires localization
L["Trade"] = "Trade" -- Requires localization
L["Triggers"] = "Triggers" -- Requires localization
L["/tt"] = "/tt" -- Requires localization
L["Unbalanced parameter count. Trailing Symbol: |cffffff00%s|r"] = "Unbalanced parameter count. Trailing Symbol: |cffffff00%s|r" -- Requires localization
L["Unrecognized Symbol: |cffffff00%s|r"] = "Unrecognized Symbol: |cffffff00%s|r" -- Requires localization
L["Unset variable |cffffff00%s|r."] = "Unset variable |cffffff00%s|r." -- Requires localization
L["Use channel color"] = "Use channel color" -- Requires localization
L["Use Channel Color"] = "Use Channel Color" -- Requires localization
L["Use Coins"] = "Use Coins" -- Requires localization
L["Use coins in the answers instead of abbreviations."] = "Use coins in the answers instead of abbreviations." -- Requires localization
L["Use Custom Color"] = "Use Custom Color" -- Requires localization
L["Use guildnotes"] = "Use guildnotes" -- Requires localization
L["Use Level Threshold"] = "Use Level Threshold" -- Requires localization
L["Use PlayerNames Coloring"] = "Use PlayerNames Coloring" -- Requires localization
L["Use Server Time"] = "Use Server Time" -- Requires localization
L["Use server time, rather than local."] = "Use server time, rather than local." -- Requires localization
L["Use Tab Complete"] = "Use Tab Complete" -- Requires localization
L["Use tab key to automatically complete character names."] = "Use tab key to automatically complete character names." -- Requires localization
L["Valid Events"] = "Valid Events" -- Requires localization
L["valor"] = "valor" -- Requires localization
L["  Valor Points\
"] = "  Valor Points\
" -- Requires localization
L["Variable |cffffff00%s|r is set to |cff00ff00%s|r."] = "Variable |cffffff00%s|r is set to |cff00ff00%s|r." -- Requires localization
L["Variable |cffffff00%s|r set to |cff00ff00%s|r."] = "Variable |cffffff00%s|r set to |cff00ff00%s|r." -- Requires localization
L["Various Developer Tools"] = "Various Developer Tools" -- Requires localization
L["Version"] = "Version" -- Requires localization
L["Version: |cff1784d1%s|r"] = "Version: |cff1784d1%s|r" -- Requires localization
L["vp"] = "vp" -- Requires localization
L["vpcap"] = "vpcap" -- Requires localization
L["Warlock"] = "Warlock" -- Requires localization
L["Warrior"] = "Warrior" -- Requires localization
L["Welcome Message"] = "Welcome Message" -- Requires localization
L["Welcome Messages"] = "Welcome Messages" -- Requires localization
L["What to do when a link is found.\
\
|cffffff00Replace:|r  Replaces link with just the text.\
|cffffff00Filter:|r  Filters the line.\
|cffffff00Remove:|r  Removes the link."] = "What to do when a link is found.\
\
|cffffff00Replace:|r  Replaces link with just the text.\
|cffffff00Filter:|r  Filters the line.\
|cffffff00Remove:|r  Removes the link." -- Requires localization
L["What to do with Recount/Skada/TinyDPS reports in this channel."] = "What to do with Recount/Skada/TinyDPS reports in this channel." -- Requires localization
L["    When I first started using ElvUI around the beginning of Cataclysm's release I noticed that there were some chat functionality that I wanted, but wasn't included with ElvUI.  I came across Prat and Chatter, but found that they had too many modules that I didn't want and both addons do use a fair bit of memory.  So I decided to write my own version, which is when ElvUI_ChatTweaks was born.  Since then I have made sure that this addon is as bug free as possible, as well as being up to date with the latest API available, and I am constantly adding new functionality.  If there's any features you'd like to see added please contact me and I'll see what I can do.\
\
Thanks,\
|cffffff00Lockslap|r"] = "    When I first started using ElvUI around the beginning of Cataclysm's release I noticed that there were some chat functionality that I wanted, but wasn't included with ElvUI.  I came across Prat and Chatter, but found that they had too many modules that I didn't want and both addons do use a fair bit of memory.  So I decided to write my own version, which is when ElvUI_ChatTweaks was born.  Since then I have made sure that this addon is as bug free as possible, as well as being up to date with the latest API available, and I am constantly adding new functionality.  If there's any features you'd like to see added please contact me and I'll see what I can do.\
\
Thanks,\
|cffffff00Lockslap|r" -- Requires localization
L["When setting a variable the variable name must be the first parameter."] = "When setting a variable the variable name must be the first parameter." -- Requires localization
L["Whisper"] = "Whisper" -- Requires localization
L["Whisper Filter"] = "Whisper Filter" -- Requires localization
L["Whisper Messages"] = "Whisper Messages" -- Requires localization
L["Whisper Options"] = "Whisper Options" -- Requires localization
L["Whispers"] = "Whispers" -- Requires localization
L["Who"] = "Who" -- Requires localization
L["Who: |cffffff00%s|r, Roll: |cffffff00%s|r, Min: |cffffff00%s|r, Max: |cffffff00%s|r"] = "Who: |cffffff00%s|r, Roll: |cffffff00%s|r, Min: |cffffff00%s|r, Max: |cffffff00%s|r" -- Requires localization
L["Who is %s's main?"] = "Who is %s's main?" -- Requires localization
L["Who to Congratulate?"] = "Who to Congratulate?" -- Requires localization
L["Will save all data for large /who queries"] = "Will save all data for large /who queries" -- Requires localization
L["Win Color"] = "Win Color" -- Requires localization
L["Words or phrases that will trigger the filtering."] = "Words or phrases that will trigger the filtering." -- Requires localization
L["XP Left To Level"] = "XP Left To Level" -- Requires localization
L["Yell"] = "Yell" -- Requires localization
L["Yell Chat"] = "Yell Chat" -- Requires localization
L["You are running version |cff1784d1%s|r."] = "You are running version |cff1784d1%s|r." -- Requires localization
L["You can only send a request once every %d seconds.  You last sent a request at %s."] = "You can only send a request once every %d seconds.  You last sent a request at %s." -- Requires localization
L["You have |cff%s%d|r of %s."] = "You have |cff%s%d|r of %s." -- Requires localization
L["You have |cff%s%d|r of %s, you need |cff%s%d|r more. |cff%s(%d/%d)|r"] = "You have |cff%s%d|r of %s, you need |cff%s%d|r more. |cff%s(%d/%d)|r" -- Requires localization
L["You have met your quota of %s%s. |cff%s(%d/%d)|r"] = "You have met your quota of %s%s. |cff%s(%d/%d)|r" -- Requires localization
L["You have reached the maximum number of friends, please remove 2 for this addon to function properly."] = "You have reached the maximum number of friends, please remove 2 for this addon to function properly." -- Requires localization
L["You must provide a calculation or set a variable."] = "You must provide a calculation or set a variable." -- Requires localization
L["You need %s%s%s%sto hit level %d."] = "You need %s%s%s%sto hit level %d." -- Requires localization
L["Your Color"] = "Your Color" -- Requires localization
L["Your Version: |cffffff00%d|r, Latest Version: |cffffff00%d|r"] = "Your Version: |cffffff00%d|r, Latest Version: |cffffff00%d|r" -- Requires localization
L["Your version of %s is out of date.  Latest version is |cff1784d1%d|r."] = "Your version of %s is out of date.  Latest version is |cff1784d1%d|r." -- Requires localization
