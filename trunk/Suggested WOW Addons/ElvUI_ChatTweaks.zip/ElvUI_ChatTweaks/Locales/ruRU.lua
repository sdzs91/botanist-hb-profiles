-------------------------------------------------------------------------------
-- ElvUI_ChatTweaks By Lockslap (US, Bleeding Hollow)
-- <Borderline Amazing>, http://ba-guild.com
-------------------------------------------------------------------------------
local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("ElvUI_ChatTweaks", "ruRU", false)
if not L then return end

L["About"] = "About" -- Requires localization
L["achieve"] = "achieve" -- Requires localization
L["Achievement Filter"] = "\208\164\208\184\208\187\209\140\209\130\209\128 \208\180\208\190\209\129\209\130\208\184\208\182\208\181\208\189\208\184\208\185" -- Needs review
L["Achievement Messages"] = "\208\161\208\190\208\190\208\177\209\137\208\181\208\189\208\184\209\143 \208\180\208\190\209\129\209\130\208\184\208\182\208\181\208\189\208\184\208\185." -- Needs review
L["  Achievement Points\
"] = "  Achievement Points\
" -- Requires localization
L["Action"] = "Action" -- Requires localization
L["Action to take when an icon is found."] = "Action to take when an icon is found." -- Requires localization
L["Add an |cff00ff00/emotes|r command to see what custom emotes you currently have running."] = "Add an |cff00ff00/emotes|r command to see what custom emotes you currently have running." -- Requires localization
L["Add |cff00ff00/emotes|r Command"] = "Add |cff00ff00/emotes|r Command" -- Requires localization
L["Add custom emotes.  Please remember that your character's name will always be the first word.\
\
|cff00ff00%t|r is your current target."] = "Add custom emotes.  Please remember that your character's name will always be the first word.\
\
|cff00ff00%t|r is your current target." -- Requires localization
L["Add Group Trigger"] = "Add Group Trigger" -- Requires localization
L["Add Guild Trigger"] = "Add Guild Trigger" -- Requires localization
L["Add item icons to loot received messages."] = "Add item icons to loot received messages." -- Requires localization
L["Addon Version Sent, Version: |cffffff00%s|r"] = "Addon Version Sent, Version: |cffffff00%s|r" -- Requires localization
L["Adds a timestamp to each line of text."] = "\208\159\208\190\208\186\208\176\208\183\209\139\208\178\208\176\209\130\209\140 \208\178\209\128\208\181\208\188\209\143 \209\129\208\190\208\190\208\177\209\137\208\181\208\189\208\184\208\185 \208\178 \209\135\208\176\209\130\208\181" -- Needs review
L["Adds chat commands |cff1784d1/chatframes|r and |cff1784d1/cf|r to help you identify the chat frames and their numbers."] = "Adds chat commands |cff1784d1/chatframes|r and |cff1784d1/cf|r to help you identify the chat frames and their numbers." -- Requires localization
L["Adds chat commands to clear the chat windows.\
\
"] = "\208\148\208\190\208\177\208\176\208\178\208\187\209\143\208\181\209\130 \208\186\208\190\208\188\208\176\208\189\208\180\209\139 \209\135\208\176\209\130\208\176 , \209\135\209\130\208\190\208\177\209\139 \208\190\209\135\208\184\209\129\209\130\208\184\209\130\209\140 \208\190\208\186\208\189\208\176 \209\135\208\176\209\130\208\176 .\
" -- Needs review
L["Adds item links to Auction House messages.  Enabling this module will automatically disable the Auction Message Filter module.\
\
|cffff0000If you do not have the item in your bags at the time of the system message firing then this will not be able to get the item link.  This is a limitation of the|r |cffffff00GetItemInfo()|r |cffff0000API function.  If this occurs, then the module will simple pass through the default message.|r"] = "Adds item links to Auction House messages.  Enabling this module will automatically disable the Auction Message Filter module.\
\
|cffff0000If you do not have the item in your bags at the time of the system message firing then this will not be able to get the item link.  This is a limitation of the|r |cffffff00GetItemInfo()|r |cffff0000API function.  If this occurs, then the module will simple pass through the default message.|r" -- Requires localization
L["Adds tell target slash command, |cff00ff00/tt|r."] = "Adds tell target slash command, |cff00ff00/tt|r." -- Requires localization
L["Add surrounding brackets to own charname in messages."] = "\208\148\208\190\208\177\208\176\208\178\208\184\209\130\209\140 \209\129\208\186\208\190\208\177\208\186\208\184 \209\129\208\178\208\190\208\181\208\188\209\131 \208\189\208\184\208\186\209\131 \208\178 \209\129\208\190\208\190\208\177\209\137\208\181\208\189\208\184\209\143\209\133." -- Needs review
L["Add word to your group invite trigger list"] = "Add word to your group invite trigger list" -- Requires localization
L["Add word to your guild invite trigger list."] = "Add word to your guild invite trigger list." -- Requires localization
L["AFK"] = "\208\158\209\130\209\129\209\131\209\130\209\129\209\130\208\178\209\131\208\181\209\130 (\208\144\208\164\208\154)" -- Needs review
L["AFK/DND Filter"] = "AFK/DND Filter" -- Requires localization
L["AFK Messages"] = "AFK Messages" -- Requires localization
L["After"] = "\208\159\208\190\209\129\208\187\208\181" -- Needs review
L["Alchemy"] = "\208\144\208\187\209\133\208\184\208\188\208\184\209\143" -- Needs review
L["All"] = "\208\146\209\129\208\181" -- Needs review
L["Allow someone to request a link of all your professions."] = "Allow someone to request a link of all your professions." -- Requires localization
L["Allows you to change the default font settings for the chat frames.\
\
|cffff0000Using another addon to do this will break this functionality.|r"] = "\208\159\208\190\208\183\208\178\208\190\208\187\209\143\208\181\209\130 \208\184\208\183\208\188\208\181\208\189\208\184\209\130\209\140 \209\136\209\128\208\184\209\132\209\130 \208\191\208\190 \209\131\208\188\208\190\208\187\209\135\208\176\208\189\208\184\209\142 \208\180\208\187\209\143 \208\190\208\186\208\189\208\176 \209\135\208\176\209\130\208\176.\
|cffff0000\208\152\209\129\208\191\208\190\208\187\209\140\208\183\208\190\208\178\208\176\208\189\208\184\208\181 \208\180\209\128\209\131\208\179\208\190\208\179\208\190 \208\176\208\180\208\180\208\190\208\189\208\176 \208\189\208\176\209\128\209\131\209\136\208\184\209\130 \209\141\209\130\209\131 \209\132\209\131\208\189\208\186\209\134\208\184\208\190\208\189\208\176\208\187\209\140\208\189\208\190\209\129\209\130\209\140 .|r\
" -- Needs review
L["Allows you to color the pet battle info messages, and determine which chat frame to send them to.\
\
I am aware that some of the features of this module don't really pertain to the chat, but I couldn't really justify an entirely new addon.  So I just snuck them into here."] = "Allows you to color the pet battle info messages, and determine which chat frame to send them to.\
\
I am aware that some of the features of this module don't really pertain to the chat, but I couldn't really justify an entirely new addon.  So I just snuck them into here." -- Requires localization
L["Allows you to filter certain words or phrases using Lua's pattern matching. For an item, achievement, spell, etc. just use the name of the item, don't try to link it.\
\
For more information see this addon's Curse or WoWInterface page."] = "\208\159\208\190\208\183\208\178\208\190\208\187\209\143\208\181\209\130 \209\132\208\184\208\187\209\140\209\130\209\128\208\190\208\178\208\176\209\130\209\140 \208\190\208\191\209\128\208\181\208\180\208\181\208\187\208\181\208\189\208\189\209\139\208\181 \209\129\208\187\208\190\208\178\208\176 \208\184\208\187\208\184 \209\132\209\128\208\176\208\183\209\139 \208\191\208\190 \209\136\208\176\208\177\208\187\208\190\208\189\209\131 \208\155\209\131\208\176. \208\148\208\187\209\143 \208\190\208\177\209\138\208\181\208\186\209\130\208\176, \208\180\208\190\209\129\209\130\208\184\208\182\208\181\208\189\208\184\209\143, \208\183\208\176\208\186\208\187\208\184\208\189\208\176\208\189\208\184\209\143 \208\184 \209\130.\208\191. \208\191\209\128\208\190\209\129\209\130\208\190 \208\184\209\129\208\191\208\190\208\187\209\140\208\183\208\190\208\178\208\176\209\130\209\140 \208\184\208\188\209\143 \209\141\208\187\208\181\208\188\208\181\208\189\209\130\208\176, \208\189\208\181 \208\191\209\139\209\130\208\176\208\185\209\130\208\181\209\129\209\140 \209\129\208\178\209\143\208\183\208\176\209\130\209\140 \208\181\208\179\208\190. \208\148\208\187\209\143 \208\191\208\190\208\187\209\131\209\135\208\181\208\189\208\184\209\143 \208\180\208\190\208\191\208\190\208\187\208\189\208\184\209\130\208\181\208\187\209\140\208\189\208\190\208\185 \208\184\208\189\209\132\208\190\209\128\208\188\208\176\209\134\208\184\208\184 \209\129\208\188. \208\159\209\128\208\190\208\186\208\187\209\143\209\130\208\184\208\181 \209\141\209\130\208\190\209\130 \208\176\208\180\208\180\208\190\208\189 \208\184\208\187\208\184 WoWInterface \209\129\209\130\209\128\208\176\208\189\208\184\209\134\209\139." -- Needs review
L["Allows you to reroute auction house messages to a different chat frame."] = "Allows you to reroute auction house messages to a different chat frame." -- Requires localization
L["Allows you to spam a message to General or Trade chat every X seconds.  Useful for guild recruitment or profession links."] = "Allows you to spam a message to General or Trade chat every X seconds.  Useful for guild recruitment or profession links." -- Requires localization
L["Allows you to strip certain links from channels of your choice."] = "Allows you to strip certain links from channels of your choice." -- Requires localization
L["alt2"] = true -- Needs review
L["alt3"] = true -- Needs review
L["Alt-click name to invite"] = "Alt-\208\186\208\187\208\184\208\186 \208\191\208\190 \208\184\208\188\208\181\208\189\208\184, \209\135\209\130\208\190 \208\177\209\139 \208\191\209\128\208\184\208\179\208\187\208\176\209\129\208\184\209\130\209\140" -- Needs review
L["Alternate"] = "Alternate" -- Requires localization
L["ALTERNATE"] = "ALTERNATE" -- Requires localization
L["Alternate command to kick someone from guild."] = "\208\144\208\187\209\140\209\130\208\181\209\128\208\189\208\176\209\130\208\184\208\178\208\189\208\176\209\143 \208\186\208\190\208\188\208\176\208\189\208\180\208\176 \208\186\208\184\208\186\208\176 \208\186\208\190\208\179\208\190-\209\130\208\190 \208\184\208\183 \208\179\208\184\208\187\209\140\208\180\208\184\208\184." -- Needs review
L["Alt Names"] = "Alt \208\152\208\188\209\143" -- Needs review
L["Alt note fallback"] = "Alt note fallback" -- Requires localization
L["Announce when a mage begins casting Ritual of Refreshment."] = "\208\158\208\177\209\138\209\143\208\178\208\187\208\181\208\189\208\184\208\181, \208\186\208\190\208\179\208\180\208\176 \208\188\208\176\208\179 \209\135\208\184\209\130\208\176\208\181\209\130 \208\183\208\176\208\186\208\187\208\184\208\189\208\176\208\189\208\184\208\181 \208\158\208\177\209\128\209\143\208\180 \209\129\208\190\209\130\208\178\208\190\209\128\208\181\208\189\208\184\209\143 \209\143\209\129\209\130\208\178." -- Needs review
L["Announce when an alchemist puts down a (Big) Cauldron of Battle."] = "\208\158\208\177\209\138\209\143\208\178\208\187\208\181\208\189\208\184\208\181, \208\186\208\190\208\179\208\180\208\176 \208\176\208\187\209\133\208\184\208\188\208\184\208\186 \209\129\208\190\208\183\208\180\208\176\208\181\209\130 \208\154\208\190\209\130\208\181\208\187 \208\178\208\190\208\185\208\189\209\139." -- Needs review
L["Announce when an engineer puts down a repair bot."] = "\208\158\208\177\209\138\209\143\208\178\208\187\208\181\208\189\208\184\208\181, \208\186\208\190\208\179\208\180\208\176 \208\184\208\189\208\182\208\181\208\189\208\181\209\128 \209\129\208\190\208\183\208\180\208\176\208\181\209\130 \208\148\208\182\208\184\208\178\209\129." -- Needs review
L["Announce when a warlock puts down a soulwell."] = "\208\158\208\177\209\138\209\143\208\178\208\187\208\181\208\189\208\184\208\181, \208\186\208\190\208\179\208\180\208\176 \209\135\208\181\209\128\208\189\208\190\208\186\208\189\208\184\208\182\208\189\208\184\208\186 \209\135\208\184\209\130\208\176\208\181\209\130 \208\183\208\176\208\186\208\187\208\184\208\189\208\176\208\189\208\184\208\181 \208\160\208\184\209\130\209\131\208\176\208\187 \208\180\209\131\209\136." -- Needs review
L["Announce when a warlock puts down a summoning stone."] = "\208\158\208\177\209\138\209\143\208\178\208\187\208\181\208\189\208\184\208\181, \208\186\208\190\208\179\208\180\208\176 \209\135\208\181\209\128\208\189\208\190\208\186\208\189\208\184\208\182\208\189\208\184\208\186 \209\135\208\184\209\130\208\176\208\181\209\130 \208\183\208\176\208\186\208\187\208\184\208\189\208\176\208\189\208\184\208\181 \208\154\208\176\208\188\208\181\208\189\209\140 \208\191\209\128\208\184\208\183\209\139\208\178\208\176." -- Needs review
L["Announce when someone casts Mass Ressurection, obtained when your guild reaches level 25."] = "Announce when someone casts Mass Ressurection, obtained when your guild reaches level 25." -- Requires localization
L["Announce when someone puts down a feast."] = "\208\158\208\177\209\138\209\143\208\178\208\187\208\181\208\189\208\184\208\181, \208\186\208\190\208\179\208\180\208\176 \208\186\209\130\208\190 \209\130\208\190 \209\129\208\190\208\183\208\180\208\176\208\181\209\130 \208\159\208\184\209\128." -- Needs review
L["ap"] = "ap" -- Requires localization
L["Are you sure you want to delete all your saved class/level data?"] = "\208\146\209\139 \209\131\208\178\208\181\209\128\208\181\208\189\209\139, \209\135\209\130\208\190 \209\133\208\190\209\130\208\184\209\130\208\181 \209\131\208\180\208\176\208\187\208\184\209\130\209\140 \208\178\209\129\208\181 \209\129\208\190\209\133\209\128\208\176\208\189\208\181\208\189\208\189\209\139\208\181 \208\186\208\187\208\176\209\129\209\129\208\176/\209\131\209\128\208\190\208\178\208\189\209\143 \208\180\208\176\208\189\208\189\209\139\208\181?" -- Needs review
L["Are you sure you want to reset the chat fonts to defaults?"] = "\208\146\209\139 \209\131\208\178\208\181\209\128\208\181\208\189\209\139, \209\135\209\130\208\190 \209\133\208\190\209\130\208\184\209\130\208\181 \209\129\208\177\209\128\208\190\209\129\208\184\209\130\209\140 \209\136\209\128\208\184\209\132\209\130 \209\135\208\176\209\130\208\176 \208\191\208\190 \209\131\208\188\208\190\208\187\209\135\208\176\208\189\208\184\209\142?" -- Needs review
L["A simple calculator used to perform basic operations on gold values.  Providing no parameters will show you how much gold you have.\
\
You can include your current gold amount by using the |cff00ff00mymoney|r keyword.  For example |cff00ff00mymoney * 2|r.\
\
|cffff0000Money amounts can only be added or subtracted, multiplication or division can only be performed with money and a number.  For example:  4g * 4 is okay, where 4g * 4g is invalid."] = "A simple calculator used to perform basic operations on gold values.  Providing no parameters will show you how much gold you have.\
\
You can include your current gold amount by using the |cff00ff00mymoney|r keyword.  For example |cff00ff00mymoney * 2|r.\
\
|cffff0000Money amounts can only be added or subtracted, multiplication or division can only be performed with money and a number.  For example:  4g * 4 is okay, where 4g * 4g is invalid." -- Requires localization
L["A simple command-line calculator.  Certain keywords, listed below, can be used and their in game value will be substituted.  You can also assign variables which are saved for later use.\
\
|cffffff00Keywords:|r\
"] = "A simple command-line calculator.  Certain keywords, listed below, can be used and their in game value will be substituted.  You can also assign variables which are saved for later use.\
\
|cffffff00Keywords:|r\
" -- Requires localization
L["Auction Expired"] = "\208\144\209\131\208\186\209\134\208\184\208\190\208\189, \208\184\209\129\209\130\208\181\208\186" -- Needs review
L["Auction Message Filtering"] = "\208\164\208\184\208\187\209\140\209\130\209\128 \209\129\208\190\208\190\208\177\209\137\208\181\208\189\208\184\209\143 \208\176\209\131\208\186\209\134\208\184\208\190\208\189\208\176" -- Needs review
L["Auction Message Types"] = "Auction Message Types" -- Requires localization
L["Auction Outbid"] = "\208\144\209\131\208\186\209\134\208\184\208\190\208\189, \209\129\208\190\208\183\208\180\208\176\208\189\208\190" -- Needs review
L["Auction Removed"] = "\208\144\209\131\208\186\209\134\208\184\208\190\208\189, \209\131\208\180\208\176\208\187\208\181\208\189\208\190" -- Needs review
L["Auction Sold"] = "\208\144\209\131\208\186\209\134\208\184\208\190\208\189, \208\191\209\128\208\190\208\180\208\176\208\189\208\190" -- Needs review
L["Auction Won"] = "\208\144\209\131\208\186\209\134\208\184\208\190\208\189, \208\178\209\139\208\184\208\179\209\128\208\176\208\189\208\190" -- Needs review
L["Auto Congratulate"] = "\208\144\208\178\209\130\208\190 \208\191\208\190\208\183\208\180\209\128\208\176\208\178\208\187\208\181\208\189\208\184\208\181" -- Needs review
L["Auto Ding"] = "Auto Ding" -- Requires localization
L["Auto Farewell"] = "Auto Farewell" -- Requires localization
L["Automatically bid someone farewell when they leave your guild."] = "Automatically bid someone farewell when they leave your guild." -- Requires localization
L["Automatically congratulate someone when they, or others, complete an achievement."] = "\208\144\208\178\209\130\208\190\208\188\208\176\209\130\208\184\209\135\208\181\209\129\208\186\208\184 \208\191\208\190\208\183\208\180\209\128\208\176\208\178\208\184\209\130\209\140 \208\186\208\190\208\179\208\190-\209\130\208\190, \208\186\208\190\208\179\208\180\208\176 \208\190\208\189 \208\183\208\176\208\178\208\181\209\128\209\136\208\184\208\187 \208\180\208\190\209\129\209\130\208\184\208\182\208\181\208\189\208\184\208\181." -- Needs review
L["Automatically congratulates someone when they say \"ding\" in chat."] = "Automatically congratulates someone when they say \"ding\" in chat." -- Requires localization
L["Automatically enables chat logging."] = "\208\144\208\178\209\130\208\190\208\188\208\176\209\130\208\184\209\135\208\181\209\129\208\186\208\184 \208\178\208\186\208\187\209\142\209\135\208\176\209\130\209\140 \208\183\208\176\208\191\208\184\209\129\209\140 \208\187\208\190\208\179\208\190\208\178 \209\135\208\176\209\130\208\176" -- Needs review
L["Automatically enable tracking of pets for battles."] = "Automatically enable tracking of pets for battles." -- Requires localization
L["Automatically enable tracking of Stable Masters to help you revive and/or heal your pets."] = "Automatically enable tracking of Stable Masters to help you revive and/or heal your pets." -- Requires localization
L["Automatically link someone the profession they requested via various keywords."] = "Automatically link someone the profession they requested via various keywords." -- Requires localization
L["Automatically Remove Item When Finished"] = "Automatically Remove Item When Finished" -- Requires localization
L["Automatically welcomes someone to your guild."] = "\208\144\208\178\209\130\208\190\208\188\208\176\209\130\208\184\209\135\208\181\209\129\208\186\208\184 \208\191\209\128\208\184\208\178\208\181\209\130\209\129\209\130\208\178\209\131\208\181\209\130 \208\186\208\190\208\179\208\190-\209\130\208\190 \208\178\208\176\209\136\208\181\208\185 \208\179\208\184\208\187\209\140\208\180\208\184\208\184." -- Needs review
L["Automatic Chat Logging"] = "\208\144\208\178\209\130\208\190\208\187\208\190\208\179 \209\135\208\176\209\130\208\176"
L["Auto Profession Link"] = "\208\144\208\178\209\130\208\190 \209\129\209\129\209\139\208\187\208\186\208\176 \208\191\209\128\208\190\209\132\208\181\209\129\209\129\208\184\208\185" -- Needs review
L["Auto Welcome"] = "\208\144\208\178\209\130\208\190 \208\180\208\190\208\177\209\128\208\190 \208\191\208\190\208\182\208\176\208\187\208\190\208\178\208\176\209\130\209\140" -- Needs review
L["Available Chat Command Arguments"] = "\208\148\208\190\209\129\209\130\209\131\208\191\208\189\209\139\208\181 \208\176\209\128\208\179\209\131\208\188\208\181\208\189\209\130\209\139 \208\186\208\190\208\188\208\176\208\189\208\180 \209\135\208\176\209\130\208\176" -- Needs review
L["Available parameters are |cff1784d1version|r, |cff1784d1build|r, |cff1784d1date|r, |cff1784d1interface|r, |cff1784d1locale|r."] = "Available parameters are |cff1784d1version|r, |cff1784d1build|r, |cff1784d1date|r, |cff1784d1interface|r, |cff1784d1locale|r." -- Requires localization
L["Battleground"] = "\208\159\208\190\208\187\208\181 \208\145\209\128\208\176\208\189\208\184" -- Needs review
L["Battleground Channel"] = "\208\154\208\176\208\189\208\176\208\187 \208\191\208\190\208\187\209\143 \208\177\209\128\208\176\208\189\208\184" -- Needs review
L["Battleground Leader"] = "\208\155\208\184\208\180\208\181\209\128 \208\191\208\190\208\187\209\143 \208\177\209\128\208\176\208\189\208\184" -- Needs review
L["Battle.Net Options"] = "Battle.Net \208\191\208\176\209\128\208\176\208\188\208\181\209\130\209\128\209\139" -- Needs review
L["Before"] = "\208\148\208\190" -- Needs review
L["Bid Accepted"] = "\208\159\209\128\208\184\208\189\208\184\208\188\208\176\209\142\209\130\209\129\209\143 \209\129\209\130\208\176\208\178\208\186\208\184." -- Needs review
L["Blacksmithing"] = "\208\154\209\131\208\183\208\189\208\181\209\135\208\189\208\190\208\181 \208\180\208\181\208\187\208\190" -- Needs review
L["Build: |cff1784d1%s|r"] = "Build: |cff1784d1%s|r" -- Requires localization
L["Build Date: |cff1784d1%s|r"] = "Build Date: |cff1784d1%s|r" -- Requires localization
L["Busy"] = "\208\157\208\181 \208\177\208\181\209\129\208\191\208\190\208\186\208\190\208\184\209\130\209\140 (\208\148\208\157\208\148)" -- Needs review
L["Calculator"] = "Calculator" -- Requires localization
L["Can't set value '%s', doesn't look like a number."] = "Can't set value '%s', doesn't look like a number." -- Requires localization
L["Capture Delay"] = "Capture Delay" -- Requires localization
L["Cauldron of Battle"] = "\208\154\208\190\209\130\208\181\208\187 \208\177\208\184\209\130\208\178\209\139" -- Needs review
L["Center"] = "\208\166\208\181\208\189\209\130\209\128"
L["   |cff00ff00/ct %s|r or |cff00ff00%s|r - %s"] = "   |cff00ff00/ct %s|r or |cff00ff00%s|r - %s" -- Requires localization
L["   |cff00ff00/ct %s|r - %s"] = "|cff00ff00/ct %s|r - %s" -- Needs review
L["|cff00ff00%d|r Custom %s Being Used"] = "|cff00ff00%d|r Custom %s Being Used" -- Requires localization
L["|cff00ff00Enabled|r"] = "|cff00ff00Enabled|r" -- Requires localization
L["|cff00ff00%s|r"] = "|cff00ff00%s|r" -- Requires localization
L["|cff00ff00%s|r or |cff00ff00%s|r %s"] = "|cff00ff00%s|r \208\184\208\187\208\184 |cff00ff00%s|r %s" -- Needs review
L["   |cff00ff00%s|r or |cff00ff00%s|r - %s"] = "|cff00ff00%s|r \208\184\208\187\208\184 |cff00ff00%s|r - %s" -- Needs review
L["   |cff00ff00%s|r - %s"] = "|cff00ff00%s|r - %s" -- Needs review
L["|cff1784d1ElvUI Chat Tweaks|r version |cff1784d1%s|r"] = "|cff1784d1ElvUI Chat Tweaks|r version |cff1784d1%s|r" -- Requires localization
L["|cFF5cb4f8Pet Battle - Tale of the Tape|r"] = "|cFF5cb4f8Pet Battle - Tale of the Tape|r" -- Requires localization
L["|cffc7c7cfs|r"] = "|cffc7c7cfs|r" -- Requires localization
L["|cFFccff00Not Owned|r"] = "|cFFccff00Not Owned|r" -- Requires localization
L["|cffeda55fc|r"] = "|cffeda55fc|r" -- Requires localization
L["|cffff0000Disabled|r"] = "|cffff0000Disabled|r" -- Requires localization
L["|cffff0000ERROR|r Both messages must be set in order to use the spam method |cffffff00%s|r"] = "|cffff0000ERROR|r Both messages must be set in order to use the spam method |cffffff00%s|r" -- Requires localization
L["|cffff0000Item|r |cffffffff\"%s\"|r |cffff0000does not exist.|r"] = "|cffff0000Item|r |cffffffff\"%s\"|r |cffff0000does not exist.|r" -- Requires localization
L["|cffff0000No modules found.|r"] = "|cffff0000No modules found.|r" -- Requires localization
L["\
\
|cffff0000NOTE:|r  If this addon starts to use a substantial amount of memory, simply reset the name data and it will return to a normal level."] = "\
\
|cffff0000NOTE:|r  If this addon starts to use a substantial amount of memory, simply reset the name data and it will return to a normal level." -- Requires localization
L["\
\
|cffff0000NOTE:|r  If this addon starts to use a substantial amount of memory, simply reset the name data and it will return to a normal level.\
\
Addon Usage: |cff00ff00%s|r"] = "\
\
|cffff0000NOTE:|r  If this addon starts to use a substantial amount of memory, simply reset the name data and it will return to a normal level.\
\
Addon Usage: |cff00ff00%s|r" -- Requires localization
L["|cffff0000The Chat Frame you chose to output reputation changes,|r |cffffffff%s|r|cffff0000, does not exist."] = "|cffff0000The Chat Frame you chose to output reputation changes,|r |cffffffff%s|r|cffff0000, does not exist." -- Requires localization
L[" |cFFff5a00(Upgrade)|r"] = " |cFFff5a00(Upgrade)|r" -- Requires localization
L["|cffff9000Not in Pet Journal|r"] = "|cffff9000Not in Pet Journal|r" -- Requires localization
L["|cffff9000Pet Journal:|r %s"] = "|cffff9000Pet Journal:|r %s" -- Requires localization
L["|cffffd700g|r"] = "|cffffd700g|r" -- Requires localization
L["|cffffff00Character already in a guild."] = "|cffffff00Character already in a guild." -- Requires localization
L["|cffffff00Character already in your guild."] = "|cffffff00Character already in your guild." -- Requires localization
L[" |cffffff00%d|r Total Modules (|cff00ff00%d|r Enabled, |cffff0000%d|r Disabled)"] = "|cffffff00%d|r \208\158\208\177\209\137\208\184\208\181 \208\156\208\190\208\180\209\131\208\187\208\184 (|cff00ff00%d|r \208\146\208\186\208\187\209\142\209\135\209\145\208\189, |cffff0000%d|r \208\146\209\139\208\186\208\187\209\142\209\135\208\181\208\189)" -- Needs review
L["|cffffff00One of your addons is breaking critical chat data I need to work properly :(|r"] = "|cffffff00One of your addons is breaking critical chat data I need to work properly :(|r" -- Requires localization
L["|cffffff00Unable to execute secure command.|r |cffffffff%s|r"] = "|cffffff00Unable to execute secure command.|r |cffffffff%s|r" -- Requires localization
L["|cffffff00Usage: /ginvite <name>|r"] = "|cffffff00Usage: /ginvite <name>|r" -- Requires localization
L["|cffffff00Usage: /gkick <name>|r"] = "|cffffff00\208\152\209\129\208\191\208\190\208\187\209\140\208\183\208\190\208\178\208\176\208\189\208\184\208\181: /gkick <\208\184\208\188\209\143>|r" -- Needs review
L["|cffffff00Usage: /in <delay> <command>|r"] = "|cffffff00Usage: /in <delay> <command>|r" -- Requires localization
L["|cffffff00Usage: /rpt <times> <command>|r"] = "|cffffff00Usage: /rpt <times> <command>|r" -- Requires localization
L["|cffffffffBlocked spam from |Hplayer:%s|h[%s]|h,|r |cfffe2ec8|Hspamfilter:%d:%s|h[Click to report!]|h|r"] = "|cffffffffBlocked spam from |Hplayer:%s|h[%s]|h,|r |cfffe2ec8|Hspamfilter:%d:%s|h[Click to report!]|h|r" -- Requires localization
L["|cffffffffYou have %s.|r"] = "|cffffffffYou have %s.|r" -- Requires localization
L["Changed Channel"] = "Changed Channel" -- Requires localization
L["Channel"] = "Channel" -- Requires localization
L["Channel Colors"] = "\208\166\208\178\208\181\209\130 \208\186\208\176\208\189\208\176\208\187\208\176"
L["Channel %d"] = "Channel %d" -- Requires localization
L["Channel Notice Filter"] = "Channel Notice Filter" -- Requires localization
L["Channels"] = "Channels" -- Requires localization
L["Channel Sounds"] = "\208\151\208\178\209\131\208\186 \208\186\208\176\208\189\208\176\208\187\208\176"
L["Channel Spam"] = "Channel Spam" -- Requires localization
L["Channel Spam has been |cff%s%s|r."] = "Channel Spam has been |cff%s%s|r." -- Requires localization
L["Channel Spam is already running."] = "Channel Spam is already running." -- Requires localization
L["Channels to Monitor"] = "\208\154\208\176\208\189\208\176\208\187\209\139 \208\180\208\187\209\143 \208\188\208\190\208\189\208\184\209\130\208\190\209\128\208\184\208\189\208\179\208\176" -- Needs review
L["Channel to output the messages to."] = "Channel to output the messages to." -- Requires localization
L["Character to use between the name and level"] = "\208\161\208\184\208\188\208\178\208\190\208\187 \208\180\208\187\209\143 \208\184\209\129\208\191\208\190\208\187\209\140\208\183\208\190\208\178\208\176\208\189\208\184\209\143 \208\188\208\181\208\182\208\180\209\131 \208\184\208\188\208\181\208\189\208\181\208\188 \208\184 \209\131\209\128\208\190\208\178\208\189\208\181\208\188" -- Needs review
L["Character to use for the left bracket"] = "\208\161\208\184\208\188\208\178\208\190\208\187, \208\186\208\190\209\130\208\190\209\128\209\139\208\185 \208\177\209\131\208\180\208\181\209\130 \208\184\209\129\208\191\208\190\208\187\209\140\208\183\208\190\208\178\208\176\209\130\209\140\209\129\209\143 \208\180\208\187\209\143 \208\187\208\181\208\178\208\190\208\185 \208\186\208\178\208\176\208\180\209\128\208\176\209\130\208\189\208\190\208\185 \209\129\208\186\208\190\208\177\208\186\208\184" -- Needs review
L["Character to use for the right bracket"] = "\208\161\208\184\208\188\208\178\208\190\208\187 \208\180\208\187\209\143 \208\184\209\129\208\191\208\190\208\187\209\140\208\183\208\190\208\178\208\176\208\189\208\184\209\143 \208\191\209\128\208\176\208\178\208\190\208\185 \209\129\208\186\208\190\208\177\208\186\208\184" -- Needs review
L["Chat"] = "\208\167\208\176\209\130" -- Needs review
L["Chat Fading"] = "\208\167\208\176\209\130 \208\178\209\139\209\134\208\178\208\181\209\130\208\176\208\189\208\184\209\143" -- Needs review
L["Chat Fonts"] = "\208\168\209\128\208\184\209\132\209\130 \209\135\208\176\209\130\208\176"
L["Chat Frame"] = "Chat Frame" -- Requires localization
L["Chat Frame "] = "\208\164\209\128\208\181\208\185\208\188 \209\135\208\176\209\130\208\176"
L["Chat Frame %d"] = "Chat Frame %d" -- Requires localization
L["ChatFrame %d"] = "\208\158\208\186\208\189\208\190 \209\135\208\176\209\130\208\176 %d" -- Needs review
L["Chat Frame Settings"] = "\208\157\208\176\209\129\209\130\209\128\208\190\208\185\208\186\208\184 \208\190\208\186\208\190\208\189 \209\135\208\176\209\130\208\176" -- Needs review
L["Chat frame to output the messages.  Default is ChatFrame3, which is the default output frame for reputation messages in ElvUI."] = "Chat frame to output the messages.  Default is ChatFrame3, which is the default output frame for reputation messages in ElvUI." -- Requires localization
L["Chat frame to output the message to.  Default is |cffffff00ChatFrame3|r, which is the default frame for ElvUI XP messages."] = "Chat frame to output the message to.  Default is |cffffff00ChatFrame3|r, which is the default frame for ElvUI XP messages." -- Requires localization
L["Chat frame to route the auction house messages to."] = "Chat frame to route the auction house messages to." -- Requires localization
L["Chat frame to route the messages to."] = "Chat frame to route the messages to." -- Requires localization
L["Chat frame to send the messages to."] = "Chat frame to send the messages to." -- Requires localization
L["Chat message"] = "\208\161\208\190\208\190\208\177\209\137\208\181\208\189\208\184\209\143 \209\135\208\176\209\130\208\176" -- Needs review
L["Chat message with icons"] = "\208\161\208\190\208\190\208\177\209\137\208\181\208\189\208\184\209\143 \209\135\208\176\209\130\208\176 \209\129 \208\184\208\186\208\190\208\189\208\186\208\176\208\188\208\184" -- Needs review
L["Chats To Monitor"] = "\208\167\208\176\209\130\209\139 \208\180\208\187\209\143 \208\188\208\190\208\189\208\184\209\130\208\190\209\128\208\176" -- Needs review
L["Cheats Color"] = "Cheats Color" -- Requires localization
L["Choose which chat frames display timestamps"] = "\208\154\208\176\208\186\208\184\208\181 \208\190\208\186\208\189\208\176 \209\135\208\176\209\130\208\176 \208\177\209\131\208\180\209\131\209\130 \208\190\209\130\208\190\208\177\209\128\208\176\208\182\208\176\209\130\209\140 \208\178\209\128\208\181\208\188\209\143 \209\129\208\190\208\190\208\177\209\137\208\181\208\189\208\184\209\143" -- Needs review
L["Class"] = "\208\154\208\187\208\176\209\129\209\129"
L["Clear all chat windows."] = "\208\158\209\135\208\184\209\129\209\130\208\184\209\130\209\140 \208\178\209\129\208\181 \208\190\208\186\208\189\208\176 \209\135\208\176\209\130\208\176" -- Needs review
L["Clear Chat Commands"] = "\208\158\209\135\208\184\209\129\209\130\208\184\209\130\209\140 \208\186\208\190\208\188\208\176\208\189\208\180\209\139 \209\135\208\176\209\130\208\176" -- Needs review
L["Clear current chat."] = "\208\158\209\135\208\184\209\129\209\130\208\184\209\130\209\140 \209\130\208\181\208\186\209\131\209\137\208\184\208\185 \209\135\208\176\209\130"
L["Click to reset the materials you're tracking."] = "Click to reset the materials you're tracking." -- Requires localization
L["Client Locale: |cff1784d1%s|r"] = "Client Locale: |cff1784d1%s|r" -- Requires localization
L["Coin Size"] = "Coin Size" -- Requires localization
L["Color"] = "Color" -- Requires localization
L["Color Anywhere"] = "Color Anywhere" -- Requires localization
L["Color a roll game loss, aka when you roll a one (1)."] = "Color a roll game loss, aka when you roll a one (1)." -- Requires localization
L["Color a roll game win, aka when someone else rolls a one (1)."] = "Color a roll game win, aka when someone else rolls a one (1)." -- Requires localization
L["Color Cheats"] = "Color Cheats" -- Requires localization
L["Colorize"] = "\208\160\208\176\209\129\208\186\209\128\208\176\209\129\208\184\209\130\209\140." -- Needs review
L["Color level by difficulty"] = "\208\166\208\178\208\181\209\130 \209\131\209\128\208\190\208\178\208\189\209\143 \209\129\208\187\208\190\208\182\208\189\208\190\209\129\209\130\208\184." -- Needs review
L["Color Loss"] = "Color Loss" -- Requires localization
L["Color Name"] = "Color Name" -- Requires localization
L["Color of other's rolls."] = "Color of other's rolls." -- Requires localization
L["Color of the base reputation messages."] = "Color of the base reputation messages." -- Requires localization
L["Color of the faction."] = "Color of the faction." -- Requires localization
L["Color of the output message."] = "Color of the output message." -- Requires localization
L["Color of the reputation needed/left."] = "Color of the reputation needed/left." -- Requires localization
L["Color of the standing (honored, revered, etc.)."] = "Color of the standing (honored, revered, etc.)." -- Requires localization
L["Color own charname in messages."] = "\208\166\208\178\208\181\209\130 \209\129\208\190\208\177\209\129\209\130\208\178\208\181\208\189\208\189\209\139\209\133 \208\184\208\188\208\181\208\189 \208\191\208\181\209\128\209\129\208\190\208\189\208\176\208\182\208\181\208\185 \208\178 \209\129\208\190\208\190\208\177\209\137\208\181\208\189\208\184\209\143\209\133." -- Needs review
L["Color Player Names By..."] = "\208\166\208\178\208\181\209\130\208\176 \208\184\208\188\208\181\208\189\208\184 \208\184\208\179\209\128\208\190\208\186\208\176..." -- Needs review
L["Color regular rolls by others."] = "Color regular rolls by others." -- Requires localization
L["Color Rolls"] = "Color Rolls" -- Requires localization
L["Color rolls differently to make tracking the roll game easier on the eyes."] = "Color rolls differently to make tracking the roll game easier on the eyes." -- Requires localization
L["Color rolls that do not start at 1."] = "Color rolls that do not start at 1." -- Requires localization
L["Color self in messages"] = "\208\166\208\178\208\181\209\130 \208\178\208\176\209\136\208\184\209\133 \209\129\208\190\208\190\208\177\209\137\208\181\208\189\208\184\208\185" -- Needs review
L["Color the name of the pets during a pet battle relative to their rarity.  If you have the pet you're currently battling it will also add the quality of the pet you have in your journal."] = "Color the name of the pets during a pet battle relative to their rarity.  If you have the pet you're currently battling it will also add the quality of the pet you have in your journal." -- Requires localization
L["Color the player names anywhere they're found."] = "Color the player names anywhere they're found." -- Requires localization
L["Color timestamps the same as the channel they appear in."] = "\208\166\208\178\208\181\209\130 \208\178\209\128\208\181\208\188\208\181\208\189\208\184 \209\129\208\190\208\190\208\177\209\137\208\181\208\189\208\184\209\143 \208\186\208\176\208\186 \208\184 \209\131 \208\186\208\176\208\189\208\176\208\187\208\176 \209\129\208\190\208\190\208\177\209\137\208\181\208\189\208\184\209\143." -- Needs review
L["Color to change the filtered message to.\
\
|cffff0000Only works when Filtering Mode is set to |cff00ff00Colorize|r."] = "Color to change the filtered message to.\
\
|cffff0000Only works when Filtering Mode is set to |cff00ff00Colorize|r." -- Requires localization
L["Color to designate a cheating roll."] = "Color to designate a cheating roll." -- Requires localization
L["Color to designate a roll game loss."] = "Color to designate a roll game loss." -- Requires localization
L["Color to designate a roll game win."] = "Color to designate a roll game win." -- Requires localization
L["Color to use for your rolls."] = "Color to use for your rolls." -- Requires localization
L["Color Win"] = "Color Win" -- Requires localization
L["Color Your Rolls"] = "Color Your Rolls" -- Requires localization
L["Color your rolls to set them apart."] = "Color your rolls to set them apart." -- Requires localization
L["Combined"] = "Combined" -- Requires localization
L["Compress"] = "\208\161\208\182\208\184\208\188\208\176\209\130\209\140" -- Needs review
L["Congratulate achievements earned by guildmates."] = "\208\159\208\190\208\183\208\180\209\128\208\176\208\178\208\187\209\143\209\130\209\140, \208\191\209\128\208\184 \208\191\208\190\208\187\209\131\209\135\208\181\208\189\208\184\208\184 \208\179\208\184\208\187\209\140\208\180\208\184\208\181\208\185 \208\180\208\190\209\129\209\130\208\184\208\182\208\181\208\189\208\184\209\143." -- Needs review
L["Congratulate achievements earned by people in your party."] = "\208\159\208\190\208\183\208\180\209\128\208\176\208\178\208\187\209\143\208\181\208\188 \208\187\209\142\208\180\208\181\208\185 \208\186\208\190\209\130\208\190\209\128\209\139\208\181 \208\191\208\190\208\187\209\131\209\135\208\184\208\187\208\184 \208\180\208\190\209\129\209\130\208\184\208\182\208\181\208\189\208\184\208\181 \208\178 \208\178\208\176\209\136\208\181\208\185 \208\179\209\128\209\131\208\191\208\191\208\181." -- Needs review
L["Congratulate achievements earned by people in your raid."] = "\208\159\208\190\208\183\208\180\209\128\208\176\208\178\208\187\209\143\208\181\208\188 \208\187\209\142\208\180\208\181\208\185 \208\186\208\190\209\130\208\190\209\128\209\139\208\181 \208\191\208\190\208\187\209\131\209\135\208\184\208\187\208\184 \208\180\208\190\209\129\209\130\208\184\208\182\208\181\208\189\208\184\208\181 \208\178 \208\178\208\176\209\136\208\181\208\188 \209\128\208\181\208\185\208\180\208\181." -- Needs review
L["Congratulate achievements earned by people near you."] = "\208\159\208\190\208\183\208\180\209\128\208\176\208\178\208\187\209\143\208\181\208\188 \208\187\209\142\208\180\208\181\208\185 \208\186\208\190\209\130\208\190\209\128\209\139\208\181 \208\191\208\190\208\187\209\131\209\135\208\184\208\187\208\184 \208\180\208\190\209\129\209\130\208\184\208\182\208\181\208\189\208\184\208\181 \208\189\208\176\209\133\208\190\208\180\209\143\209\129\209\140 \208\189\208\181\208\180\208\176\208\187\208\181\208\186\208\190 \208\190\209\130 \208\178\208\176\209\129." -- Needs review
L["Congratulations Messages"] = "\208\159\208\190\208\183\208\180\209\128\208\176\208\178\208\187\209\143\209\130\209\140 \209\129\208\190\208\190\208\177\209\137\208\181\208\189\208\184\208\181\208\188." -- Needs review
L["conquest"] = "conquest" -- Requires localization
L["  Conquest Points\
"] = "  Conquest Points\
" -- Requires localization
L["Cooking"] = "\208\154\209\131\208\187\208\184\208\189\208\176\209\128\208\184\209\143" -- Needs review
L["copper"] = "copper" -- Requires localization
L["cp"] = "cp" -- Requires localization
L["cpcap"] = "cpcap" -- Requires localization
L["Crap Cleaner"] = "\208\167\208\184\209\129\209\130\208\190\208\181 \208\180\208\181\209\128\209\140\208\188\208\190" -- Needs review
L["Creates a button to click that will return you to the bottom of the chat frame."] = "\208\161\208\190\208\183\208\180\208\176\208\181\209\130 \208\186\208\189\208\190\208\191\208\186\209\131 \208\189\208\176\208\182\208\176\209\130\209\140 \208\186\208\190\209\130\208\190\209\128\209\131\209\142 \208\178\208\181\209\128\208\189\208\181\209\130 \208\178\208\176\209\129 \208\186 \208\189\208\184\208\182\208\189\208\181\208\185 \209\135\208\176\209\129\209\130\208\184 \209\135\208\176\209\130\208\176." -- Needs review
L["Custom chat filters."] = "\208\159\208\190\208\187\209\140\208\183\208\190\208\178\208\176\209\130\208\181\208\187\209\140\209\129\208\186\208\184\208\181 \209\132\208\184\208\187\209\140\209\130\209\128\209\139 \209\135\208\176\209\130\208\176." -- Needs review
L["Custom Chat Filters"] = "\208\157\208\176\209\129\209\130\209\128\208\190\208\184\209\130\209\140 \209\132\208\184\208\187\209\140\209\130\209\128\209\139 \209\135\208\176\209\130\208\176." -- Needs review
L["Custom color"] = "\208\159\208\190\208\187\209\140\208\183\208\190\208\178\208\176\209\130\208\181\208\187\209\140\209\129\208\186\208\184\208\181 \209\134\208\178\208\181\209\130\208\176" -- Needs review
L["Custom Emote: |cffffff00%s|r"] = "Custom Emote: |cffffff00%s|r" -- Requires localization
L["Custom Emotes"] = "\208\159\208\190\208\187\209\140\208\183\208\190\208\178\208\176\209\130\208\181\208\187\209\140\209\129\208\186\208\184\208\181 \209\141\208\188\208\190\209\134\208\184\208\184" -- Needs review
L["Custom format (advanced)"] = "\208\159\208\190\208\187\209\140\208\183\208\190\208\178\208\176\209\130\208\181\208\187\209\140\209\129\208\186\208\184\208\185 \209\132\208\190\209\128\208\188\208\176\209\130 (\208\191\209\128\208\190\208\180\208\178\208\184\208\189\209\131\209\130\209\139\208\185)" -- Needs review
L["Damage Meters"] = "\208\154\208\190\208\188\208\191\209\128\208\181\209\129\209\129\208\190\209\128" -- Needs review
L["Death Knight"] = "\208\160\209\139\209\134\208\176\209\128\209\140 \209\129\208\188\208\181\209\128\209\130\208\184"
L["Default font face for the chat frames."] = "\208\168\209\128\208\184\209\132\209\130 \208\191\208\190 \209\131\208\188\208\190\208\187\209\135\208\176\208\189\208\184\209\142 \208\180\208\187\209\143 \208\190\208\186\208\189\208\176 \209\135\208\176\209\130\208\176." -- Needs review
L["Default font outline for the chat frames."] = "\208\168\209\128\208\184\209\132\209\130 \208\191\208\190 \209\131\208\188\208\190\208\187\209\135\208\176\208\189\208\184\209\142 \208\180\208\187\209\143 \209\141\209\130\208\190\208\179\208\190 \208\190\208\186\208\189\208\176 \209\135\208\176\209\130\208\176." -- Needs review
L["Default font size for the chat frames."] = "\208\160\208\176\208\183\208\188\208\181\209\128 \209\136\209\128\208\184\209\132\209\130\208\176 \209\135\208\176\209\130\208\176 \208\191\208\190 \209\131\208\188\208\190\208\187\209\135\208\176\208\189\208\184\209\142." -- Needs review
L["Default Name Color"] = "\208\166\208\178\208\181\209\130 \208\184\208\188\208\181\208\189\208\184 \208\191\208\190 \209\131\208\188\208\190\208\187\209\135\208\176\208\189\208\184\209\142." -- Needs review
L["Destroys all your saved class/level data"] = "\208\158\209\135\208\184\209\129\209\130\208\184\209\130\209\140 \209\129\208\190\209\133\209\128\208\176\208\189\208\189\209\139\208\181 \208\180\208\176\208\189\208\189\209\139\208\181 \208\190 \208\186\208\187\208\176\209\129\209\129\208\176\209\133 \208\184 \209\131\209\128\208\190\208\178\208\189\209\143\209\133" -- Needs review
L["Determines if a chat message is deemed spam, at which point it can be filtered and the person reported."] = "Determines if a chat message is deemed spam, at which point it can be filtered and the person reported." -- Requires localization
L["Developer Tools"] = "Developer Tools" -- Requires localization
L["Ding Messages"] = "Ding Messages" -- Requires localization
L["Disabled"] = "\208\146\209\139\208\186\208\187\209\142\209\135\208\184\209\130\209\140 " -- Needs review
L["Disable if..."] = "\208\158\209\130\208\186\208\187\209\142\209\135\208\184\209\130\208\181, \208\181\209\129\208\187\208\184 ..." -- Needs review
L["Disable while you're AFK flagged."] = "\208\158\209\130\208\186\208\187\209\142\209\135\208\184\209\130\209\140 \208\181\209\129\208\187\208\184 \208\178\209\139 \208\178\209\139 \208\144\208\164\208\154." -- Needs review
L["Disable while you're DND flagged."] = "\208\158\209\130\208\186\208\187\209\142\209\135\208\184\209\130\209\140 \208\181\209\129\208\187\208\184 \208\178\209\139 \208\178\209\139 \208\148\208\157\208\148." -- Needs review
L["Displays reputation numbers and progress in the chat frame."] = "Displays reputation numbers and progress in the chat frame." -- Requires localization
L["DND Messages"] = "DND Messages" -- Requires localization
L["Do Nothing"] = "\208\148\208\181\208\185\209\129\209\130\208\178\208\184\208\181 \208\189\208\181 \209\130\209\128\208\181\208\177\209\131\208\181\209\130\209\129\209\143" -- Needs review
L["Dont Always Run"] = "Dont Always Run" -- Requires localization
L["Don't Report"] = "Don't Report" -- Requires localization
L["Do you want to automatically remove an item when you meet your quota?"] = "Do you want to automatically remove an item when you meet your quota?" -- Requires localization
L["Druid"] = "\208\148\209\128\209\131\208\184\208\180"
L["Editbox History"] = "\208\160\208\181\208\180\208\176\208\186\209\130\208\184\209\128\208\190\208\178\208\176\209\130\209\140 \208\177\208\187\208\190\208\186 \208\184\209\129\209\130\208\190\209\128\208\184\208\184" -- Needs review
L["ElvUI ChatTweaks"] = "ElvUI ChatTweaks " -- Needs review
L["ElvUI_ChatTweaks: You need to be level %d to whisper me.  Currently you are level %d!"] = "ElvUI_ChatTweaks: You need to be level %d to whisper me.  Currently you are level %d!" -- Requires localization
L["Emote"] = "\208\173\208\188\208\190\209\134\208\184\208\184" -- Needs review
L["Emote Filter"] = "Emote Filter" -- Requires localization
L["Emphasize Self"] = "Emphasize Self" -- Requires localization
L["Enable"] = "Enable" -- Requires localization
L["Enable "] = "\208\146\208\186\208\187\209\142\209\135\208\184\209\130\209\140 " -- Needs review
L["Enabled"] = "\208\146\208\186\208\187\209\142\209\135\208\181\208\189\208\190 " -- Needs review
L["Enable Debugging"] = "Enable Debugging" -- Requires localization
L["Enables you to right-click a person's name in chat and set a note on them to be displayed in chat, such as their main character's name.  Can also scan guild notes for character names to display, if no note has been manually set."] = "Enables you to right-click a person's name in chat and set a note on them to be displayed in chat, such as their main character's name.  Can also scan guild notes for character names to display, if no note has been manually set." -- Requires localization
L["Enable this to give the module a percent chance to run to prevent spam/annoyances.  If disabled the module will always congratulate."] = "Enable this to give the module a percent chance to run to prevent spam/annoyances.  If disabled the module will always congratulate." -- Requires localization
L["Enable this to give the module a percent chance to run to prevent spam/annoyances.  If disabled the module will always run."] = "Enable this to give the module a percent chance to run to prevent spam/annoyances.  If disabled the module will always run." -- Requires localization
L["Enable this to give the module a percent chance to run to prevent spam/annoyances.  If disabled the module will always welcome."] = "Enable this to give the module a percent chance to run to prevent spam/annoyances.  If disabled the module will always welcome." -- Requires localization
L["Enable to filter custom emotes made using |cff00ff00/emote|r or |cff00ff00/e|r."] = "Enable to filter custom emotes made using |cff00ff00/emote|r or |cff00ff00/e|r." -- Requires localization
L["Enable to filter standard emotes such as |cff00ff00/dance|r or |cff00ff00/flirt|r."] = "Enable to filter standard emotes such as |cff00ff00/dance|r or |cff00ff00/flirt|r." -- Requires localization
L["Enable various debugging messages to help with errors or undesired functioning."] = "Enable various debugging messages to help with errors or undesired functioning." -- Requires localization
L["Enchanting"] = "\208\157\208\176\208\187\208\190\208\182\208\181\208\189\208\184\208\181 \209\135\208\176\209\128" -- Needs review
L["Engineering"] = "\208\152\208\189\208\182\208\181\208\189\208\181\209\128\208\184\209\143" -- Needs review
L["Enter a custom time format. See http://www.lua.org/pil/22.1.html for a list of valid formatting symbols."] = "\208\146\208\178\208\181\208\180\208\184\209\130\208\181 \208\191\208\190\208\187\209\140\208\183\208\190\208\178\208\176\209\130\208\181\208\187\209\140\209\129\208\186\208\184\208\185 \209\132\208\190\209\128\208\188\208\176\209\130 \208\178\209\128\208\181\208\188\208\181\208\189\208\184. \208\161\208\188\208\190\209\130\209\128\208\184\209\130\208\181 http://www.lua.org/pil/22.1.html \208\180\208\187\209\143 \209\129\208\191\208\184\209\129\208\186\208\176 \208\180\208\190\208\191\209\131\209\129\209\130\208\184\208\188\209\139\209\133 \209\129\208\184\208\188\208\178\208\190\208\187\208\190\208\178 \209\132\208\190\209\128\208\188\208\176\209\130\208\184\209\128\208\190\208\178\208\176\208\189\208\184\209\143." -- Needs review
L["Exclude level display for max level characters"] = "\208\146\209\139\208\186\208\187\209\142\209\135\208\184\209\130\209\140 \208\184\208\189\208\180\208\184\208\186\208\176\209\130\208\190\209\128 \209\131\209\128\208\190\208\178\208\189\209\143 \208\180\208\187\209\143 \208\191\208\181\209\128\209\129\208\190\208\189\208\176\208\182\208\181\208\185 \208\188\208\176\208\186\209\129\208\184\208\188\208\176\208\187\209\140\208\189\208\190\208\179\208\190 \209\131\209\128\208\190\208\178\208\189\209\143." -- Needs review
L["Exclude max levels"] = "\208\163\208\177\209\128\208\176\209\130\209\140 \208\188\208\176\208\186\209\129\208\184\208\188\208\176\208\187\209\140\208\189\209\139\208\185 \209\131\209\128\208\190\208\178\208\181\208\189\209\140." -- Needs review
L["Execution Interval"] = "\208\161\208\190\208\183\208\180\208\176\209\130\209\140 \208\184\208\189\209\130\208\181\209\128\208\178\208\176\208\187" -- Needs review
L["Faction Color"] = "Faction Color" -- Requires localization
L["Feasts"] = "\208\159\209\128\208\176\208\183\208\180\208\189\208\184\208\186\208\184" -- Needs review
L["Filter"] = "Filter" -- Requires localization
L["Filter achievement message spam!"] = "\208\164\208\184\208\187\209\140\209\130\209\128\209\139 \209\129\208\191\208\176\208\188\208\176 \208\180\208\190\209\129\209\130\208\184\208\182\208\181\208\189\208\184\208\185" -- Needs review
L["Filter achievements earned by guildmates."] = "\208\164\208\184\208\187\209\140\209\130\209\128\209\139 \208\180\208\190\209\129\209\130\208\184\208\182\208\181\208\189\208\184\208\185 \208\179\208\184\208\187\209\140\208\180\208\184\208\184." -- Needs review
L["Filter achievements earned by nearby people."] = "\208\164\208\184\208\187\209\140\209\130\209\128\209\139 \208\180\208\190\209\129\209\130\208\184\208\182\208\181\208\189\208\184\208\185 \208\191\208\190\208\187\209\131\209\135\208\181\208\189\208\189\209\139\208\181 \208\184\208\179\209\128\208\190\208\186\208\190\208\178 \209\128\209\143\208\180\208\190\208\188 \209\129 \208\178\208\176\208\188\208\184." -- Needs review
L["Filter AFK/DND auto responses.  This module is compatible with WIM."] = "Filter AFK/DND auto responses.  This module is compatible with WIM." -- Requires localization
L["Filter AFK messages."] = "Filter AFK messages." -- Requires localization
L["Filter annoying phrases in chat."] = "\208\164\208\184\208\187\209\140\209\130\209\128 \209\128\208\176\208\183\208\180\209\128\208\176\208\182\208\176\209\142\209\137\208\184\209\133 \209\132\209\128\208\176\208\183 \208\178 \209\135\208\176\209\130\208\181." -- Needs review
L["Filter by Player Level"] = "\208\164\208\184\208\187\209\140\209\130\209\128 \208\191\208\190 \209\131\209\128\208\190\208\178\208\189\209\142 \208\184\208\179\209\128\208\190\208\186\208\176" -- Needs review
L["Filter changed channel message."] = "Filter changed channel message." -- Requires localization
L["Filter Color"] = "\208\166\208\178\208\181\209\130 \209\132\208\184\208\187\209\140\209\130\209\128\208\176" -- Needs review
L["Filter DND messages."] = "Filter DND messages." -- Requires localization
L["Filter Entire Line"] = "Filter Entire Line" -- Requires localization
L["Filter Guild Achievements"] = "\208\164\208\184\208\187\209\140\209\130\209\128\209\139 \208\148\208\190\209\129\209\130\208\184\208\182\208\181\208\189\208\184\209\143 \208\179\208\184\208\187\209\140\208\180\208\184\208\184" -- Needs review
L["Filter guild invites."] = "\208\164\208\184\208\187\209\140\209\130\209\128 \208\191\209\128\208\184\208\179\208\187\208\176\209\136\208\181\208\189\208\184\208\185 \208\178 \208\179\208\184\208\187\209\140\208\180\208\184\209\142" -- Needs review
L["Filter guild recruitment messages in chat."] = "\208\164\208\184\208\187\209\140\209\130\209\128 \208\189\208\176\208\177\208\190\209\128\208\176 \208\178 \208\179\208\184\208\187\209\140\208\180\208\184\209\142, \208\178 \209\135\208\176\209\130\208\181." -- Needs review
L["Filter guild recruitment whispers."] = "\208\164\208\184\208\187\209\140\209\130\209\128 \208\189\208\176\208\177\208\190\209\128\208\176 \208\178 \208\179\208\184\208\187\209\140\208\180\208\184\209\142, \208\178 \209\136\208\181\208\191\208\190\209\130." -- Needs review
L["Filtering Mode"] = "\208\160\208\181\208\182\208\184\208\188 \209\132\208\184\208\187\209\140\209\130\209\128\208\176\209\134\208\184\208\184." -- Needs review
L["Filter joined channel message."] = "Filter joined channel message." -- Requires localization
L["Filter left channel message."] = "Filter left channel message." -- Requires localization
L["Filter Nearby Achievements"] = "Filter Nearby Achievements" -- Requires localization
L["Filter out raid icons in chat."] = "\208\158\209\130\209\132\208\184\208\187\209\140\209\130\209\128\208\190\208\178\208\176\209\130\209\140 \209\128\208\181\208\185\208\180 \208\184\208\186\208\190\208\189\208\186\208\184 \208\178 \209\135\208\176\209\130\208\181." -- Needs review
L["Filter Raid Icons"] = "\208\164\208\184\208\187\209\140\209\130\209\128 \208\184\208\186\208\190\208\189\208\190\208\186 \209\128\208\181\208\185\208\180\208\176" -- Needs review
L["Filters"] = "\208\164\208\184\208\187\209\140\209\130\209\128\209\139." -- Needs review
L["Filters guild recruitment spam in whispers or chat.  Can also block guild invites."] = "Filters guild recruitment spam in whispers or chat.  Can also block guild invites." -- Requires localization
L["Filters out Auction House system messages."] = "Filters out Auction House system messages." -- Requires localization
L["Filter spam throttle notices."] = "Filter spam throttle notices." -- Requires localization
L["Filter standard and/or custom emotes."] = "Filter standard and/or custom emotes." -- Requires localization
L["Filters the channel notices."] = "Filters the channel notices." -- Requires localization
L["Filter the Auction Expired message.\
\
|cffffff00%s|r"] = "Filter the Auction Expired message.\
\
|cffffff00%s|r" -- Requires localization
L["Filter the Auction Outbid message.\
\
|cffffff00%s|r"] = "Filter the Auction Outbid message.\
\
|cffffff00%s|r" -- Requires localization
L["Filter the Auction Removed message.\
\
|cffffff00%s|r"] = "Filter the Auction Removed message.\
\
|cffffff00%s|r" -- Requires localization
L["Filter the Auction Sold message.\
\
|cffffff00%s|r"] = "Filter the Auction Sold message.\
\
|cffffff00%s|r" -- Requires localization
L["Filter the Auction Won message.\
\
|cffffff00%s|r"] = "Filter the Auction Won message.\
\
|cffffff00%s|r" -- Requires localization
L["Filter the Bid Accepted message.\
\
|cffffff00%s|r"] = "Filter the Bid Accepted message.\
\
|cffffff00%s|r" -- Requires localization
L["Filter Triggers"] = "Filter Triggers" -- Requires localization
L["Filter whispers based on the sender's level."] = "Filter whispers based on the sender's level." -- Requires localization
L["First message to send.  You can include links.\
\
|cffffffMake sure you hit [ENTER] after you finish typing your message.|r"] = "First message to send.  You can include links.\
\
|cffffffMake sure you hit [ENTER] after you finish typing your message.|r" -- Requires localization
L["Font Face"] = "\208\168\209\128\208\184\209\132\209\130\
" -- Needs review
L["Font Size"] = "\208\160\208\176\208\183\208\188\208\181\209\128 \209\136\209\128\208\184\209\132\209\130\208\176\
" -- Needs review
L["Friends"] = "\208\148\209\128\209\131\208\183\209\140\209\143" -- Needs review
L["General"] = "General" -- Requires localization
L["ginv"] = "ginv" -- Requires localization
L["ginvite"] = "ginvite" -- Requires localization
L["GInvite Alternate Command"] = "GInvite Alternate Command" -- Requires localization
L["Gives you more flexibility in how you invite people to your group and guild."] = "Gives you more flexibility in how you invite people to your group and guild." -- Requires localization
L["GKick Command"] = "\208\154\208\190\208\188\208\176\208\189\208\180\208\176 GKick" -- Needs review
L["GKick Target: |cffffff00%s|r"] = "GKick Target: |cffffff00%s|r" -- Requires localization
L["gold"] = "gold" -- Requires localization
L["Gold Calculator"] = "Gold Calculator" -- Requires localization
L["Group"] = "\208\147\209\128\209\131\208\191\208\191\208\176" -- Needs review
L["Group Invite Links"] = "Group Invite Links" -- Requires localization
L["Group Say Command"] = "Group Say Command" -- Requires localization
L["Guild"] = "\208\147\208\184\208\187\209\140\208\180\208\184\209\143" -- Needs review
L["Guild Channel"] = "\208\154\208\176\208\189\208\176\208\187 \208\179\208\184\208\187\209\140\208\180\208\184\208\184" -- Needs review
L["Guild Chat"] = "\208\167\208\176\209\130 \208\179\208\184\208\187\209\140\208\180\208\184\208\184" -- Needs review
L["Guild Invite Links"] = "Guild Invite Links" -- Requires localization
L["Guildmates"] = "\208\147\208\184\208\187\209\140\208\180\208\184\208\184" -- Needs review
L["Guild Messages"] = "Guild Messages" -- Requires localization
L["Guild Options"] = "Guild Options" -- Requires localization
L["Guild Spam"] = "Guild Spam" -- Requires localization
L["health"] = "health" -- Requires localization
L["Here you can select which channels this module will scan for the keygroupWords to trigger the invite."] = "Here you can select which channels this module will scan for the keygroupWords to trigger the invite." -- Requires localization
L["HH:MM (12-hour)"] = "HH:MM (12 \209\135\208\176\209\129\208\176)" -- Needs review
L["HH:MM (24-hour)"] = "HH:MM (24 \209\135\208\176\209\129\208\176)" -- Needs review
L["HH:MM:SS (24-hour)"] = "HH:MM:SS (24 \209\135\208\176\209\129\208\176)" -- Needs review
L["HH:MM:SS AM (12-hour)"] = "HH:MM:SS AM (12 \209\135\208\176\209\129\208\176)" -- Needs review
L["Hide the spam blocked message asking you to report the person."] = "Hide the spam blocked message asking you to report the person." -- Requires localization
L["Highlight Color"] = "Highlight Color" -- Requires localization
L["honor"] = "honor" -- Requires localization
L["  Honor Points\
"] = "  Honor Points\
" -- Requires localization
L["honour"] = "honour" -- Requires localization
L["Hook the GameTooltip to add information to pet tooltips."] = "Hook the GameTooltip to add information to pet tooltips." -- Requires localization
L["Hook Tooltip"] = "Hook Tooltip" -- Requires localization
L["How to filter any matches."] = "How to filter any matches." -- Requires localization
L["Hunter"] = "\208\158\209\133\208\190\209\130\208\189\208\184\208\186" -- Needs review
L["I am |cff1784d1%s|r"] = "I am |cff1784d1%s|r" -- Requires localization
L["Icon Action"] = "\208\152\208\186\208\190\208\189\208\186\208\176 \208\180\208\181\208\185\209\129\209\130\208\178\208\184\209\143" -- Needs review
L["Icon Orientation"] = "Icon Orientation" -- Requires localization
L["Icon Size"] = "Icon Size" -- Requires localization
L["Icon to the left or right of the item link."] = "Icon to the left or right of the item link." -- Requires localization
L["Identify Chat Frames"] = "Identify Chat Frames" -- Requires localization
L["If no name can be found for an 'alt' rank character, use entire note"] = "\208\149\209\129\208\187\208\184 \208\189\208\181\209\130 \208\184\208\188\208\181\208\189\208\184 \208\176\208\187\209\140\209\130\208\176, \208\184\209\129\208\191\208\190\208\187\209\140\208\183\208\190\208\178\208\176\209\130\209\140 \208\178\209\129\209\142 \208\183\208\176\208\188\208\181\209\130\208\186\209\131." -- Needs review
L["Improved Auction Messages"] = "Improved Auction Messages" -- Requires localization
L["Improve the Auction Expired message.\
\
|cffffff00%s|r"] = "Improve the Auction Expired message.\
\
|cffffff00%s|r" -- Requires localization
L["Improve the Auction Outbid message.\
\
|cffffff00%s|r"] = "Improve the Auction Outbid message.\
\
|cffffff00%s|r" -- Requires localization
L["Improve the Auction Removed message.\
\
|cffffff00%s|r"] = "Improve the Auction Removed message.\
\
|cffffff00%s|r" -- Requires localization
L["Improve the Auction Sold message.\
\
|cffffff00%s|r"] = "Improve the Auction Sold message.\
\
|cffffff00%s|r" -- Requires localization
L["Improve the Auction Won message.\
\
|cffffff00%s|r"] = "Improve the Auction Won message.\
\
|cffffff00%s|r" -- Requires localization
L["Include level"] = "\208\146\208\186\208\187\209\142\209\135\208\184\209\130\209\140 \209\131\209\128\208\190\208\178\208\189\208\184" -- Needs review
L["Include the player's level"] = "\208\146\208\186\208\187\209\142\209\135\208\184\209\130\209\140 \209\131\209\128\208\190\208\178\208\189\208\184 \208\184\208\179\209\128\208\190\208\186\208\176." -- Needs review
L["In Command"] = "\208\146 \208\186\208\190\208\188\208\176\208\189\208\180\208\189\208\190\208\185" -- Needs review
L["Inscription"] = "\208\157\208\176\208\180\208\191\208\184\209\129\209\140" -- Needs review
L["inv"] = "\208\184\208\189\208\178" -- Needs review
L["invite"] = "\208\159\209\128\208\184\208\179\208\187\208\176\209\136\208\176\209\130\209\140" -- Needs review
L["Invite Links"] = "\208\161\209\129\209\139\208\187\208\186\208\184 \208\189\208\176 \208\184\208\189\208\178\208\176\208\185\209\130" -- Needs review
L["Invites"] = "\208\152\208\189\208\178\208\176\208\185\209\130" -- Needs review
L[" is loaded. Type |cff1784d1/ct|r if you need help."] = " is loaded. Type |cff1784d1/ct|r if you need help." -- Requires localization
L[" isn't a number."] = " isn't a number." -- Requires localization
L[" isn't a recognized variable or number."] = " isn't a recognized variable or number." -- Requires localization
L["Jewelcrafting"] = "\208\174\208\178\208\181\208\187\208\184\209\128\208\189\208\190\208\181 \208\180\208\181\208\187\208\190" -- Needs review
L["Joined Channel"] = "Joined Channel" -- Requires localization
L["jp"] = "jp" -- Requires localization
L["jpcap"] = "jpcap" -- Requires localization
L["justice"] = "justice" -- Requires localization
L["  Justice Points\
"] = "  Justice Points\
" -- Requires localization
L["Keeps your channel colors by name rather than by number."] = "\208\161\208\190\209\133\209\128\208\176\208\189\209\143\208\181\209\130 \209\134\208\178\208\181\209\130 \208\186\208\176\208\189\208\176\208\187\208\176 \208\184\208\188\208\181\208\189\208\184, \208\176 \208\189\208\181 \208\191\208\190 \208\189\208\190\208\188\208\181\209\128\209\131." -- Needs review
L["Keybinds"] = "Keybinds" -- Requires localization
L["Leatherworking"] = "\208\154\208\190\208\182\208\181\208\178\208\189\208\184\209\135\208\181\209\129\209\130\208\178\208\190" -- Needs review
L["Left"] = "\208\155\208\181\208\178\208\190" -- Needs review
L["Left Bracket"] = "\208\155\208\181\208\178\209\139\208\185 \208\177\208\187\208\190\208\186." -- Needs review
L["Left Channel"] = "Left Channel" -- Requires localization
L["Lets you alt-click player names to invite them to your party."] = "\208\144\208\187\209\140\209\130-\208\186\208\187\208\184\208\186 \208\189\208\176 \208\184\208\188\208\181\208\189\208\176 \208\184\208\179\209\128\208\190\208\186\208\190\208\178, \209\135\209\130\208\190\208\177\209\139 \208\191\209\128\208\184\208\179\208\187\208\176\209\129\208\184\209\130\209\140 \208\184\209\133 \208\178 \209\129\208\178\208\190\209\142 \208\179\209\128\209\131\208\191\208\191\209\131." -- Needs review
L["Lets you set the justification of text in your chat frames."] = "\208\159\208\190\208\183\208\178\208\190\208\187\209\143\208\181\209\130 \208\178\208\176\208\188 \208\178\209\139\208\177\209\128\208\176\209\130\209\140 \208\191\208\190\208\187\208\190\208\182\208\181\208\189\208\184\208\181 \209\130\208\181\208\186\209\129\209\130\208\176 \208\178 \208\190\208\186\208\189\208\181 \209\135\208\176\209\130\208\176." -- Needs review
L["Level: |cffffff00%s|r, Message: |cffffff00%s|r"] = "Level: |cffffff00%s|r, Message: |cffffff00%s|r" -- Requires localization
L["Level Location"] = "\208\163\209\128\208\190\208\178\208\181\208\189\209\140 \208\187\208\190\208\186\208\176\209\134\208\184\208\184" -- Needs review
L["Level wasn't a number, tell Lockslap. Level was |cffff0000%s|r!"] = "Level wasn't a number, tell Lockslap. Level was |cffff0000%s|r!" -- Requires localization
L["Link All Professions"] = "\208\161\209\129\209\139\208\187\208\186\208\176 \208\146\209\129\208\181 \208\191\209\128\208\190\209\132\208\181\209\129\209\129\208\184\208\184" -- Needs review
L["Link Types"] = "Link Types" -- Requires localization
L["Look in guildnotes for character names, unless a note is set manually"] = "\208\159\208\190\209\129\208\188\208\190\209\130\209\128\208\184\209\130\208\181 \208\178 guildnotes \208\180\208\187\209\143 \209\129\208\184\208\188\208\178\208\190\208\187\209\140\208\189\209\139\209\133 \208\184\208\188\208\181\208\189, \208\181\209\129\208\187\208\184 \208\183\208\176\208\191\208\184\209\129\208\186\209\131 \209\131\209\129\209\130\208\176\208\189\208\176\208\178\208\187\208\184\208\178\208\176\208\181\209\130\209\129\209\143 \208\178\209\128\209\131\209\135\208\189\209\131\209\142" -- Needs review
L["Loot Icons"] = "Loot Icons" -- Requires localization
L["Loss Color"] = "Loss Color" -- Requires localization
L["Mage"] = "\208\156\208\176\208\179" -- Needs review
L["mana"] = "mana" -- Requires localization
L["Mass Ressurection"] = "Mass Ressurection" -- Requires localization
L["Material Quantities"] = "Material Quantities" -- Requires localization
L["Materials Farming"] = "Materials Farming" -- Requires localization
L["Materials to Track"] = "Materials to Track" -- Requires localization
L["Maximum Delay"] = "\208\156\208\176\208\186\209\129\208\184\208\188\208\176\208\187\209\140\208\189\208\190\208\181 \208\178\209\128\208\181\208\188\209\143 \208\183\208\176\208\180\208\181\209\128\208\182\208\186\208\184" -- Needs review
L["Maximum time, in seconds, to wait before announcing."] = "Maximum time, in seconds, to wait before announcing." -- Requires localization
L["Maximum time, in seconds, to wait before bidding someone farewell."] = "Maximum time, in seconds, to wait before bidding someone farewell." -- Requires localization
L["Maximum time, in seconds, to wait before congratulating someone."] = "\208\156\208\176\208\186\209\129\208\184\208\188\208\176\208\187\209\140\208\189\208\190\208\181 \208\178\209\128\208\181\208\188\209\143, \208\178 \209\129\208\181\208\186\209\131\208\189\208\180\208\176\209\133, \208\191\209\128\208\181\208\182\208\180\208\181 \209\135\208\181\208\188 \208\191\208\190\208\183\208\180\209\128\208\176\208\178\208\184\209\130\209\140 \208\186\208\190\208\179\208\190-\209\130\208\190." -- Needs review
L["Maximum time, in seconds, to wait before welcoming someone."] = "\208\156\208\176\208\186\209\129\208\184\208\188\208\176\208\187\209\140\208\189\208\190\208\181 \208\178\209\128\208\181\208\188\209\143 \208\178 \209\129\208\181\208\186\209\131\208\189\208\180\208\176\209\133, \208\191\208\190 \208\184\209\129\209\130\208\181\209\135\208\181\208\189\208\184\208\184 \208\191\209\128\208\184\208\178\208\181\209\130\209\129\209\130\208\178\209\131\209\143 \208\186\208\190\208\179\208\190-\209\130\208\190." -- Needs review
L["Maximum time, in seconds, to wait before whispering someone the link."] = "Maximum time, in seconds, to wait before whispering someone the link." -- Requires localization
L["Message color."] = "Message color." -- Requires localization
L["Message Color"] = "Message Color" -- Requires localization
L["Message highlight color."] = "Message highlight color." -- Requires localization
L["Message Settings"] = "Message Settings" -- Requires localization
L["Messages for when multiple people complete achievements.  A random one will always be selected.\
\
|cffff0000Wildcards do not apply for multiple achievements.|r"] = "Messages for when multiple people complete achievements.  A random one will always be selected.\
\
|cffff0000Wildcards do not apply for multiple achievements.|r" -- Requires localization
L["Messages for when someone completes an achievement.  A random one will always be selected.\
\
|cffFA6400Wildcards|r\
|cff00ff00#name#|r  - Name of the person.\
|cff00ff00#achieve#|r - Achievement they completed."] = "Messages for when someone completes an achievement.  A random one will always be selected.\
\
|cffFA6400Wildcards|r\
|cff00ff00#name#|r  - Name of the person.\
|cff00ff00#achieve#|r - Achievement they completed." -- Requires localization
L["Messages to use in guild chat when someone leaves your guild.\
\
|cffFA6400Wildcards|r\
|cff00ff00#name#|r - Person who left.\
|cff00ff00#guild#|r - Name of your guild."] = "Messages to use in guild chat when someone leaves your guild.\
\
|cffFA6400Wildcards|r\
|cff00ff00#name#|r - Person who left.\
|cff00ff00#guild#|r - Name of your guild." -- Requires localization
L["Messages to use in the whisper when someone leaves your guild.\
\
|cffFA6400Wildcards|r\
|cff00ff00#name#|r - Person who left.\
|cff00ff00#guild#|r - Name of your guild."] = "Messages to use in the whisper when someone leaves your guild.\
\
|cffFA6400Wildcards|r\
|cff00ff00#name#|r - Person who left.\
|cff00ff00#guild#|r - Name of your guild." -- Requires localization
L["Messages to use when someone joins your guild.\
\
|cffFA6400Wildcards|r\
|cff00ff00#name#|r - Person who joined.\
|cff00ff00#guild#|r - Name of your guild."] = "Messages to use when someone joins your guild.\
\
|cffFA6400Wildcards|r\
|cff00ff00#name#|r - Person who joined.\
|cff00ff00#guild#|r - Name of your guild." -- Requires localization
L["Messages to use when someone says \"ding\".\
\
|cffFA6400Wildcards|r\
|cff00ff00#name#|r - Who said ding.\
|cff00ff00#guild#|r - Their current level."] = "Messages to use when someone says \"ding\".\
\
|cffFA6400Wildcards|r\
|cff00ff00#name#|r - Who said ding.\
|cff00ff00#guild#|r - Their current level." -- Requires localization
L["Method by which to send the messages.\
\
|cffff00Alternate is alternating between the two messages.\
Combined is both messages at once.\
Random will randomly pick one of the messages to send.|r"] = "Method by which to send the messages.\
\
|cffff00Alternate is alternating between the two messages.\
Combined is both messages at once.\
Random will randomly pick one of the messages to send.|r" -- Requires localization
L["Minimum Delay"] = "\208\156\208\184\208\189\208\184\208\188\208\176\208\187\209\140\208\189\208\176\209\143 \208\183\208\176\208\180\208\181\209\128\208\182\208\186\208\176." -- Needs review
L["Minimum DK Level"] = "\208\156\208\184\208\189\208\184\208\188\208\176\208\187\209\140\208\189\209\139\208\185 \209\131\209\128\208\190\208\178\208\181\208\189\209\140 \208\148\208\154." -- Needs review
L["Minimum Level"] = "\208\156\208\184\208\189\208\184\208\188\208\176\208\187\209\140\208\189\209\139\208\185 \209\131\209\128\208\190\208\178\208\181\208\189\209\140." -- Needs review
L["Minimum level for a Death Knight to be in order to whisper you."] = "Minimum level for a Death Knight to be in order to whisper you." -- Requires localization
L["Minimum level for a non-Death Knight to be in order to whisper you."] = "Minimum level for a non-Death Knight to be in order to whisper you." -- Requires localization
L["Minimum level required for an achievement to not be filtered."] = "Minimum level required for an achievement to not be filtered." -- Requires localization
L["Minimum time, in seconds, to wait before announcing."] = "Minimum time, in seconds, to wait before announcing." -- Requires localization
L["Minimum time, in seconds, to wait before bidding someone farewell."] = "Minimum time, in seconds, to wait before bidding someone farewell." -- Requires localization
L["Minimum time, in seconds, to wait before congratulating someone."] = "\208\156\208\184\208\189\208\184\208\188\208\176\208\187\209\140\208\189\208\190\208\181 \208\178\209\128\208\181\208\188\209\143, \208\178 \209\129\208\181\208\186\209\131\208\189\208\180\208\176\209\133, \208\191\209\128\208\181\208\182\208\180\208\181 \209\135\208\181\208\188 \208\191\208\190\208\183\208\180\209\128\208\176\208\178\208\184\209\130\209\140 \208\186\208\190\208\179\208\190-\209\130\208\190." -- Needs review
L["Minimum time, in seconds, to wait before welcoming someone."] = "\208\156\208\184\208\189\208\184\208\188\208\176\208\187\209\140\208\189\208\190\208\181 \208\178\209\128\208\181\208\188\209\143 \208\178 \209\129\208\181\208\186\209\131\208\189\208\180\208\176\209\133, \208\191\208\190 \208\184\209\129\209\130\208\181\209\135\208\181\208\189\208\184\208\184 \208\191\209\128\208\184\208\178\208\181\209\130\209\129\209\130\208\178\209\131\209\143 \208\186\208\190\208\179\208\190-\209\130\208\190." -- Needs review
L["Minimum time, in seconds, to wait before whispering someone the link."] = "Minimum time, in seconds, to wait before whispering someone the link." -- Requires localization
L["MM:SS"] = true -- Needs review
L["Module"] = "\208\156\208\190\208\180\209\131\208\187\209\140." -- Needs review
L["Monitor guild chat."] = "\208\156\208\190\208\189\208\184\209\130\208\190\209\128 \209\135\208\176\209\130\208\176 \208\179\208\184\208\187\209\140\208\180\208\184\208\184." -- Needs review
L["Monitor party chat."] = "\208\156\208\190\208\189\208\184\209\130\208\190\209\128 \209\135\208\176\209\130\208\176 \208\179\209\128\209\131\208\191\208\191\209\139." -- Needs review
L["Monitor raid chat."] = "\208\156\208\190\208\189\208\184\209\130\208\190\209\128 \209\135\208\176\209\130\208\176 \209\128\208\181\208\185\208\180\208\176." -- Needs review
L["Monitor say chat."] = "\208\156\208\190\208\189\208\184\209\130\208\190\209\128 \209\135\208\176\209\130\208\176 \208\161\208\186\208\176\208\183\208\176\209\130\209\140." -- Needs review
L["Monitor text in this channel for link triggers."] = "Monitor text in this channel for link triggers." -- Requires localization
L["Monitor whispers."] = "\208\156\208\190\208\189\208\184\209\130\208\190\209\128 \209\135\208\176\209\130\208\176 \208\168\208\181\208\191\208\190\209\130." -- Needs review
L["Monitor yell chat."] = "\208\156\208\190\208\189\208\184\209\130\208\190\209\128 \209\135\208\176\209\130\208\176 \208\154\209\128\208\184\208\186." -- Needs review
L["Monster Emote"] = "\208\173\208\188\208\190\209\134\208\184\208\184 \208\188\208\190\208\189\209\129\209\130\209\128\208\190\208\178" -- Needs review
L["Monster Say"] = "\208\160\208\181\209\135\209\140 \208\188\208\190\208\189\209\129\209\130\209\128\208\190\208\178" -- Needs review
L["Multiple Achievement Messages"] = "Multiple Achievement Messages" -- Requires localization
L["Name"] = "\208\152\208\188\209\143" -- Needs review
L["Name color"] = "\208\157\208\176\208\183\208\178\208\176\208\189\208\184\208\181 \209\134\208\178\208\181\209\130\208\176" -- Needs review
L["Nearby People"] = "\208\160\209\143\208\180\208\190\208\188 \208\187\209\142\208\180\208\184" -- Needs review
L["New Version Notify"] = "New Version Notify" -- Requires localization
L["No custom emotes are currently being used."] = "No custom emotes are currently being used." -- Requires localization
L["None"] = "\208\159\209\131\209\129\209\130\208\190" -- Needs review
L["No RealNames"] = "\208\157\208\181\209\130 RealNames" -- Needs review
L["NoTarget"] = "NoTarget" -- Requires localization
L["Notifies the raid/party when someone places down a feast, cauldron, or repair bot."] = "\208\161\208\190\208\190\208\177\209\137\208\176\208\181\209\130 \208\178 \208\160\208\181\208\185\208\180 \208\184\208\187\208\184 \208\147\209\128\209\131\208\191\208\191\209\131, \208\186\208\190\208\179\208\180\208\176 \208\186\209\130\208\190-\209\130\208\190 \209\129\209\130\208\176\208\178\208\184\209\130 \208\191\208\184\209\128, \208\186\208\190\209\130\208\181\208\187 \208\184\208\187\208\184 \209\128\208\181\208\188-\208\177\208\190\209\130\208\176." -- Needs review
L["Notify on Filter"] = "Notify on Filter" -- Requires localization
L["Notify on new release?"] = "Notify on new release?" -- Requires localization
L["Notify you when a message is filtered."] = "Notify you when a message is filtered." -- Requires localization
L["Notify you when a message/whisper is filtered."] = "Notify you when a message/whisper is filtered." -- Requires localization
L["Not tracking %s."] = "Not tracking %s." -- Requires localization
L["Numbered Channels"] = "Numbered Channels" -- Requires localization
L["Officer"] = "\208\158\209\132\208\184\209\134\208\181\209\128 " -- Needs review
L["Officer Channel"] = "\208\158\209\132\208\184\209\134\208\181\209\128\209\129\208\186\208\184\208\185 \208\186\208\176\208\189\208\176\208\187" -- Needs review
L["Officer Chat"] = "\208\158\209\132\208\184\209\134\208\181\209\128\209\129\208\186\208\184\208\185 \209\135\208\176\209\130." -- Needs review
L["One or more of the changes you have made require you to reload your UI."] = "One or more of the changes you have made require you to reload your UI." -- Requires localization
L["Only filter achievements earned by players below a certain level."] = "Only filter achievements earned by players below a certain level." -- Requires localization
L["Only make these announcements if you are a raid assistant."] = "Only make these announcements if you are a raid assistant." -- Requires localization
L["Opens configuration window."] = "\208\158\209\130\208\186\209\128\209\139\209\130\209\140 \208\190\208\186\208\189\208\190 \208\189\208\176\209\129\209\130\209\128\208\190\208\181\208\186 \209\135\208\176\209\130\208\176." -- Needs review
L["Other Channels"] = "\208\148\209\128\209\131\208\179\208\184\208\181 \208\186\208\176\208\189\208\176\208\187\209\139" -- Needs review
L["Ouput Frame"] = "Ouput Frame" -- Requires localization
L["Outline"] = "\208\148\209\128\208\181\208\178\208\190\208\178\208\184\208\180\208\189\209\139\208\185" -- Needs review
L["Output Color"] = "Output Color" -- Requires localization
L["Output color of the rerouted messages."] = "Output color of the rerouted messages." -- Requires localization
L["Output Frame"] = "Output Frame" -- Requires localization
L["Output Message Every..."] = "Output Message Every..." -- Requires localization
L["Output the message every X times you gain XP."] = "Output the message every X times you gain XP." -- Requires localization
L["Paladin"] = "\208\159\208\176\208\187\208\176\208\180\208\184\208\189" -- Needs review
L["Parameter: |cffffff00%s|r"] = "Parameter: |cffffff00%s|r" -- Requires localization
L["Party"] = "\208\147\209\128\209\131\208\191\208\191\208\176 " -- Needs review
L["Party Channel"] = "\208\154\208\176\208\189\208\176\208\187 \208\179\209\128\209\131\208\191\208\191\209\139 " -- Needs review
L["Party Leader"] = "\208\155\208\184\208\180\208\181\209\128 \208\179\209\128\209\131\208\191\208\191\209\139" -- Needs review
L["Party Members"] = "\208\167\208\187\208\181\208\189\209\139 \208\179\209\128\209\131\208\191\208\191\209\139." -- Needs review
L["Percent Chance"] = "Percent Chance" -- Requires localization
L["Perhaps you meant '*' (multiplication)?"] = "Perhaps you meant '*' (multiplication)?" -- Requires localization
L["Pet Battle Info"] = "Pet Battle Info" -- Requires localization
L["Pet Battles"] = "Pet Battles" -- Requires localization
L["Pet Combat Log"] = "Pet Combat Log" -- Requires localization
L["Place the level before or after the player's name."] = "\208\163\209\129\209\130\208\176\208\189\208\190\208\178\208\184\209\130\209\140 \209\131\209\128\208\190\208\178\208\181\208\189\209\140 \208\180\208\190 \208\184\208\187\208\184 \208\191\208\190\209\129\208\187\208\181 \208\184\208\188\208\181\208\189\208\184 \208\184\208\179\209\128\208\190\208\186\208\176." -- Needs review
L["Player Level"] = "\208\163\209\128\208\190\208\178\208\181\208\189\209\140 \208\152\208\179\209\128\208\190\208\186\208\176." -- Needs review
L["Player level display options."] = "\208\157\208\176\209\129\209\130\209\128\208\190\208\185\208\186\208\184 \208\190\209\130\208\190\208\177\209\128\208\176\208\182\208\181\208\189\208\184\209\143 \209\131\209\128\208\190\208\178\208\189\209\143 \208\184\208\179\209\128\208\190\208\186\208\176." -- Needs review
L["Player Names"] = "\208\163\209\128\208\190\208\178\208\181\208\189\209\140 \208\152\208\179\209\128\208\190\208\186\208\176." -- Needs review
L["Plays a sound, of your choosing (via LibSharedMedia-3.0), whenever a message is received in a given channel."] = "\208\146\208\190\209\129\208\191\209\128\208\190\208\184\208\183\208\178\208\181\208\180\208\181\208\189\208\184\208\181 \208\183\208\178\209\131\208\186\208\176, \208\191\209\128\208\184 \208\191\208\190\208\187\209\131\209\135\208\181\208\189\208\184\208\184 \209\129\208\190\208\190\208\177\209\137\208\181\208\189\208\184\209\143 \208\178 \208\180\208\176\208\189\208\189\208\190\208\188 \208\186\208\176\208\189\208\176\208\187\208\181." -- Needs review
L["Please DON'T use this. Reporting the spam is what gets the hacked accounts used by\
the spammers closed down and realms cleaned up. Also, if many people report a spammer,\
then that spammer looses the ability to chat meaning they can no longer spam, this benefits\
everyone."] = "Please DON'T use this. Reporting the spam is what gets the hacked accounts used by\
the spammers closed down and realms cleaned up. Also, if many people report a spammer,\
then that spammer looses the ability to chat meaning they can no longer spam, this benefits\
everyone." -- Requires localization
L["power"] = "power" -- Requires localization
L["Priest"] = "\208\150\209\128\208\181\209\134" -- Needs review
L["Print Addon Version"] = "Print Addon Version" -- Requires localization
L["Prints a message in the chat with your remain XP needed to level up."] = "Prints a message in the chat with your remain XP needed to level up." -- Requires localization
L["Prints module status."] = "\208\146\209\139\208\178\208\190\208\180\208\184\209\130 \209\129\209\130\208\176\209\130\209\131\209\129 \208\188\208\190\208\180\209\131\208\187\209\143." -- Needs review
L["Print this again."] = "\208\157\208\176\208\191\208\181\209\135\208\176\209\130\208\176\209\130\209\140 \209\141\209\130\208\190 \209\129\208\189\208\190\208\178\208\176." -- Needs review
L["Provides a |cff00ff00/gkick|r command, as it should be."] = "\208\158\208\177\208\181\209\129\208\191\208\181\209\135\208\184\208\178\208\176\208\181\209\130 |cff00ff00/gkick|r \208\186\208\190\208\188\208\176\208\189\208\180\209\131, \208\186\208\176\208\186 \209\141\209\130\208\190 \208\184 \208\180\208\190\208\187\208\182\208\189\208\190 \208\177\209\139\209\130\209\140." -- Needs review
L["Provides a few tools to help me (Lockslap), develop this addon as well as diagnose and fix any errors that are reported.\
\
|cff00ff00You can leave this addon disabled unless I (Lockslap) ask you to enable it for some debugging.|r"] = "Provides a few tools to help me (Lockslap), develop this addon as well as diagnose and fix any errors that are reported.\
\
|cff00ff00You can leave this addon disabled unless I (Lockslap) ask you to enable it for some debugging.|r" -- Requires localization
L["Provides a /gr slash command to let you speak in your group (raid, party, or battleground) automatically."] = "\208\154\208\190\208\188\208\176\208\189\208\180\208\176 /gr \208\191\208\190\208\183\208\178\208\190\208\187\208\184\209\130 \208\178\208\176\208\188 \208\179\208\190\208\178\208\190\209\128\208\184\209\130\209\140 \208\178 \208\178\208\176\209\136\208\181\208\185 \208\179\209\128\209\131\208\191\208\191\208\181 (\209\128\208\181\208\185\208\180\208\181, \208\179\209\128\209\131\208\191\208\191\208\181, \208\184\208\187\208\184 \208\191\208\190\208\187\208\181 \208\177\208\184\209\130\208\178\209\139) \208\176\208\178\209\130\208\190\208\188\208\176\209\130\208\184\209\135\208\181\209\129\208\186\208\184." -- Needs review
L["Provides a /in command to delay the execution of code in macros and other settings."] = "Provides a /in command to delay the execution of code in macros and other settings." -- Requires localization
L["Provides |cff00ff00/ginv|r, an alternative to |cff00ff00/ginvite|r command, for us lazy folks."] = "Provides |cff00ff00/ginv|r, an alternative to |cff00ff00/ginvite|r command, for us lazy folks." -- Requires localization
L["Provides keybinds to make talking in a specific chat easier."] = "Provides keybinds to make talking in a specific chat easier." -- Requires localization
L["Provides options to color player names, add player levels, and add tab completion of player names."] = "\208\158\208\177\208\181\209\129\208\191\208\181\209\135\208\184\208\178\208\176\208\181\209\130 \208\191\208\176\209\128\208\176\208\188\208\181\209\130\209\128\209\139 \209\134\208\178\208\181\209\130\208\176 \208\184\208\188\208\181\208\189\208\176 \208\184\208\179\209\128\208\190\208\186\208\190\208\178, \209\131\209\128\208\190\208\178\208\181\208\189\209\140 \208\184\208\179\209\128\208\190\208\186\208\190\208\178, \208\184 \208\178\208\186\208\187\208\176\208\180\208\186\208\176 \208\183\208\176\208\178\208\181\209\128\209\136\208\181\208\189\208\184\209\143 \208\184\208\188\208\181\208\189\208\176 \208\184\208\179\209\128\208\190\208\186\208\190\208\178." -- Needs review
L["Put each emote on a separate line.\
Separate the command from the text with a colon (\":\")."] = "Put each emote on a separate line.\
Separate the command from the text with a colon (\":\")." -- Requires localization
L["Quality Notification"] = "Quality Notification" -- Requires localization
L["Raid"] = "\208\160\208\181\208\185\208\180" -- Needs review
L["Raid Assistant"] = "Raid Assistant" -- Requires localization
L["Raid Boss Emote"] = "\208\173\208\188\208\190\209\134\208\184\208\184 \208\160\208\181\208\185\208\180 \208\145\208\190\209\129\209\129\208\190\208\178" -- Needs review
L["Raid Channel"] = "\208\154\208\176\208\189\208\176\208\187 \208\160\208\181\208\185\208\180\208\176" -- Needs review
L["Raid Helper"] = "Raid Helper" -- Requires localization
L["Raid Leader"] = "Raid Leader" -- Requires localization
L["Raid Members"] = "\208\167\208\187\208\181\208\189\209\139 \209\128\208\181\208\185\208\180\208\176." -- Needs review
L["Raid Warning"] = "Raid Warning" -- Requires localization
L["Raid Warning Channel"] = "\208\154\208\176\208\189\208\176\208\187 \208\158\208\177\209\138\209\143\208\178\208\187\208\181\208\189\208\184\208\185 \208\160\208\181\208\185\208\180\209\131" -- Needs review
L["Random"] = "Random" -- Requires localization
L["RANDOM"] = "RANDOM" -- Requires localization
L["RealID Brackets"] = "\208\161\208\186\208\190\208\177\208\186\208\184 RealID" -- Needs review
L["RealID Conversation"] = "\208\160\208\176\208\183\208\179\208\190\208\178\208\190\209\128 RealID" -- Needs review
L["RealID Whisper"] = "\208\168\209\145\208\191\208\190\209\130 RealID " -- Needs review
L["Really remove this word from your trigger list?"] = "\208\146\209\139 \208\180\208\181\208\185\209\129\209\130\208\178\208\184\209\130\208\181\208\187\209\140\208\189\208\190 \209\133\208\190\209\130\208\184\209\130\208\181 \209\131\208\180\208\176\208\187\208\184\209\130\209\140 \209\141\209\130\208\190 \209\129\208\187\208\190\208\178\208\190 \208\184\208\183 \208\184\209\129\209\133\208\190\208\180\208\189\208\190\208\179\208\190 \209\129\208\191\208\184\209\129\208\186\208\176?" -- Needs review
L["Remembers the history of the editbox across sessions."] = "\208\159\208\190\208\188\208\189\208\184\209\130\209\140 \208\184\209\129\209\130\208\190\209\128\208\184\209\142 \208\190\208\186\208\189\208\176 \209\128\208\181\208\180\208\176\208\186\209\130\208\184\209\128\208\190\208\178\208\176\208\189\208\184\209\143 \208\188\208\181\208\182\208\180\209\131 \209\129\208\181\209\129\209\129\208\184\209\143\208\188\208\184." -- Needs review
L["Remove"] = "Remove" -- Requires localization
L["Remove a word from your group invite trigger list"] = "Remove a word from your group invite trigger list" -- Requires localization
L["Remove a word from your guild invite trigget list."] = "Remove a word from your guild invite trigget list." -- Requires localization
L["Remove Group Trigger"] = "Remove Group Trigger" -- Requires localization
L["Remove Guild Trigger"] = "Remove Guild Trigger" -- Requires localization
L["Remove Icon Only"] = "Remove Icon Only" -- Requires localization
L[", removing from list"] = ", removing from list" -- Requires localization
L["Repair Bot"] = "\208\160\208\181\208\188\208\190\208\189\209\130\208\189\209\139\208\185 \209\128\208\190\208\177\208\190\209\130" -- Needs review
L["Repeat Command"] = "Repeat Command" -- Requires localization
L["Replace"] = "Replace" -- Requires localization
L["Reported by %s"] = "Reported by %s" -- Requires localization
L["Reputation"] = "Reputation" -- Requires localization
L["Reputation Color"] = "Reputation Color" -- Requires localization
L["Reroute Auction Messages"] = "Reroute Auction Messages" -- Requires localization
L["Reset"] = "Reset" -- Requires localization
L["Reset ChatFrame text justifications to defaults (left)."] = "\208\161\208\177\209\128\208\190\209\129\208\184\209\130\209\140 \208\189\208\176\209\129\209\130\209\128\208\190\208\185\208\186\208\184 \208\178\209\139\209\128\208\176\208\178\208\189\208\184\208\178\208\176\208\189\208\184\209\143 \209\130\208\181\208\186\209\129\209\130\208\176 \208\190\208\186\208\189\208\176 \209\135\208\176\209\130\208\176. (\208\187\208\181\208\178\208\190)" -- Needs review
L["Reset Data"] = "\208\161\208\177\209\128\208\190\209\129 \208\180\208\176\209\130\209\139" -- Needs review
L["Reset Font Data"] = "\208\161\208\177\209\128\208\190\209\129 \208\189\208\176\209\129\209\130\209\128\208\190\208\181\208\186 \209\136\209\128\208\184\209\132\209\130\208\176." -- Needs review
L["Reset Materials"] = "Reset Materials" -- Requires localization
L["Resets all chat frames to their original font settings."] = "\208\161\208\177\209\128\208\190\209\129\208\184\209\130\209\140 \208\178\209\129\208\181 \208\189\208\176\209\129\209\130\209\128\208\190\208\185\208\186\208\184 \208\190\208\186\208\190\208\189 \209\135\208\176\209\130\208\176 \208\186 \208\191\208\181\209\128\208\178\208\190\208\189\208\176\209\135\208\176\208\187\209\140\208\189\209\139\208\188 \208\189\208\176\209\129\209\130\209\128\208\190\208\185\208\186\208\176\208\188 \209\136\209\128\208\184\209\132\209\130\208\176." -- Needs review
L["Reset Text Justitification"] = "\208\161\208\177\209\128\208\190\209\129 \208\178\209\139\209\128\208\176\208\178\208\189\208\184\208\178\208\176\208\189\208\184\208\181 \209\130\208\181\208\186\209\129\209\130\208\176" -- Needs review
L["Respond to Whispers"] = "Respond to Whispers" -- Requires localization
L["Respond to whispers notifying them that they don't meet the level requirement."] = "Respond to whispers notifying them that they don't meet the level requirement." -- Requires localization
L["Right"] = "\208\159\209\128\208\176\208\178\208\190" -- Needs review
L["Right Bracket"] = "\208\159\209\128\208\176\208\178\208\176\209\143 \209\129\208\186\208\190\208\177\208\186\208\176" -- Needs review
L["Ritual of Refreshment"] = "\208\158\208\177\209\128\209\143\208\180 \209\129\208\190\209\130\208\178\208\190\209\128\208\181\208\189\208\184\209\143 \209\143\209\129\209\130\208\178" -- Needs review
L["Ritual of Souls"] = "\208\160\208\184\209\130\209\131\208\176\208\187 \208\180\209\131\209\136" -- Needs review
L["Ritual of Summoning"] = "\208\160\208\184\209\130\209\131\208\176\208\187 \208\191\209\128\208\184\208\183\209\139\208\178\208\176" -- Needs review
L["Rogue"] = "\208\160\208\190\208\179" -- Needs review
L["Roll Color"] = "Roll Color" -- Requires localization
L["Roll Pattern: |cffffff00%s|r"] = "Roll Pattern: |cffffff00%s|r" -- Requires localization
L["Save all /who data"] = "\208\161\208\190\209\133\209\128\208\176\208\189\208\184\209\130\209\140 \208\178\209\129\208\181 /who \208\180\208\176\208\189\208\189\209\139\208\181" -- Needs review
L["Save class data from friends between sessions."] = "\208\161\208\190\209\133\209\128\208\176\208\189\208\184\209\130\209\140 \208\180\208\176\208\189\208\189\209\139\208\181 \208\186\208\187\208\176\209\129\209\129\208\190\208\178 \209\131 \208\180\209\128\209\131\208\183\208\181\208\185, \208\188\208\181\208\182\208\180\209\131 \209\129\208\181\209\129\209\129\208\184\209\143\208\188\208\184." -- Needs review
L["Save class data from groups between sessions."] = "\208\161\208\190\209\133\209\128\208\176\208\189\208\184\209\130\209\140 \208\180\208\176\208\189\208\189\209\139\208\181 \208\186\208\187\208\176\209\129\209\129\208\190\208\178 \208\184\208\183 \208\179\209\128\209\131\208\191\208\191\209\139, \208\188\208\181\208\182\208\180\209\131 \209\129\208\181\209\129\209\129\208\184\209\143\208\188\208\184." -- Needs review
L["Save class data from guild between sessions."] = "\208\161\208\190\209\133\209\128\208\176\208\189\209\143\209\130\209\140 \208\180\208\176\208\189\208\189\209\139\208\181 \208\186\208\187\208\176\209\129\209\129\208\190\208\178 \208\178 \208\179\208\184\208\187\209\140\208\180\208\184\208\184, \208\188\208\181\208\182\208\180\209\131 \209\129\208\181\209\129\209\129\208\184\209\143\208\188\208\184." -- Needs review
L["Save class data from target/mouseover between sessions."] = "\208\161\208\190\209\133\209\128\208\176\208\189\209\143\209\130\209\140 \208\180\208\176\208\189\208\189\209\139\208\181 \208\186\208\187\208\176\209\129\209\129\208\176 \208\190\209\130 \209\134\208\181\208\187\208\184, \208\188\208\181\208\182\208\180\209\131 \209\129\208\181\209\129\209\129\208\184\209\143\208\188\208\184." -- Needs review
L["Save class data from /who queries between sessions."] = "\208\161\208\190\209\133\209\128\208\176\208\189\208\184\209\130\209\140 \208\180\208\176\208\189\208\189\209\139\208\181 \208\186\208\187\208\176\209\129\209\129\208\190\208\178 /who, \208\188\208\181\208\182\208\180\209\131 \209\129\208\181\209\129\209\129\208\184\209\143\208\188\208\184." -- Needs review
L["Save Data"] = "\208\161\208\190\209\133\209\128\208\176\208\189\208\184\209\130\209\140" -- Needs review
L["Save data between sessions. Will increase memory usage"] = "\208\161\208\190\209\133\209\128\208\176\208\189\209\143\209\130\209\140 \208\180\208\176\208\189\208\189\209\139\208\181 \208\188\208\181\208\182\208\180\209\131 \209\129\208\181\208\176\208\189\209\129\208\176\208\188\208\184. \208\159\209\128\208\184\208\178\208\181\208\180\208\181\209\130 \208\186 \209\131\208\178\208\181\208\187\208\184\209\135\208\181\208\189\208\184\209\142 \208\191\208\190\209\130\209\128\208\181\208\177\208\187\209\143\208\181\208\188\208\190\208\185 \208\191\208\176\208\188\209\143\209\130\208\184 \208\188\208\190\208\180\208\184\209\132\208\184\208\186\208\176\209\134\208\184\208\181\208\185." -- Needs review
L["Say"] = "\208\161\208\186\208\176\208\183\208\176\209\130\209\140" -- Needs review
L["Say Chat"] = "\208\167\208\176\209\130 \208\161\208\186\208\176\208\183\208\176\209\130\209\140" -- Needs review
L["%s  Conquest Cap\
"] = "%s  Conquest Cap\
" -- Requires localization
L["Scroll Reminder"] = "Scroll \208\189\208\176\208\191\208\190\208\188\208\184\208\189\208\176\208\189\208\184\208\181\
" -- Needs review
L["Second message to send.  You can include links.\
\
|cffffffMake sure you hit [ENTER] after you finish typing your message.|r"] = "Second message to send.  You can include links.\
\
|cffffffMake sure you hit [ENTER] after you finish typing your message.|r" -- Requires localization
L["Select a color for this channel."] = "\208\146\209\139\208\177\208\181\209\128\208\184\209\130\208\181 \209\134\208\178\208\181\209\130 \208\180\208\187\209\143 \209\141\209\130\208\190\208\179\208\190 \208\186\208\176\208\189\208\176\208\187\208\176." -- Needs review
L["Select a method for coloring player names"] = "\208\146\209\139\208\177\208\181\209\128\208\184\209\130\208\181 \208\188\208\181\209\130\208\190\208\180 \208\190\208\186\209\128\208\176\209\129\208\186\208\184 \208\184\208\188\208\181\208\189 \208\184\208\179\209\128\208\190\208\186\208\190\208\178." -- Needs review
L["Select the custom color to use for alt names"] = "Select the custom color to use for alt names" -- Requires localization
L["Select which factions you would like to receive notifications for."] = "Select which factions you would like to receive notifications for." -- Requires localization
L["Send a tell to your target."] = "Send a tell to your target." -- Requires localization
L["Send a whisper to the person who left."] = "\208\161\208\186\208\176\208\183\208\176\209\130\209\140 \209\136\208\181\208\191\208\190\209\130\208\190\208\188 \209\130\208\190\208\188\209\131 \209\135\209\130\208\190 \209\131\209\136\208\181\208\187." -- Needs review
L["Send Guild Messages"] = "\208\167\208\176\209\130 \208\179\208\184\208\187\209\140\208\180\208\184\208\184" -- Needs review
L["Send messages as a raid warning.  |cffffff00Only applies if you are the raid leader, or an assistant.|r"] = "Send messages as a raid warning.  |cffffff00Only applies if you are the raid leader, or an assistant.|r" -- Requires localization
L["Send messages to guild chat when someone leaves."] = "\208\158\209\130\208\191\209\128\208\176\208\178\208\186\208\176 \209\129\208\190\208\190\208\177\209\137\208\181\208\189\208\184\208\185 \208\178 \209\135\208\176\209\130\208\181 \208\179\208\184\208\187\209\140\208\180\208\184\208\184, \208\186\208\190\208\179\208\180\208\176 \208\186\209\130\208\190-\209\130\208\190 \209\131\209\133\208\190\208\180\208\184\209\130." -- Needs review
L["Send Whisper"] = "\208\167\208\176\209\130 \208\168\208\181\208\191\208\190\209\130" -- Needs review
L["Separator"] = "\208\160\208\176\208\183\208\180\208\181\208\187\208\184\209\130\208\181\208\187\209\140" -- Needs review
L["Set Main"] = "Set Main" -- Requires localization
L["Set the coloring mode for alt names"] = "Set the coloring mode for alt names" -- Requires localization
L["Settings"] = "\208\157\208\176\209\129\209\130\209\128\208\190\208\185\208\186\208\184" -- Needs review
L["%s from |cff00ff00%s|r was blocked."] = "%s from |cff00ff00%s|r was blocked." -- Requires localization
L["Shaman"] = "\208\168\208\176\208\188\208\176\208\189" -- Needs review
L["%s has casted %s."] = "%s has casted %s." -- Requires localization
L["%s has prepared a %s."] = "%s has prepared a %s." -- Requires localization
L["%s has put down a %s."] = "%s has put down a %s." -- Requires localization
L["Show a report player popup (showing the spam) instead of printing in chat"] = "Show a report player popup (showing the spam) instead of printing in chat" -- Requires localization
L["Show current to total XP percentage."] = "Show current to total XP percentage." -- Requires localization
L["Show Percentage"] = "Show Percentage" -- Requires localization
L["Show remaining rested XP."] = "Show remaining rested XP." -- Requires localization
L["Show Rested XP"] = "Show Rested XP" -- Requires localization
L["Show Spam Popup"] = "Show Spam Popup" -- Requires localization
L["Show toon names instead of real names"] = "\208\159\208\190\208\186\208\176\208\183\209\139\208\178\208\176\209\130\209\140 \208\184\208\188\208\181\208\189\208\176 \208\191\208\181\209\128\209\129\208\190\208\189\208\176\208\182\208\181\208\185 \208\178 \208\188\208\181\209\129\209\130\208\190 \208\157\208\176\209\129\209\130\208\190\209\143\209\137\208\181\208\179\208\190 \208\152\208\188\208\181\208\189\208\184" -- Needs review
L["Show Total XP"] = "Show Total XP" -- Requires localization
L["Show total XP needed to level."] = "Show total XP needed to level." -- Requires localization
L["Show welcome message when logging in."] = "Show welcome message when logging in." -- Requires localization
L["silver"] = "silver" -- Requires localization
L["Similar to the |cffffffIn Command|r module, except it will repeat the command X times."] = "Similar to the |cffffffIn Command|r module, except it will repeat the command X times." -- Requires localization
L["%s is casting %s.  Click!"] = "%s is casting %s.  Click!" -- Requires localization
L["Size of the coin icons.  Generally you want to use your font size or smaller."] = "Size of the coin icons.  Generally you want to use your font size or smaller." -- Requires localization
L["%s  Justice Cap\
"] = "%s  Justice Cap\
" -- Requires localization
L["Smart Group Channel"] = "Smart Group Channel" -- Requires localization
L["%s or %s"] = "%s or %s" -- Requires localization
L["Sound to play when a message in %s is received.\
\
|cff00ff00To disable set to \"None\"|r."] = "\208\159\209\128\208\190\208\184\208\179\209\128\209\139\208\178\208\176\209\130\209\140 \208\183\208\178\209\131\208\186 \208\186\208\190\208\179\208\180\208\176 %s \208\191\208\190\208\187\209\131\209\135\208\184\208\187 \209\129\208\190\208\190\208\177\209\137\208\181\208\189\208\184\208\181.\
\
|cff00ff00To disable set to \"None\"|r." -- Needs review
L["Spam Delay"] = "\208\151\208\176\208\180\208\181\209\128\208\182\208\186\208\176 \209\129\208\191\208\176\208\188\208\176" -- Needs review
L["Spam Filter"] = "\208\161\208\191\208\176\208\188 \209\132\208\184\208\187\209\140\209\130\209\128" -- Needs review
L["Spam Interval"] = "Spam Interval" -- Requires localization
L["Spam interval changed to |cffffff00%d|r"] = "Spam interval changed to |cffffff00%d|r" -- Requires localization
L["Spam Mode"] = "Spam Mode" -- Requires localization
L["Spam Throttle"] = "Spam Throttle" -- Requires localization
L["%s reputation left until %s with %s."] = "%s reputation left until %s with %s." -- Requires localization
L["%s reputation needed until %s with %s."] = "%s reputation needed until %s with %s." -- Requires localization
L["%s, %s, %s  Player's Money\
"] = "%s, %s, %s  Player's Money\
" -- Requires localization
L["%s, %s, %s  Player's Stats\
"] = "%s, %s, %s  Player's Stats\
" -- Requires localization
L["Standard Emote: |cffffff00%s|r"] = "Standard Emote: |cffffff00%s|r" -- Requires localization
L["Standard Emotes"] = "Standard Emotes" -- Requires localization
L["Standing Color"] = "Standing Color" -- Requires localization
L["Start"] = "Start" -- Requires localization
L["STARTED"] = "STARTED" -- Requires localization
L["Stop"] = "Stop" -- Requires localization
L["STOPPED"] = "STOPPED" -- Requires localization
L["Strip Links"] = "Strip Links" -- Requires localization
L["Strip RealID brackets"] = "Strip RealID brackets" -- Requires localization
L["Suppress"] = "\208\159\208\190\208\180\208\176\208\178\208\187\209\143\209\130\209\140" -- Needs review
L["Suppress Recount/Skada/TinyDPS output into a clickable link, or filter it entirely."] = "\208\159\208\190\208\180\208\176\208\178\208\187\209\143\209\130\209\140 \208\190\209\130\209\135\208\181\209\130\209\139 Recount/Skada/TinyDPS \209\129\208\182\208\184\208\188\208\176\209\143 \208\184\209\133 \208\178 \208\184\208\189\209\130\208\181\209\128\208\176\208\186\209\130\208\184\208\178\208\189\209\139\208\181 \209\129\209\129\209\139\208\187\208\186\208\184, \208\184\208\187\208\184 \209\132\208\184\208\187\209\140\209\130\209\128\208\190\208\178\208\176\209\130\209\140 \208\184\209\133." -- Needs review
L["Suppress report message."] = "Suppress report message." -- Requires localization
L["%s  Valor Cap\
"] = "%s  Valor Cap\
" -- Requires localization
L["Symbol: |cffffff00%s|r"] = "Symbol: |cffffff00%s|r" -- Requires localization
L["Tailoring"] = "\208\159\208\190\209\128\209\130\208\189\209\143\208\182\208\189\208\190\208\181 \208\180\208\181\208\187\208\190" -- Needs review
L["Talk to your group based on party/raid status."] = "Talk to your group based on party/raid status." -- Requires localization
L["Target: |cffffff00%s|r"] = "Target: |cffffff00%s|r" -- Requires localization
L["Target/Mouseover"] = "\208\166\208\181\208\187\209\140/\208\164\208\190\208\186\209\131\209\129" -- Needs review
L["Tell Target"] = "Tell Target" -- Requires localization
L["Text Justification"] = "\208\146\209\139\209\128\208\176\208\178\208\189\208\184\208\178\208\176\208\189\208\184\208\181 \209\130\208\181\208\186\209\129\209\130\208\176\
" -- Needs review
L["Text justification for ChatFrame %d."] = "Text justification for ChatFrame %d." -- Requires localization
L["The amount of each material you'd like to farm.  If you want an unlimited amount simply put a 0.  You must add a quantity for every entry, and it must correspond to the same line in the other box."] = "The amount of each material you'd like to farm.  If you want an unlimited amount simply put a 0.  You must add a quantity for every entry, and it must correspond to the same line in the other box." -- Requires localization
L["The default color to use to color names."] = "The default color to use to color names." -- Requires localization
L["The interval must be a |cff00ff00%s|r between |cff00ff00%d|r and |cff00ff00%d|r."] = "The interval must be a |cff00ff00%s|r between |cff00ff00%d|r and |cff00ff00%d|r." -- Requires localization
L["The name or ID of the material you'd like to track."] = "The name or ID of the material you'd like to track." -- Requires localization
L["The percent chance the module has to bid someone farewell.  Higher the chance, the more likely it is to run.  This is a means to throttle, so as to prevent spam/annoyances."] = "The percent chance the module has to bid someone farewell.  Higher the chance, the more likely it is to run.  This is a means to throttle, so as to prevent spam/annoyances." -- Requires localization
L["The percent chance the module has to congratulate someone.  Higher the chance, the more likely it is to run.  This is a means to throttle, so as to prevent spam/annoyances."] = "The percent chance the module has to congratulate someone.  Higher the chance, the more likely it is to run.  This is a means to throttle, so as to prevent spam/annoyances." -- Requires localization
L["The percent chance the module has to welcome someone.  Higher the chance, the more likely it is to run.  This is a means to throttle, so as to prevent spam/annoyances."] = "The percent chance the module has to welcome someone.  Higher the chance, the more likely it is to run.  This is a means to throttle, so as to prevent spam/annoyances." -- Requires localization
L["These are the keywords that the addon will look for first, when it finds a match then it will look for the actual profession being requested."] = "These are the keywords that the addon will look for first, when it finds a match then it will look for the actual profession being requested." -- Requires localization
L["The size of the icon in the chat frame."] = "The size of the icon in the chat frame." -- Requires localization
L["The time, in seconds, it takes for the same person to trigger the addon again."] = "The time, in seconds, it takes for the same person to trigger the addon again." -- Requires localization
L["The time, in seconds, it takes for the same person to trigger the addon by saying ding."] = "The time, in seconds, it takes for the same person to trigger the addon by saying ding." -- Requires localization
L["Thick Outline"] = "\208\162\208\190\208\187\209\129\209\130\209\139\208\181 \208\186\208\190\208\189\209\130\209\131\209\128\209\139" -- Needs review
L["Things to Track"] = "Things to Track" -- Requires localization
L["This addon is designed to add a lot of the functionality of full fledged chat addons like Prat or Chatter, but without a lot of the unneeded bloat.  I wrote it to be as lightweight as possible, while still powerful enough to accomplish it's intended function.\
"] = "This addon is designed to add a lot of the functionality of full fledged chat addons like Prat or Chatter, but without a lot of the unneeded bloat.  I wrote it to be as lightweight as possible, while still powerful enough to accomplish it's intended function.\
" -- Requires localization
L["This module will send a chat message every time you loot an item on your list with how many you have, and if applicable it will tell you how many more you need based on your set quantity.  This is useful if you need X amount of Y to be able to cook Z."] = "This module will send a chat message every time you loot an item on your list with how many you have, and if applicable it will tell you how many more you need based on your set quantity.  This is useful if you need X amount of Y to be able to cook Z." -- Requires localization
L["This will disable the ChatFrames annoying habit of having the chat text fade away after a certain amount of time."] = "This will disable the ChatFrames annoying habit of having the chat text fade away after a certain amount of time." -- Requires localization
L["Throttle Interval"] = "Throttle Interval" -- Requires localization
L["Throttle Messages"] = "Throttle Messages" -- Requires localization
L["Throttle output messages to prevent spam."] = "Throttle output messages to prevent spam." -- Requires localization
L["Time, in seconds, between messages being sent."] = "Time, in seconds, between messages being sent." -- Requires localization
L["Time, in seconds, in between running the command."] = "Time, in seconds, in between running the command." -- Requires localization
L["Time, in seconds, the module will wait after the first line is found to assume it is complete.\
\
|cffffff00One (1) second seems to work.|r"] = "Time, in seconds, the module will wait after the first line is found to assume it is complete.\
\
|cffffff00One (1) second seems to work.|r" -- Requires localization
L["Time, in seconds, to throttle output messages to prevent spam."] = "Time, in seconds, to throttle output messages to prevent spam." -- Requires localization
L["Timer is currently running, you must stop it first before changing the interval."] = "Timer is currently running, you must stop it first before changing the interval." -- Requires localization
L["Timestamp color"] = "\208\166\208\178\208\181\209\130 \208\178\209\128\208\181\208\188\208\181\208\189\208\184" -- Needs review
L["Timestamp format"] = "\208\164\208\190\209\128\208\188\208\176\209\130 \208\178\209\128\208\181\208\188\208\181\208\189\208\184" -- Needs review
L["Timestamps"] = "\208\146\209\128\208\181\208\188\209\143" -- Needs review
L["TOC Version: |cff1784d1%s|r"] = "TOC Version: |cff1784d1%s|r" -- Requires localization
L["Toggle coloring and change of the chat frame for pet combat log messages."] = "Toggle coloring and change of the chat frame for pet combat log messages." -- Requires localization
L["Toggle coloring and changing of the chat frame for pet battle info messages."] = "Toggle coloring and changing of the chat frame for pet battle info messages." -- Requires localization
L["Toggle the pet quality notifications when you join a wild pet battle."] = "Toggle the pet quality notifications when you join a wild pet battle." -- Requires localization
L["Track Pets"] = "Track Pets" -- Requires localization
L["Track Stable Masters"] = "Track Stable Masters" -- Requires localization
L["Trade"] = "Trade" -- Requires localization
L["Triggers"] = "\208\162\209\128\208\184\208\179\208\179\208\181\209\128\209\139" -- Needs review
L["/tt"] = "/tt" -- Requires localization
L["Unbalanced parameter count. Trailing Symbol: |cffffff00%s|r"] = "Unbalanced parameter count. Trailing Symbol: |cffffff00%s|r" -- Requires localization
L["Unrecognized Symbol: |cffffff00%s|r"] = "Unrecognized Symbol: |cffffff00%s|r" -- Requires localization
L["Unset variable |cffffff00%s|r."] = "Unset variable |cffffff00%s|r." -- Requires localization
L["Use channel color"] = "\208\152\209\129\208\191\208\190\208\187\209\140\208\183\208\190\208\178\208\176\209\130\209\140 \209\134\208\178\208\181\209\130 \208\186\208\176\208\189\208\176\208\187\208\176." -- Needs review
L["Use Channel Color"] = "Use Channel Color" -- Requires localization
L["Use Coins"] = "Use Coins" -- Requires localization
L["Use coins in the answers instead of abbreviations."] = "Use coins in the answers instead of abbreviations." -- Requires localization
L["Use Custom Color"] = "\208\152\209\129\208\191\208\190\208\187\209\140\208\183\208\190\208\178\208\176\208\189\208\184\208\181 \208\191\208\190\208\187\209\140\208\183\208\190\208\178\208\176\209\130\208\181\208\187\209\140\209\129\208\186\208\184\209\133 \209\134\208\178\208\181\209\130\208\190\208\178" -- Needs review
L["Use guildnotes"] = "\208\152\209\129\208\191\208\190\208\187\209\140\208\183\209\131\208\185\209\130\208\181 \208\183\208\176\208\188\208\181\209\130\208\186\208\184 \208\179\208\184\208\187\209\140\208\180\208\184\208\184" -- Needs review
L["Use Level Threshold"] = "Use Level Threshold" -- Requires localization
L["Use PlayerNames Coloring"] = "Use PlayerNames Coloring" -- Requires localization
L["Use Server Time"] = "\208\152\209\129\208\191\208\190\208\187\209\140\208\183\208\190\208\178\208\176\209\130\209\140 \208\178\209\128\208\181\208\188\209\143 \209\129\208\181\209\128\208\178\208\181\209\128\208\176" -- Needs review
L["Use server time, rather than local."] = "\208\152\209\129\208\191\208\190\208\187\209\140\208\183\208\190\208\178\208\176\209\130\209\140 \208\178\209\128\208\181\208\188\209\143 \209\129\208\181\209\128\208\178\208\181\209\128\208\176 \208\176 \208\189\208\181 \208\188\208\181\209\129\209\130\208\189\208\190\208\181." -- Needs review
L["Use Tab Complete"] = "Use Tab Complete" -- Requires localization
L["Use tab key to automatically complete character names."] = "Use tab key to automatically complete character names." -- Requires localization
L["Valid Events"] = "Valid Events" -- Requires localization
L["valor"] = "valor" -- Requires localization
L["  Valor Points\
"] = "  Valor Points\
" -- Requires localization
L["Variable |cffffff00%s|r is set to |cff00ff00%s|r."] = "Variable |cffffff00%s|r is set to |cff00ff00%s|r." -- Requires localization
L["Variable |cffffff00%s|r set to |cff00ff00%s|r."] = "Variable |cffffff00%s|r set to |cff00ff00%s|r." -- Requires localization
L["Various Developer Tools"] = "Various Developer Tools" -- Requires localization
L["Version"] = "Version" -- Requires localization
L["Version: |cff1784d1%s|r"] = "Version: |cff1784d1%s|r" -- Requires localization
L["vp"] = "vp" -- Requires localization
L["vpcap"] = "vpcap" -- Requires localization
L["Warlock"] = "\208\167\208\181\209\128\208\189\208\190\208\186\208\189\208\184\208\182\208\189\208\184\208\186" -- Needs review
L["Warrior"] = "\208\146\208\190\208\184\208\189" -- Needs review
L["Welcome Message"] = "Welcome Message" -- Requires localization
L["Welcome Messages"] = "\208\161\208\190\208\190\208\177\209\137\208\181\208\189\208\184\208\181 \208\148\208\190\208\177\209\128\208\190 \208\191\208\190\208\182\208\176\208\187\208\190\208\178\208\176\209\130\209\140" -- Needs review
L["What to do when a link is found.\
\
|cffffff00Replace:|r  Replaces link with just the text.\
|cffffff00Filter:|r  Filters the line.\
|cffffff00Remove:|r  Removes the link."] = "What to do when a link is found.\
\
|cffffff00Replace:|r  Replaces link with just the text.\
|cffffff00Filter:|r  Filters the line.\
|cffffff00Remove:|r  Removes the link." -- Requires localization
L["What to do with Recount/Skada/TinyDPS reports in this channel."] = "What to do with Recount/Skada/TinyDPS reports in this channel." -- Requires localization
L["    When I first started using ElvUI around the beginning of Cataclysm's release I noticed that there were some chat functionality that I wanted, but wasn't included with ElvUI.  I came across Prat and Chatter, but found that they had too many modules that I didn't want and both addons do use a fair bit of memory.  So I decided to write my own version, which is when ElvUI_ChatTweaks was born.  Since then I have made sure that this addon is as bug free as possible, as well as being up to date with the latest API available, and I am constantly adding new functionality.  If there's any features you'd like to see added please contact me and I'll see what I can do.\
\
Thanks,\
|cffffff00Lockslap|r"] = "    When I first started using ElvUI around the beginning of Cataclysm's release I noticed that there were some chat functionality that I wanted, but wasn't included with ElvUI.  I came across Prat and Chatter, but found that they had too many modules that I didn't want and both addons do use a fair bit of memory.  So I decided to write my own version, which is when ElvUI_ChatTweaks was born.  Since then I have made sure that this addon is as bug free as possible, as well as being up to date with the latest API available, and I am constantly adding new functionality.  If there's any features you'd like to see added please contact me and I'll see what I can do.\
\
Thanks,\
|cffffff00Lockslap|r" -- Requires localization
L["When setting a variable the variable name must be the first parameter."] = "When setting a variable the variable name must be the first parameter." -- Requires localization
L["Whisper"] = "\208\168\208\181\208\191\209\130\208\176\209\130\209\140" -- Needs review
L["Whisper Filter"] = "\208\164\208\184\208\187\209\140\209\130\209\128 \209\136\208\181\208\191\208\190\209\130\208\176." -- Needs review
L["Whisper Messages"] = "Whisper Messages" -- Requires localization
L["Whisper Options"] = "\208\157\208\176\209\129\209\130\209\128\208\190\208\185\208\186\208\184 \209\136\208\181\208\191\208\190\209\130\208\176" -- Needs review
L["Whispers"] = "\208\168\208\181\208\191\208\190\209\130" -- Needs review
L["Who"] = "\208\154\209\130\208\190" -- Needs review
L["Who: |cffffff00%s|r, Roll: |cffffff00%s|r, Min: |cffffff00%s|r, Max: |cffffff00%s|r"] = "Who: |cffffff00%s|r, Roll: |cffffff00%s|r, Min: |cffffff00%s|r, Max: |cffffff00%s|r" -- Requires localization
L["Who is %s's main?"] = "Who is %s's main?" -- Requires localization
L["Who to Congratulate?"] = "Who to Congratulate?" -- Requires localization
L["Will save all data for large /who queries"] = "Will save all data for large /who queries" -- Requires localization
L["Win Color"] = "Win Color" -- Requires localization
L["Words or phrases that will trigger the filtering."] = "\208\161\208\187\208\190\208\178\208\176 \208\184\208\187\208\184 \209\132\209\128\208\176\208\183\209\139, \208\186\208\190\209\130\208\190\209\128\209\139\208\181 \208\177\209\131\208\180\209\131\209\130 \208\178\209\139\208\183\209\139\208\178\208\176\209\130\209\140 \209\132\208\184\208\187\209\140\209\130\209\128\208\176\209\134\208\184\208\184." -- Needs review
L["XP Left To Level"] = "XP Left To Level" -- Requires localization
L["Yell"] = "\208\154\209\128\208\184\208\186" -- Needs review
L["Yell Chat"] = "\208\167\208\176\209\130 \208\154\209\128\208\184\208\186" -- Needs review
L["You are running version |cff1784d1%s|r."] = "You are running version |cff1784d1%s|r." -- Requires localization
L["You can only send a request once every %d seconds.  You last sent a request at %s."] = "You can only send a request once every %d seconds.  You last sent a request at %s." -- Requires localization
L["You have |cff%s%d|r of %s."] = "You have |cff%s%d|r of %s." -- Requires localization
L["You have |cff%s%d|r of %s, you need |cff%s%d|r more. |cff%s(%d/%d)|r"] = "You have |cff%s%d|r of %s, you need |cff%s%d|r more. |cff%s(%d/%d)|r" -- Requires localization
L["You have met your quota of %s%s. |cff%s(%d/%d)|r"] = "You have met your quota of %s%s. |cff%s(%d/%d)|r" -- Requires localization
L["You have reached the maximum number of friends, please remove 2 for this addon to function properly."] = "You have reached the maximum number of friends, please remove 2 for this addon to function properly." -- Requires localization
L["You must provide a calculation or set a variable."] = "You must provide a calculation or set a variable." -- Requires localization
L["You need %s%s%s%sto hit level %d."] = "You need %s%s%s%sto hit level %d." -- Requires localization
L["Your Color"] = "Your Color" -- Requires localization
L["Your Version: |cffffff00%d|r, Latest Version: |cffffff00%d|r"] = "Your Version: |cffffff00%d|r, Latest Version: |cffffff00%d|r" -- Requires localization
L["Your version of %s is out of date.  Latest version is |cff1784d1%d|r."] = "Your version of %s is out of date.  Latest version is |cff1784d1%d|r." -- Requires localization
