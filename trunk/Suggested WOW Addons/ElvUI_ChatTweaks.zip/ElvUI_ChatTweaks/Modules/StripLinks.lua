-------------------------------------------------------------------------------
-- ElvUI Chat Tweaks By Lockslap (US, Bleeding Hollow)
-- <Borderline Amazing>, http://ba-guild.com
-- Based on functionality provided by Prat and/or Chatter
-------------------------------------------------------------------------------
local Module = ElvUI_ChatTweaks:NewModule("Strip Links", "AceConsole-3.0")
local L = ElvUI_ChatTweaks.L
Module.name = L["Strip Links"]

local upper 	= string.upper

local db, options
local defaults = {
	profile = {
		types = {
			['item']			= false,
			['spell']			= false,
			['unit']			= true,
			['quest']			= true,
			['enchant']			= true,
			['achievement']		= false,
			['instancelock']	= true,
			['talent']			= true,
			['glyph']			= false,
		},
		
		-- channels
		guild = false,
		officer = false,
		say = true,
		yell = true,
		channel = true,
		
		action = "replace",
	}
}

local pattern = "\124c%x+\124H(.-):.-\124h%[(.-)%]\124h\124r"
local events = {
	"CHAT_MSG_GUILD",
	"CHAT_MSG_OFFICER",
	"CHAT_MSG_SAY",
	"CHAT_MSG_YELL",
	"CHAT_MSG_CHANNEL",
}

function UCWords(link)
	return link:lower():gsub("(%w+)", function(first)
		return first:gsub("^%l", upper)
	end)
end


local function FindLink(self, event, message, ...)
	if message:match(pattern) then
		
		-- debugging
		if Module.debug then Module:Print(message:match(pattern)) end
		
		local linkType, linkName = message:match(pattern)
		local chan = event:match("CHAT_MSG_(.+)"):lower()
		if db[chan] == true and db.types[linkType:lower()] == true then
			if db.action ==  "filter" then
				return true
			elseif db.action == "replace" then
				message = message:gsub(pattern, ("[%s]"):format(linkName))
				return false, message, ...
			elseif db.action == "remove" then
				message = message:gsub(pattern, "")
				return false, message, ...
			end
		end
	else
		return false
	end
end

function Module:OnEnable()
	for _, event in pairs(events) do
		ChatFrame_AddMessageEventFilter(event, FindLink)
	end
end

function Module:OnDisable()
	for _, event in pairs(events) do
		ChatFrame_RemoveMessageEventFilter(event, FindLink)
	end
end

function Module:OnInitialize()
	self.db = ElvUI_ChatTweaks.db:RegisterNamespace("StripLinks", defaults)
	db = self.db.profile
	Module.debug = ElvUI_ChatTweaks.db.profile.debugging	
	local i = 1
	for index, _ in pairs(db.types) do
		if index ~= "" and index ~= nil then
			options.types.args[index] = {
				type = "toggle",
				order = i,
				name = UCWords(index),
				desc = UCWords(index),
				get = function() return db.types[index] end,
				set = function(_, value) db.types[index] = value end,
			}
			i = i + 1
		end
	end
end

function Module:Info()
	return L["Allows you to strip certain links from channels of your choice."]
end

function Module:GetOptions()
	if not options then
		options = {
			action = {
				type = "select",
				order = 13,
				name = L["Action"],
				desc = L["What to do when a link is found.\n\n|cffffff00Replace:|r  Replaces link with just the text.\n|cffffff00Filter:|r  Filters the line.\n|cffffff00Remove:|r  Removes the link."],
				values = {
					["replace"]	= L["Replace"],
					["remove"]	= L["Remove"],
					["filter"]	= L["Filter"],
				},
				get = function() return db.action end,
				set = function(_, value) db.action = value end,
			},
			types = {
				type = "group",
				order = 14,
				name = L["Link Types"],
				guiInline = true,
				args = {}
			},
			channels = {
				type = "group",
				order = 15,
				name = L["Channels"],
				guiInline = true,
				args = {
					guild = {
						type = "toggle",
						order = 1,
						name = L["Guild"],
						desc = L["Guild Chat"],
						get = function() return db.guild end,
						set = function(_, value) db.guild = value end,
					},
					officer = {
						type = "toggle",
						order = 2,
						name = L["Officer"],
						desc = L["Officer Chat"],
						get = function() return db.officer end,
						set = function(_, value) db.officer = value end,
					},
					say = {
						type = "toggle",
						order = 3,
						name = L["Say"],
						desc = L["Say Chat"],
						get = function() return db.say end,
						set = function(_, value) db.say = value end,
					},
					yell = {
						type = "toggle",
						order = 4,
						name = L["Yell"],
						desc = L["Yell Chat"],
						get = function() return db.yell end,
						set = function(_, value) db.yell = value end,
					},
					channel = {
						type = "toggle",
						order = 5,
						name = L["Channel"],
						desc = L["Numbered Channels"],
						get = function() return db.channel end,
						set = function(_, value) db.channel = value end,
					},
				},
			},
		}
	end
	return options
end