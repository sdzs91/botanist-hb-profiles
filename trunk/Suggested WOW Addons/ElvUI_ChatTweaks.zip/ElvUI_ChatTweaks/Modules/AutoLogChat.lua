-------------------------------------------------------------------------------
-- ElvUI Chat Tweaks By Lockslap (US, Bleeding Hollow)
-- <Borderline Amazing>, http://ba-guild.com
-- Based on functionality provided by Prat and/or Chatter
-------------------------------------------------------------------------------
local Module = ElvUI_ChatTweaks:NewModule("Automatic Chat Logging", "AceConsole-3.0")
local L = ElvUI_ChatTweaks.L
Module.name = L["Automatic Chat Logging"]

function Module:OnEnable()
	self.isLogging = LoggingChat()
	if not self.isLogging then
		LoggingChat(true)
	end
end

function Module:OnDisable()
	if self.isLogging then
		LoggingChat(false)
	end
end

function Module:OnInitialize()
	Module.debug = ElvUI_ChatTweaks.db.profile.debugging
end

function Module:Info()
	return L["Automatically enables chat logging."]
end