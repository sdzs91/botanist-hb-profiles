-------------------------------------------------------------------------------
-- ElvUI Chat Tweaks By Lockslap (US, Bleeding Hollow)
-- <Borderline Amazing>, http://ba-guild.com
-- Based on functionality provided by Prat and/or Chatter
-------------------------------------------------------------------------------
local Module = ElvUI_ChatTweaks:NewModule("Developer Tools", "AceConsole-3.0")
local L = ElvUI_ChatTweaks.L
Module.name = L["Developer Tools"]

function Module:OnEnable()
	self:RegisterChatCommand("ctdev", function(args)
		local command = self:GetArgs(args)
		
		if command == "version" then
			Module:Print((L["Version: |cff1784d1%s|r"]):format(select(1, GetBuildInfo())))
		elseif command == "build" then
			Module:Print((L["Build: |cff1784d1%s|r"]):format(select(2, GetBuildInfo())))
		elseif command == "date" then
			Module:Print((L["Build Date: |cff1784d1%s|r"]):format(select(3, GetBuildInfo())))
		elseif command == "interface" then
			Module:Print((L["TOC Version: |cff1784d1%s|r"]):format(select(4, GetBuildInfo())))
		elseif command == "locale" then
			Module:Print((L["Client Locale: |cff1784d1%s|r"]):format(GetLocale()))
		else
			Module:Print(L["Available parameters are |cff1784d1version|r, |cff1784d1build|r, |cff1784d1date|r, |cff1784d1interface|r, |cff1784d1locale|r."])
		end
	end)
end

function Module:OnDisable()
	self:UnregisterChatCommand("ctdev")
end

function Module:OnInitialize()
	Module.debug = ElvUI_ChatTweaks.db.profile.debugging
end

function Module:Info()
	return L["Provides a few tools to help me (Lockslap), develop this addon as well as diagnose and fix any errors that are reported.\n\n|cff00ff00You can leave this addon disabled unless I (Lockslap) ask you to enable it for some debugging.|r"]
end