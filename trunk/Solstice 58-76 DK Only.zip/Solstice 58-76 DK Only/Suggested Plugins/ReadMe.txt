Copy Both of these plugins to you HonorBuddy\Plugins folder

GankOff - Keeps you characters from being ganked - will not rez your character for up to 30 minutes, if being camped.

Alwayshere - An anti-afk plugin to keep your character from being flagged AFK in Wow.